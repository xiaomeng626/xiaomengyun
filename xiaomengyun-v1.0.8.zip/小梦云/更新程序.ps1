﻿# 小梦云更新程序：等服务器退出 -> 停 cloudflared -> 把 staging/new 里的程序文件拷到安装目录（绝不碰 data/）-> 重启服务器
param(
    [int]$ServerPid = 0,
    [string]$StagingDir = '',
    [string]$InstallDir = ''
)
$ErrorActionPreference = 'Stop'

# 拿一个进程的命令行（Windows 用 CIM，Linux 用 /proc；都拿不到就返回空）
function Get-ProcessCommandLine($procId) {
    try {
        if (Get-Command Get-CimInstance -ErrorAction SilentlyContinue) {
            $c = (Get-CimInstance Win32_Process -Filter "ProcessId=$procId" -ErrorAction SilentlyContinue).CommandLine
            if ($c) { return [string]$c }
        }
    } catch { }
    try {
        $cmdFile = "/proc/$procId/cmdline"
        if (Test-Path $cmdFile) {
            $bytes = [System.IO.File]::ReadAllBytes($cmdFile)
            return ([System.Text.Encoding]::UTF8.GetString($bytes)).Replace([char]0, ' ')
        }
    } catch { }
    return ''
}

try {
    if ($ServerPid -gt 0) {
        try { Wait-Process -Id $ServerPid -Timeout 30 -ErrorAction SilentlyContinue } catch { }
    }
    Start-Sleep -Seconds 2
    # 先停 cloudflared：它占着安装文件夹，不停就拷不进去（2026-11-11 用户实测：关黑窗口后它还在后台跑）
    try {
        $killedIds = @()
        foreach ($p in @(Get-Process -Name 'cloudflared' -ErrorAction SilentlyContinue)) {
            $kill = $true
            # 尽量只停安装目录里的；判断不了就全停（这台电脑上 cloudflared 就是小梦云的）
            $cmd = Get-ProcessCommandLine $p.Id
            if ($cmd) {
                $kill = $false
                if ($InstallDir -and $cmd.ToLower().Contains($InstallDir.ToLower())) { $kill = $true }
            }
            if ($kill) {
                try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; $killedIds += $p.Id } catch { }
            }
        }
        # 等它们彻底退出，最多 10 秒
        $waitEnd = (Get-Date).AddSeconds(10)
        while ((Get-Date) -lt $waitEnd -and $killedIds.Count -gt 0) {
            $still = @($killedIds | Where-Object { $null -ne (Get-Process -Id $_ -ErrorAction SilentlyContinue) })
            if ($still.Count -eq 0) { break }
            Start-Sleep -Milliseconds 500
        }
    } catch { }
    # 再停掉其他还在跑的、命令行里带“小梦云.ps1”的 PowerShell 进程（不含更新程序自己）
    try {
        foreach ($pn in @('pwsh', 'powershell')) {
            foreach ($p in @(Get-Process -Name $pn -ErrorAction SilentlyContinue)) {
                if ($p.Id -eq $PID) { continue }
                if ($ServerPid -gt 0 -and $p.Id -eq $ServerPid) { continue }
                $cmd = Get-ProcessCommandLine $p.Id
                if ($cmd -and $cmd.Contains('小梦云.ps1')) {
                    try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } catch { }
                }
            }
        }
    } catch { }
    $newDir = Join-Path $StagingDir 'new'
    if (Test-Path $newDir) {
        # 只拷程序文件：staging/new 里的一切（除 data 文件夹外）覆盖到安装目录
        # 单个文件被锁就重试 3 次（每次隔 1 秒），还不行就报错写进 update-result.json
        Get-ChildItem $newDir -Force | ForEach-Object {
            if ($_.Name -eq 'data') { return }
            $dest = Join-Path $InstallDir $_.Name
            $copied = $false
            $copyErr = $null
            for ($try = 1; $try -le 3 -and -not $copied; $try++) {
                try {
                    if ($_.PSIsContainer) {
                        Copy-Item $_.FullName $dest -Recurse -Force -ErrorAction Stop
                    } else {
                        Copy-Item $_.FullName $dest -Force -ErrorAction Stop
                    }
                    $copied = $true
                } catch {
                    $copyErr = $_
                    if ($try -lt 3) { Start-Sleep -Seconds 1 }
                }
            }
            if (-not $copied) { throw "拷文件失败（$($_.Name)）：$($copyErr.Exception.Message)" }
        }
    }
    # 记录更新结果（供新版服务器启动后显示）
    try {
        $ver = 'unknown'
        $vj = Join-Path $InstallDir 'version.json'
        if (Test-Path $vj) { $ver = ((Get-Content $vj -Raw -Encoding UTF8 | ConvertFrom-Json).version) }
        Set-Content -Path (Join-Path $InstallDir 'update-result.json') -Value (@{ ok = $true; version = $ver; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') } | ConvertTo-Json -Compress) -Encoding UTF8
    } catch { }
    # 清掉 staging（TEMP 下的整个更新临时目录一起清）
    try { Remove-Item $StagingDir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    try {
        $updParent = Split-Path $StagingDir -Parent
        if ((Split-Path $updParent -Leaf) -eq 'XiaoMengYun-update') { Remove-Item $updParent -Recurse -Force -ErrorAction SilentlyContinue }
    } catch { }
    try { Remove-Item (Join-Path $InstallDir 'update-pending.json') -Force -ErrorAction SilentlyContinue } catch { }
    # 重启服务器：只在 Windows 上通过 .bat 新开一个黑窗口；其他系统跳过（由人工重启），
    # 重启失败也不推翻“文件已替换成功”的结果。
    if ($IsWindows) {
        try {
            $bat = Join-Path $InstallDir '启动小梦云.bat'
            if (Test-Path $bat) {
                Start-Process -FilePath 'cmd.exe' -ArgumentList "/c `"$bat`"" -WindowStyle Normal
            }
        } catch { }
    }
} catch {
    try {
        Set-Content -Path (Join-Path $InstallDir 'update-result.json') -Value (@{ ok = $false; version = ''; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); error = $_.Exception.Message } | ConvertTo-Json -Compress) -Encoding UTF8
    } catch { }
}
