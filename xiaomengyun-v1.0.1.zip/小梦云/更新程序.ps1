﻿# 小梦云更新程序：等服务器退出 -> 把 staging/new 里的程序文件拷到安装目录（绝不碰 data/）-> 重启服务器
param(
    [int]$ServerPid = 0,
    [string]$StagingDir = '',
    [string]$InstallDir = ''
)
$ErrorActionPreference = 'Stop'
try {
    if ($ServerPid -gt 0) {
        try { Wait-Process -Id $ServerPid -Timeout 30 -ErrorAction SilentlyContinue } catch { }
    }
    Start-Sleep -Seconds 2
    $newDir = Join-Path $StagingDir 'new'
    if (Test-Path $newDir) {
        # 只拷程序文件：staging/new 里的一切（除 data 文件夹外）覆盖到安装目录
        Get-ChildItem $newDir -Force | ForEach-Object {
            if ($_.Name -eq 'data') { return }
            $dest = Join-Path $InstallDir $_.Name
            if ($_.PSIsContainer) {
                Copy-Item $_.FullName $dest -Recurse -Force
            } else {
                Copy-Item $_.FullName $dest -Force
            }
        }
    }
    # 记录更新结果（供新版服务器启动后显示）
    try {
        $ver = 'unknown'
        $vj = Join-Path $InstallDir 'version.json'
        if (Test-Path $vj) { $ver = ((Get-Content $vj -Raw -Encoding UTF8 | ConvertFrom-Json).version) }
        Set-Content -Path (Join-Path $InstallDir 'update-result.json') -Value (@{ ok = $true; version = $ver; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') } | ConvertTo-Json -Compress) -Encoding UTF8
    } catch { }
    # 清掉 staging
    try { Remove-Item $StagingDir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    try { Remove-Item (Join-Path $InstallDir 'update-pending.json') -Force -ErrorAction SilentlyContinue } catch { }
    # 重启服务器：只在 Windows 上通过 .bat 新开一个黑窗口；其他系统跳过（由人工重启），
    # 重启失败也不推翻“文件已替换成功”的结果。
    if ($IsWindows) {
        try {
            $bat = Join-Path $InstallDir '启动小梦云.bat'
            if (Test-Path $bat) {
                Start-Process -FilePath 'cmd.exe' -ArgumentList "/c `"$bat`"" -WindowStyle Normal
            }
        } catch { }
    }
} catch {
    try {
        Set-Content -Path (Join-Path $InstallDir 'update-result.json') -Value (@{ ok = $false; version = ''; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); error = $_.Exception.Message } | ConvertTo-Json -Compress) -Encoding UTF8
    } catch { }
}
