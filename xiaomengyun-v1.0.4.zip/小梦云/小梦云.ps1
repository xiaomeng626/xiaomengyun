﻿# 小梦云 - 联网版（BOSS 端主机）
# 用法：双击同目录下的“启动小梦云.bat”，黑窗口不要关。
# 本机是主机（BOSS），工人用公开链接在浏览器里注册登录，不用装东西。
# 账号存在服务器文件里（storage.json），重启还在；公开链接每次重启都会变。
# 角色：BOSS（老板密码登录，全权）/ 管理员（老板任命，只能添加账号）/ 工人（注册登录，只能拿账号用）。
# 余额字段已预留（workers.json 里 balance，默认 null = 不限量），以后加充值系统用。

$Port = 18080
foreach ($p in 18080..18089) {
    try {
        $testListener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $p)
        $testListener.Start()
        $testListener.Stop()
        $Port = $p
        break
    } catch { }
}

$DataDir = Join-Path $PSScriptRoot 'data'
if (-not (Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
# 旧版升级：如果数据文件还在程序目录，搬进 data/（data/ 里已有的不动）
foreach ($legacy in @('admin.json','workers.json','storage.json','taken.json','blacklist.json','takelog.json','regcode.json','spent.json','usagelog.json')) {
    $old = Join-Path $PSScriptRoot $legacy
    $new = Join-Path $DataDir $legacy
    if ((Test-Path $old) -and -not (Test-Path $new)) {
        try { Move-Item $old $new -ErrorAction Stop } catch { }
    }
}
$AdminFile   = Join-Path $DataDir 'admin.json'
$WorkersFile = Join-Path $DataDir 'workers.json'
$StorageFile = Join-Path $DataDir 'storage.json'
$TakenFile   = Join-Path $DataDir 'taken.json'
$BlacklistFile = Join-Path $DataDir 'blacklist.json'
$TakeLogFile = Join-Path $DataDir 'takelog.json'
$SpentFile   = Join-Path $DataDir 'spent.json'
$UsageLogFile = Join-Path $DataDir 'usagelog.json'
$RegCodeFile = Join-Path $DataDir 'regcode.json'
$SettingsFile = Join-Path $DataDir 'settings.json'
$QrSharesFile = Join-Path $DataDir 'qr-shares.json'
$BackupDir = Join-Path $PSScriptRoot 'backups'
if (-not (Test-Path $BackupDir)) { New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null }
$CfLogFile   = Join-Path $PSScriptRoot 'cloudflared.log'
$CfExe       = Join-Path $PSScriptRoot 'cloudflared.exe'
$IconFile    = Join-Path $PSScriptRoot 'icon.png'
# 更新相关（程序文件，都在根目录，不在 data/ 里）
$VersionFile = Join-Path $PSScriptRoot 'version.json'
$UpdateConfigFile = Join-Path $PSScriptRoot 'update.json'
# 更新的下载和解压改放系统临时文件夹，不再写安装文件夹
# （安装文件夹可能写不进、还被 cloudflared 占着；2026-11-11 用户实测 v1.0.2 的问题）
$tempBase = $env:TEMP
if ([string]::IsNullOrWhiteSpace($tempBase)) { $tempBase = $env:TMPDIR }
if ([string]::IsNullOrWhiteSpace($tempBase)) { $tempBase = '/tmp' }
$UpdateTempDir = Join-Path $tempBase 'XiaoMengYun-update'
$UpdateZipPath = Join-Path $UpdateTempDir 'update-download.zip'
$StagingDir = Join-Path $UpdateTempDir 'staging'
$UpdaterFile = Join-Path $PSScriptRoot '更新程序.ps1'

$script:BossToken = [guid]::NewGuid().ToString()
$script:WorkerTokens = @{}
$script:PublicUrl = ''
$script:FetchCache = @{}
$script:CfProcess = $null
$script:LastCfLogCheck = [datetime]::MinValue
$script:LastCleanup = [datetime]::MinValue

function Get-PasswordHash($plain) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes([string]$plain)
    $hash = $sha.ComputeHash($bytes)
    $sha.Dispose()
    return ([System.BitConverter]::ToString($hash)).Replace('-', '').ToLower()
}

# 密码存哈希加盐（PBKDF2）：格式 pbkdf2-sha256:10000:<盐base64>:<哈希base64>，文件里绝不明文存密码。
# 老数据是纯 SHA256（64 位十六进制），登录时校验通过就自动升级成加盐哈希。
function New-PasswordHash($plain) {
    $salt = New-Object byte[] 16
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($salt)
    $iterations = 10000
    $algo = 'sha256'
    try {
        $kdf = New-Object System.Security.Cryptography.Rfc2898DeriveBytes([string]$plain, $salt, $iterations, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
    } catch {
        $algo = 'sha1'
        $kdf = New-Object System.Security.Cryptography.Rfc2898DeriveBytes([string]$plain, $salt, $iterations)
    }
    $hash = $kdf.GetBytes(32)
    $kdf.Dispose()
    return ('pbkdf2-' + $algo + ':' + $iterations + ':' + [Convert]::ToBase64String($salt) + ':' + [Convert]::ToBase64String($hash))
}
function Test-PasswordHash($plain, $stored) {
    # 返回 'ok'（加盐哈希校验通过）、'ok-legacy'（老 SHA256 校验通过，需升级）、'bad'
    if ([string]::IsNullOrWhiteSpace([string]$stored)) { return 'bad' }
    $stored = [string]$stored
    if ($stored -like 'pbkdf2-*') {
        $parts = $stored -split ':'
        if ($parts.Count -ne 4) { return 'bad' }
        $algo = $parts[0] -replace '^pbkdf2-',''
        $iterations = 0
        if (-not [int]::TryParse($parts[1], [ref]$iterations) -or $iterations -le 0) { return 'bad' }
        try {
            $salt = [Convert]::FromBase64String($parts[2])
            $want = [Convert]::FromBase64String($parts[3])
            if ($algo -eq 'sha256') {
                $kdf = New-Object System.Security.Cryptography.Rfc2898DeriveBytes([string]$plain, $salt, $iterations, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
            } else {
                $kdf = New-Object System.Security.Cryptography.Rfc2898DeriveBytes([string]$plain, $salt, $iterations)
            }
            $got = $kdf.GetBytes(32)
            $kdf.Dispose()
            if ($got.Length -ne $want.Length) { return 'bad' }
            for ($i = 0; $i -lt $got.Length; $i++) { if ($got[$i] -ne $want[$i]) { return 'bad' } }
            return 'ok'
        } catch { return 'bad' }
    }
    if ((Get-PasswordHash $plain) -eq $stored) { return 'ok-legacy' }
    return 'bad'
}

function Read-JsonArray($path) {
    if (-not (Test-Path $path)) { return @() }
    try {
        $j = Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -eq $j) { return @() }
        return @($j)
    } catch { return @() }
}

function Write-JsonArray($path, $items) {
    $arr = @($items)
    if ($arr.Count -eq 0) { '[]' | Set-Content $path -Encoding UTF8; return }
    $parts = foreach ($it in $arr) { $it | ConvertTo-Json -Depth 5 -Compress }
    ('[' + ($parts -join ',') + ']') | Set-Content $path -Encoding UTF8
}

function Read-JsonObject($path) {
    if (-not (Test-Path $path)) { return $null }
    try { return (Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { return $null }
}

function Write-JsonObject($path, $obj) {
    ($obj | ConvertTo-Json -Depth 5 -Compress) | Set-Content $path -Encoding UTF8
}

function Get-BossHash {
    $j = Read-JsonObject $AdminFile
    if ($null -ne $j -and $null -ne $j.hash) { return [string]$j.hash }
    return ''
}

function Set-BossHash($hash) { Write-JsonObject $AdminFile @{ hash = $hash } }

function Get-RegCode {
    $j = Read-JsonObject $RegCodeFile
    if ($null -ne $j -and $null -ne $j.code) { return [string]$j.code }
    return ''
}

function Set-RegCode($code) { Write-JsonObject $RegCodeFile @{ code = $code } }

function Find-Worker($nickname) {
    $workers = Read-JsonArray $WorkersFile
    foreach ($w in $workers) { if ([string]$w.nickname -eq $nickname) { return $w } }
    return $null
}

function Save-Workers($workers) { Write-JsonArray $WorkersFile $workers }

# 二维码短链接分享：把一批邮箱存成一个短 token，手机扫码打开 /e/<token> 就能复制/存备忘录
# （二维码里直接放邮箱原文会被 iPhone 认成 mailto 跳去 Mail，没法复制；所以二维码里只放短链接）
function Get-QrShareToken {
    $chars = 'abcdefghjkmnpqrstuvwxyz23456789'.ToCharArray()
    $rng = New-Object System.Random
    $tok = ''
    for ($i = 0; $i -lt 6; $i++) { $tok += $chars[$rng.Next($chars.Length)] }
    return $tok
}

function Read-QrShares {
    $arr = @(Read-JsonArray $QrSharesFile)
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $valid = @()
    foreach ($s in $arr) {
        if ($null -ne $s -and $null -ne $s.token -and $null -ne $s.created -and ($now - [long]$s.created) -le 86400) {
            $valid += $s
        }
    }
    return $valid
}

function New-QrShare($emails) {
    $shares = @(Read-QrShares)
    $tok = ''
    do { $tok = Get-QrShareToken } while (@($shares | Where-Object { [string]$_.token -eq $tok }).Count -gt 0)
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $shares += @{ token = $tok; emails = @($emails); created = $now }
    Write-JsonArray $QrSharesFile $shares
    return $tok
}

function Get-QrShare($token) {
    $shares = @(Read-QrShares)
    foreach ($s in $shares) { if ([string]$s.token -eq $token) { return $s } }
    return $null
}

# 二维码短链接必须用手机能打开的地址：优先内网 IP，其次隧道公开链接
# （不能用 window.location.origin 拼：电脑上用 127.0.0.1 打开页面时 origin 是 127.0.0.1，
#  手机扫了会去连手机自己的 127.0.0.1，根本打不开。2026-11-11 用户实测 v1.0.2 的 bug）
function Get-QrShareUrl($token) {
    if (-not [string]::IsNullOrEmpty($LanIp)) { return "http://${LanIp}:$Port/e/$token" }
    $link = Get-TunnelUrl
    if (-not [string]::IsNullOrEmpty($link)) { return ($link.TrimEnd('/')) + "/e/$token" }
    return "/e/$token"
}

function Get-QrSharePage($share) {
    $pageExpired = @'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>小梦云邮箱</title>
<style>
body{margin:0;background:#0b1220;color:#e2e8f0;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;}
.wrap{max-width:560px;margin:0 auto;padding:20px 16px 40px;}
h1{font-size:20px;margin:6px 0 4px;}
.sub{color:#94a3b8;font-size:14px;line-height:1.6;margin:0 0 16px;}
.err{color:#f87171;font-size:16px;line-height:1.6;}
</style>
</head>
<body>
<div class="wrap">
<h1>小梦云邮箱</h1>
<p class="err">链接已过期，请重新生成二维码</p>
<p class="sub">这个分享链接只有 24 小时有效。回电脑上重新点「生成二维码」，再扫新的码。</p>
</div>
</body>
</html>
'@
    if ($null -eq $share) { return $pageExpired }
    $emails = @($share.emails)
    if ($emails.Count -eq 0) { return $pageExpired }
    $rows = ''
    foreach ($e in $emails) {
        $esc = ([string]$e).Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;').Replace('"', '&quot;')
        $rows += '<div class="row"><span class="em">' + $esc + '</span><button class="mini" data-em="' + $esc + '">复制</button></div>' + "`n"
    }
    $allJson = ConvertTo-Json -InputObject @($emails) -Compress
    $page = @'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>小梦云邮箱</title>
<style>
body{margin:0;background:#0b1220;color:#e2e8f0;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;}
.wrap{max-width:560px;margin:0 auto;padding:20px 16px 40px;}
h1{font-size:20px;margin:6px 0 4px;}
.sub{color:#94a3b8;font-size:14px;margin:0 0 16px;}
.big{width:100%;padding:16px 0;font-size:18px;font-weight:700;color:#0b1220;background:#f59e0b;border:0;border-radius:12px;}
.big:active{background:#d97706;}
.hint{color:#f59e0b;font-size:14px;line-height:1.6;margin:14px 0;}
.row{display:flex;align-items:center;gap:10px;background:#0f172a;border:1px solid #243449;border-radius:10px;padding:12px;margin:8px 0;}
.em{flex:1;font-size:15px;word-break:break-all;}
.mini{flex:none;padding:8px 14px;font-size:14px;color:#e2e8f0;background:#1e293b;border:1px solid #334155;border-radius:8px;}
.mini:active{background:#334155;}
.foot{color:#64748b;font-size:12px;margin-top:20px;text-align:center;}
</style>
</head>
<body>
<div class="wrap">
<h1>小梦云邮箱</h1>
<p class="sub">共 __COUNT__ 个邮箱</p>
<button class="big" id="copyAll">复制全部邮箱</button>
<p class="hint">想存到备忘录：点浏览器右上角分享 → 存储到备忘录</p>
<div id="list">__EMAIL_ROWS__</div>
<p class="foot">小梦云 · 链接 24 小时内有效</p>
</div>
<script>
var ALL = __ALL_JSON__;
function copyText(t, btn) {
  var old = btn ? btn.textContent : '';
  function done(ok) { if (btn) { btn.textContent = ok ? '已复制' : '复制失败'; setTimeout(function(){ btn.textContent = old; }, 1200); } }
  function fallback() {
    var ta = document.createElement('textarea');
    ta.value = t;
    ta.style.position = 'fixed'; ta.style.top = '0'; ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    try { ta.setSelectionRange(0, ta.value.length); } catch (e) {}
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    done(ok);
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(t).then(function(){ done(true); }).catch(function(){ fallback(); });
  } else { fallback(); }
}
document.getElementById('copyAll').addEventListener('click', function(){ copyText(ALL.join('\n'), this); });
var btns = document.querySelectorAll('.mini');
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener('click', function(){ copyText(this.getAttribute('data-em'), this); });
}
</script>
</body>
</html>
'@
    $page = $page.Replace('__COUNT__', [string]$emails.Count)
    $page = $page.Replace('__EMAIL_ROWS__', $rows)
    $page = $page.Replace('__ALL_JSON__', $allJson)
    return $page
}

function Get-RequestRole($headers) {
    if (-not $headers.ContainsKey('x-auth-token')) { return $null }
    $tok = $headers['x-auth-token']
    if ($tok -eq $script:BossToken -and -not [string]::IsNullOrEmpty((Get-BossHash))) {
        return @{ role = 'boss'; nickname = 'BOSS' }
    }
    if ($script:WorkerTokens.ContainsKey($tok)) {
        $nick = $script:WorkerTokens[$tok]
        $w = Find-Worker $nick
        if ($null -ne $w -and $w.enabled) {
            return @{ role = [string]$w.role; nickname = [string]$w.nickname }
        }
    }
    return $null
}

function Get-StorageCounts {
    $st = Read-JsonArray $StorageFile
    $emails = 0; $phones = 0; $noLink = 0; $noLinkEmail = 0; $noLinkPhone = 0; $usedPhones = 0; $usedEmails = 0
    foreach ($a in $st) {
        # 电话号码是一次性的：used=true 表示已用过/已废弃，不再计入可用数，也永不被取出
        if ([bool]$a.used) {
            if ([string]$a.type -eq 'phone') { $usedPhones++ } else { $usedEmails++ }
            continue
        }
        if ([string]$a.type -eq 'phone') { $phones++ } else { $emails++ }
        if ([string]::IsNullOrWhiteSpace([string]$a.url)) {
            $noLink++
            if ([string]$a.type -eq 'phone') { $noLinkPhone++ } else { $noLinkEmail++ }
        }
    }
    return @{ emails = $emails; phones = $phones; noLink = $noLink; noLinkEmail = $noLinkEmail; noLinkPhone = $noLinkPhone; usedPhones = $usedPhones; usedEmails = $usedEmails; total = $st.Count }
}

# 解析账号行：完整“账号----链接”按账号类型分；只有账号没有链接的裸行，用面板类型（forceType），链接留空
function Parse-AccountLines($text, $forceType) {
    $out = @()
    foreach ($line in ($text -split "`n")) {
        $line = $line.Trim()
        if (-not $line) { continue }
        $parts = @($line -split '----|\t' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ($parts.Count -lt 1) { continue }
        $label = $parts[0]
        $url = if ($parts.Count -ge 2) { $parts[1] } else { '' }
        if ($parts.Count -ge 2) {
            $type = if ($label -match '@') { 'email' } else { 'phone' }
        } else {
            $type = if ($forceType) { $forceType } elseif ($label -match '@') { 'email' } else { 'phone' }
        }
        $out += @{ label = $label; url = $url; type = $type }
    }
    return $out
}

function Find-Taken($label) {
    $taken = Read-JsonArray $TakenFile
    foreach ($t in $taken) { if ([string]$t.label -eq $label) { return $t } }
    return $null
}

# 拉黑名单：label -> 1；被拉黑的账号永不进仓库、永不被取出
function Get-BlacklistLabels {
    $set = @{}
    foreach ($b in (Read-JsonArray $BlacklistFile)) { $set[[string]$b.label] = 1 }
    return $set
}

# 已废弃名单：label -> 1；废弃过的账号永不被再次取出（哪怕重新导入）
function Get-SpentLabels {
    $set = @{}
    foreach ($s in (Read-JsonArray $SpentFile)) { $set[[string]$s.label] = 1 }
    return $set
}

# 发件方 -> 平台显示名（只认三个：TikTok、PixVerse、可灵；其他照原名显示；空发件方返回空）
function Get-PlatformName($sender) {
    $s = [string]$sender
    if ([string]::IsNullOrWhiteSpace($s)) { return '' }
    if ($s -match '(?i)tiktok') { return 'TikTok' }
    if ($s -match '(?i)pixverse') { return 'PixVerse' }
    if ($s -match '(?i)kling' -or $s -match '可灵') { return '可灵' }
    $name = ($s -split '·')[0].Trim()
    if ($name) { return $name }
    return '其他'
}

# 标记废弃：从仓库移除，记入 spent.json（永不再取）；如果正被人拿着，taken 里的记录保留 used=true，
# 让持有人还能看到最后一条码，释放/确认时再彻底移出 taken。
function Mark-Spent($label, $type, $reason) {
    $st = @(Read-JsonArray $StorageFile | Where-Object { [string]$_.label -ne $label })
    Write-JsonArray $StorageFile $st
    $spent = @(Read-JsonArray $SpentFile)
    $exists = $false
    foreach ($s in $spent) { if ([string]$s.label -eq $label) { $exists = $true; break } }
    if (-not $exists) {
        $spent += @{ label = $label; type = $type; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); reason = $reason }
        Write-JsonArray $SpentFile $spent
    }
    $taken = @(Read-JsonArray $TakenFile)
    $changed = $false
    foreach ($t in $taken) {
        if ([string]$t.label -eq $label) { $t.used = $true; $changed = $true }
    }
    if ($changed) { Write-JsonArray $TakenFile $taken }
}

# 记录一个平台被使用（新平台首次出现才记）：返回 @{ platforms = @(); spent = $false; platform = '' }
# 邮箱满 3 个平台立即废弃；电话只认一个平台，第二个不同平台不记。
function Register-Platform($label, $type, $sender, $nickname) {
    $platform = Get-PlatformName $sender
    $res = @{ platforms = @(); spent = $false; platform = $platform }
    if (-not $platform) {
        # 没有发件人（如短信）：不记平台，但把当前平台列表带回来
        $t0 = Find-Taken $label
        if ($null -ne $t0) { $res.platforms = @($t0.platforms); $res.spent = [bool]$t0.used }
        return $res
    }
    $taken = @(Read-JsonArray $TakenFile)
    $rec = $null
    foreach ($t in $taken) { if ([string]$t.label -eq $label) { $rec = $t; break } }
    if ($null -eq $rec) { return $res }
    $plats = @()
    foreach ($p in @($rec.platforms)) { $plats += [string]$p }
    $res.platforms = $plats
    $res.spent = [bool]$rec.used
    if ($plats -contains $platform) { return $res }
    if ($type -eq 'phone' -and $plats.Count -ge 1) {
        # 电话只认一个平台：第二个不同平台不记、不显示
        return $res
    }
    $plats += $platform
    $rec.platforms = $plats
    if ([string]::IsNullOrWhiteSpace([string]$rec.firstUse)) { $rec.firstUse = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
    $res.platforms = $plats
    # 使用记录：平台、谁、时间（只记新平台首次出现）
    $log = @(Read-JsonArray $UsageLogFile)
    $log += @{ label = $label; type = $type; platform = $platform; nickname = $nickname; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); manual = $false }
    if ($log.Count -gt 1000) { $log = $log[($log.Count - 1000)..($log.Count - 1)] }
    Write-JsonArray $UsageLogFile $log
    # 邮箱满 3 个平台立即废弃
    if ($type -eq 'email' -and $plats.Count -ge 3) {
        $rec.used = $true
        $res.spent = $true
    }
    Write-JsonArray $TakenFile $taken
    if ($res.spent) { Mark-Spent $label $type '已用满 3 个平台' }
    return $res
}

# 定期清理：只清仓库（storage.json）里的账号，不动正在被人拿着的（taken.json），不动使用记录。
# 邮箱：注册过 ≥1 个平台且首次使用已超过 3 天 -> 清掉；0 平台永不清理；满 3 平台立即废弃（这里是兜底）。
# 电话：已确认废弃的（used）清掉；仓库里出现已用过的电话也清掉。
# 返回被清掉的列表（label/type/reason）。
function Invoke-Cleanup {
    $removed = @()
    $st = @(Read-JsonArray $StorageFile)
    $now = Get-Date
    $kept = @()
    foreach ($a in $st) {
        $label = [string]$a.label
        $type = [string]$a.type
        $plats = @($a.platforms)
        $reason = ''
        if ([bool]$a.used) { $reason = '已废弃' }
        elseif ($type -eq 'email' -and $plats.Count -ge 3) { $reason = '已用满 3 个平台' }
        elseif ($type -eq 'email' -and $plats.Count -ge 1 -and -not [string]::IsNullOrWhiteSpace([string]$a.firstUse)) {
            try {
                $fu = [datetime]$a.firstUse
                if (($now - $fu).TotalDays -ge 3) { $reason = '首次使用已超过 3 天' }
            } catch { }
        }
        elseif ($type -eq 'phone' -and $plats.Count -ge 1) { $reason = '电话已用过' }
        if ($reason) { $removed += @{ label = $label; type = $type; reason = $reason } } else { $kept += $a }
    }
    if ($removed.Count -gt 0) {
        Write-JsonArray $StorageFile $kept
        $spent = @(Read-JsonArray $SpentFile)
        $spentLabels = @{}
        foreach ($s in $spent) { $spentLabels[[string]$s.label] = 1 }
        foreach ($r in $removed) {
            if (-not $spentLabels.ContainsKey($r.label)) {
                $spent += @{ label = $r.label; type = $r.type; time = $now.ToString('yyyy-MM-dd HH:mm:ss'); reason = $r.reason }
            }
        }
        Write-JsonArray $SpentFile $spent
    }
    return $removed
}

# ---------------- 设置（超时放回时间等） ----------------
function Get-Settings {
    $def = @{ holdTimeoutMinutes = 30 }
    try {
        $j = Read-JsonObject $SettingsFile
        if ($null -ne $j -and $null -ne $j.holdTimeoutMinutes) { $def.holdTimeoutMinutes = [int]$j.holdTimeoutMinutes }
    } catch { }
    if ($def.holdTimeoutMinutes -lt 5) { $def.holdTimeoutMinutes = 5 }
    if ($def.holdTimeoutMinutes -gt 1440) { $def.holdTimeoutMinutes = 1440 }
    return $def
}
function Set-Settings($s) { Write-JsonObject $SettingsFile $s }

# 释放一个已取出的账号（回池或废弃），和 /api/release 同一套规则。
# 返回 @{ ok; discarded; found }
function Invoke-ReleaseLabel($label) {
    $label = ([string]$label).Trim()
    $tk = @(Read-JsonArray $TakenFile)
    $rec = $null
    foreach ($t in $tk) { if ([string]$t.label -eq $label) { $rec = $t; break } }
    if ($null -eq $rec) { return @{ ok = $true; discarded = $false; found = $false } }
    $type = [string]$rec.type
    $plats = @($rec.platforms)
    $discarded = $false
    if ([bool]$rec.used) { $discarded = $true }
    elseif ($type -eq 'phone' -and $plats.Count -ge 1) { Mark-Spent $label $type '电话已用过'; $discarded = $true }
    elseif ($type -eq 'email' -and $plats.Count -ge 1 -and -not [string]::IsNullOrWhiteSpace([string]$rec.firstUse)) {
        try { if (((Get-Date) - [datetime]$rec.firstUse).TotalDays -ge 3) { Mark-Spent $label $type '首次使用已超过 3 天'; $discarded = $true } } catch { }
    }
    if (-not $discarded) {
        $st = @(Read-JsonArray $StorageFile)
        $inStore = $false
        foreach ($a in $st) { if ([string]$a.label -eq $label) { $inStore = $true; break } }
        if (-not $inStore) {
            $st += @{ label = $label; url = [string]$rec.url; type = $type; platforms = $plats; firstUse = [string]$rec.firstUse; used = $false }
            Write-JsonArray $StorageFile $st
        }
    }
    $tk2 = @($tk | Where-Object { [string]$_.label -ne $label })
    Write-JsonArray $TakenFile $tk2
    return @{ ok = $true; discarded = $discarded; found = $true }
}

# 超时自动放回：拿了超过 holdTimeoutMinutes 分钟还没动静（没收到码、没确认、没释放）的，自动按释放规则处理。
# 动静以 lastSeen 为准（收到码时更新；没收到过码就按领用时间算）。返回被自动放回的列表。
function Invoke-HoldTimeout {
    $settings = Get-Settings
    $timeout = [int]$settings.holdTimeoutMinutes
    $now = Get-Date
    $released = @()
    $tk = @(Read-JsonArray $TakenFile)
    foreach ($t in $tk) {
        $last = $null
        try { if (-not [string]::IsNullOrWhiteSpace([string]$t.lastSeen)) { $last = [datetime]$t.lastSeen } } catch { }
        if ($null -eq $last) { try { $last = [datetime]$t.time } catch { continue } }
        $held = ($now - $last).TotalMinutes
        if ($held -ge $timeout) {
            $rel = Invoke-ReleaseLabel ([string]$t.label)
            if ($rel.ok -and $rel.found) {
                $released += @{ label = [string]$t.label; type = [string]$t.type; nickname = [string]$t.nickname; heldMinutes = [math]::Floor($held); discarded = [bool]$rel.discarded }
            }
        }
    }
    return $released
}

# ---------------- 备份 ----------------
# 备份数据文件夹（账号、工人、密码哈希、使用记录、设置）成一个 zip，放在 backups/（数据文件夹外）。
# 只保留最近 7 份，多的自动删。返回备份文件名。
function New-Backup($reason) {
    $stamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
    $name = "小梦云备份-$stamp.zip"
    $dest = Join-Path $BackupDir $name
    $files = @(Get-ChildItem -Path $DataDir -File -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
    if ($files.Count -eq 0) { throw '数据文件夹是空的，没什么可备份' }
    Compress-Archive -Path $files -DestinationPath $dest -Force
    # 只留最近 7 份
    $all = @(Get-ChildItem -Path $BackupDir -Filter '小梦云备份-*.zip' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($all.Count -gt 7) {
        foreach ($old in $all[7..($all.Count - 1)]) { try { Remove-Item $old.FullName -Force -ErrorAction SilentlyContinue } catch { } }
    }
    return $name
}
function Get-BackupList {
    $list = @()
    foreach ($f in @(Get-ChildItem -Path $BackupDir -Filter '小梦云备份-*.zip' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)) {
        $list += @{ name = $f.Name; size = $f.Length; time = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss') }
    }
    return $list
}
# 从备份 zip 恢复：校验里面有数据文件才恢复，恢复后数据文件即刻生效（服务端每次请求都重读文件）。
# 返回 @{ ok; restored = @('storage.json', ...) }
function Restore-Backup($zipPath) {
    $need = @('storage.json', 'workers.json', 'admin.json', 'regcode.json', 'takelog.json', 'blacklist.json', 'spent.json', 'usagelog.json')
    $tmp = Join-Path $PSScriptRoot 'restore-tmp'
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Force -Path $tmp | Out-Null
    try {
        Expand-Archive -Path $zipPath -DestinationPath $tmp -Force
        $found = @()
        foreach ($n in $need) {
            $src = Join-Path $tmp $n
            if (Test-Path $src) { $found += $n }
        }
        if ($found.Count -eq 0) { throw '这个备份里没有小梦云的数据文件，恢复不了' }
        foreach ($n in $found) {
            Copy-Item (Join-Path $tmp $n) (Join-Path $DataDir $n) -Force
        }
        return @{ ok = $true; restored = $found }
    } finally {
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

# ---------------- 自动更新 / 一键更新 ----------------
function Get-CurrentVersion {
    try {
        $j = Get-Content $VersionFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($j.version) { return [string]$j.version }
    } catch { }
    return '1.0.0'
}

function Compare-Versions($a, $b) {
    $pa = @([string]$a -split '\.' | ForEach-Object { try { [int]$_ } catch { 0 } })
    $pb = @([string]$b -split '\.' | ForEach-Object { try { [int]$_ } catch { 0 } })
    $n = [Math]::Max($pa.Count, $pb.Count)
    for ($i = 0; $i -lt $n; $i++) {
        $x = if ($i -lt $pa.Count) { $pa[$i] } else { 0 }
        $y = if ($i -lt $pb.Count) { $pb[$i] } else { 0 }
        if ($x -lt $y) { return -1 }
        if ($x -gt $y) { return 1 }
    }
    return 0
}

function Get-ManifestUrl {
    try {
        $j = Get-Content $UpdateConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
        return [string]$j.manifestUrl
    } catch { return '' }
}

# raw.githubusercontent.com 拉不到时用的备用清单地址（jsdelivr 镜像）
function Get-ManifestMirrorUrl($url) {
    if ([string]::IsNullOrWhiteSpace($url)) { return '' }
    if ($url -match '^https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/main/(.*)$') {
        return "https://cdn.jsdelivr.net/gh/$($Matches[1])/$($Matches[2])@main/$($Matches[3])"
    }
    return ''
}

# 检查 manifest（update.json 里的 manifestUrl 为空 = 没配更新源，直接返回未配置）
# 主地址拉不到时自动试 jsdelivr 备用地址，两个都失败才返回 error
function Invoke-ManifestCheck {
    $url = Get-ManifestUrl
    $res = @{ configured = $false; updateAvailable = $false; current = (Get-CurrentVersion); version = ''; downloadUrl = ''; notes = ''; error = '' }
    if ([string]::IsNullOrWhiteSpace($url)) { return $res }
    $res.configured = $true
    $tried = @()
    $errs = @()
    foreach ($tryUrl in @($url, (Get-ManifestMirrorUrl $url))) {
        if ([string]::IsNullOrWhiteSpace($tryUrl)) { continue }
        $tried += $tryUrl
        try {
            $resp = Invoke-WebRequest -Uri $tryUrl -UseBasicParsing -TimeoutSec 15 -Headers @{ 'User-Agent' = 'XiaoMengYun/1.0' }
            $m = $resp.Content | ConvertFrom-Json
            $res.version = [string]$m.version
            # 清单里的下载地址可能是 downloadUrl，也可能是 download_url（两种都认）
            $dl = $m.downloadUrl
            if ([string]::IsNullOrWhiteSpace([string]$dl)) { $dl = $m.download_url }
            $res.downloadUrl = [string]$dl
            $res.notes = [string]$m.notes
            if ($res.version -and (Compare-Versions $res.version $res.current) -gt 0) { $res.updateAvailable = $true }
            return $res
        } catch {
            $errs += "拉取 $tryUrl 失败：$($_.Exception.Message)"
        }
    }
    if ($tried.Count -gt 0) { $res.error = ($errs -join '；') }
    if ($tried.Count -gt 1) { $res.error = "主地址和备用地址都拉不到清单。" + $res.error }
    return $res
}

# 准备更新：把 zip 解压到 staging/new（系统临时文件夹下），校验里面有 小梦云.ps1；成功返回 @{ ok=$true }
function Prepare-Update($zipPath) {
    try {
        if (-not (Test-Path $UpdateTempDir)) { New-Item -ItemType Directory -Force -Path $UpdateTempDir | Out-Null }
        if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force -ErrorAction SilentlyContinue }
        New-Item -ItemType Directory -Force -Path $StagingDir | Out-Null
        $newDir = Join-Path $StagingDir 'new'
        New-Item -ItemType Directory -Force -Path $newDir | Out-Null
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $newDir)
        $root = $newDir
        if (-not (Test-Path (Join-Path $root '小梦云.ps1'))) {
            $sub = @(Get-ChildItem $root -Directory | Where-Object { Test-Path (Join-Path $_.FullName '小梦云.ps1') })
            if ($sub.Count -eq 1) { $root = $sub[0].FullName }
        }
        if (-not (Test-Path (Join-Path $root '小梦云.ps1'))) { return @{ ok = $false; error = '更新包里没有找到 小梦云.ps1' } }
        if ($root -ne $newDir) {
            $tmp = Join-Path $StagingDir 'new2'
            Move-Item $root $tmp
            Remove-Item $newDir -Recurse -Force -ErrorAction SilentlyContinue
            Move-Item $tmp $newDir
        }
        return @{ ok = $true }
    } catch {
        return @{ ok = $false; error = $_.Exception.Message }
    }
}

# 启动更新程序（独立进程），由调用方随后退出服务器
function Start-UpdaterAndExit {
    try {
        # 告诉 .bat：这是更新重启，退出后不用 pause，直接关窗口
        Set-Content -Path (Join-Path $PSScriptRoot 'update-pending.json') -Value '{"updating":true}' -Encoding UTF8
    } catch { }
    # -WindowStyle 只在 Windows 上有效（Linux 的 pwsh 不认这个参数，传了会直接报错）
    $winStyle = if ($IsWindows) { ' -WindowStyle Hidden' } else { '' }
    $argStr = "-NoProfile -ExecutionPolicy Bypass$winStyle -File `"$UpdaterFile`" -ServerPid $PID -StagingDir `"$StagingDir`" -InstallDir `"$PSScriptRoot`""
    foreach ($exe in @('pwsh', 'powershell.exe')) {
        try {
            if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
            $sp = @{ FilePath = $exe; ArgumentList = $argStr }
            if ($IsWindows) { $sp.WindowStyle = 'Hidden' }
            Start-Process @sp
            break
        } catch { }
    }
}

# 停掉属于小梦云的 cloudflared：上次关黑窗口留下的孤儿进程会一直占着安装文件夹，
# 导致删不掉/改不了名、更新拷不进文件（2026-11-11 用户实测 v1.0.2 的问题）。
# 只停命令行里带本工具端口（--url http://127.0.0.1:$Port）或路径在安装目录下的；
# 实在判断不了（比如拿不到命令行）就按进程名停，并写一句日志说明。
function Stop-OurCloudflared {
    try {
        foreach ($p in @(Get-Process -Name 'cloudflared' -ErrorAction SilentlyContinue)) {
            $why = ''
            try {
                $cmd = ''
                if (Get-Command Get-CimInstance -ErrorAction SilentlyContinue) {
                    $cmd = [string](Get-CimInstance Win32_Process -Filter "ProcessId=$($p.Id)" -ErrorAction SilentlyContinue).CommandLine
                }
                if ($cmd -and $cmd.Contains("127.0.0.1:$Port")) { $why = '命令行带本工具端口' }
                elseif ($cmd -and $cmd.ToLower().Contains($PSScriptRoot.ToLower())) { $why = '命令行在安装目录' }
                elseif ($cmd) { continue }
                else { $why = '拿不到命令行，按进程名停' }
            } catch { $why = '判断失败，按进程名停' }
            try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; Write-Host "  清掉残留的 cloudflared（PID $($p.Id)，$why）。" } catch { }
        }
    } catch { }
}

function Append-TakeLog($label, $type, $nickname) {
    $log = @(Read-JsonArray $TakeLogFile)
    $log += @{ label = $label; type = $type; nickname = $nickname; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
    if ($log.Count -gt 500) { $log = $log[($log.Count - 500)..($log.Count - 1)] }
    Write-JsonArray $TakeLogFile $log
}

# ---------------- 验证码拉取（含 15 秒服务端缓存） ----------------
function Get-CodeFromMail($html) {
    $code = ''
    $sender = ''
    $patterns = @(
        '验证码[:：]\s*([A-Za-z0-9]{4,10})',
        '验证代码[:：]?\s*(?:是|为)?\s*([A-Za-z0-9]{4,10})',
        'verification\s+code(?:\s+is)?\s*[:：]?\s*([A-Za-z0-9]{4,10})',
        '\bcode\s*[:：]\s*([A-Za-z0-9]{4,10})'
    )
    foreach ($pat in $patterns) {
        $m = [regex]::Match($html, $pat)
        if ($m.Success -and $m.Groups[1].Value -match '\d') { $code = $m.Groups[1].Value; break }
    }
    if (-not $code) {
        $text = [regex]::Replace($html, '<[^>]+>', ' ')
        $m = [regex]::Match($text, '(?i)\b(?=[A-Za-z0-9]*[A-Za-z])(?=[A-Za-z0-9]*\d)[A-Za-z0-9]{4,10}\b')
        if ($m.Success) { $code = $m.Value }
    }
    $m2 = [regex]::Match($html, '<div class="meta">([^<]*)</div>')
    if ($m2.Success) { $sender = $m2.Groups[1].Value.Trim() }
    return @{ code = $code; sender = $sender }
}

function Get-CodeFromSms($jsonText) {
    $code = ''
    try {
        $j = $jsonText | ConvertFrom-Json
        if ($null -ne $j.data -and $null -ne $j.data.code) { $code = [string]$j.data.code }
    } catch { }
    return @{ code = $code; sender = '' }
}

function Fetch-One($label, $url, $type) {
    $result = [ordered]@{ label = $label; code = ''; sender = ''; time = ''; ok = $false; error = '' }
    if ([string]::IsNullOrWhiteSpace($url)) { $result.error = '这个账号没有链接，取不到验证码（让老板补上链接再取）'; return $result }
    if ($script:FetchCache.ContainsKey($url)) {
        $e = $script:FetchCache[$url]
        if ((Get-Date) -lt $e.expires) { return $e.result }
        $script:FetchCache.Remove($url)
    }
    try {
        # 超时 8 秒：服务器是单线程，一次只处理一个请求；拉码太慢会卡住所有请求（比如手机开 /e/ 页一直白屏）
        $resp = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 8 -Headers @{ 'User-Agent' = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36' }
        if ($type -eq 'email') { $r = Get-CodeFromMail $resp.Content } else { $r = Get-CodeFromSms $resp.Content }
        $result.code = $r.code
        $result.sender = $r.sender
        $result.ok = $true
        if ($r.code) { $result.time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
        if ($result.ok) { $script:FetchCache[$url] = @{ result = $result; expires = (Get-Date).AddSeconds(15) } }
    } catch {
        $result.error = $_.Exception.Message
    }
    return $result
}

function Send-Response($stream, $contentType, $content) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
    $header = "HTTP/1.1 200 OK`r`nContent-Type: $contentType; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Headers: Content-Type, X-Auth-Token`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nConnection: close`r`n`r`n"
    $hbytes = [System.Text.Encoding]::UTF8.GetBytes($header)
    $stream.Write($hbytes, 0, $hbytes.Length)
    $stream.Write($bytes, 0, $bytes.Length)
    $stream.Flush()
}

# 二进制响应（图标等），可带缓存
function Send-BinaryResponse($stream, $contentType, $bytes, $cacheSeconds, $fileName) {
    $cache = ''
    if ($cacheSeconds -gt 0) { $cache = "Cache-Control: public, max-age=$cacheSeconds`r`n" }
    $disp = ''
    if (-not [string]::IsNullOrWhiteSpace([string]$fileName)) { $disp = "Content-Disposition: attachment; filename=`"$fileName`"`r`n" }
    $header = "HTTP/1.1 200 OK`r`nContent-Type: $contentType`r`nContent-Length: $($bytes.Length)`r`n$cache$disp`Access-Control-Allow-Origin: *`r`nConnection: close`r`n`r`n"
    $hbytes = [System.Text.Encoding]::UTF8.GetBytes($header)
    $stream.Write($hbytes, 0, $hbytes.Length)
    $stream.Write($bytes, 0, $bytes.Length)
    $stream.Flush()
}

function Get-LanIp {
    try {
        $addrs = [System.Net.Dns]::GetHostEntry([System.Net.Dns]::GetHostName()).AddressList
        foreach ($a in $addrs) {
            if ($a.AddressFamily -eq 'InterNetwork' -and -not [System.Net.IPAddress]::IsLoopback($a)) {
                $s = $a.ToString()
                if (-not $s.StartsWith('169.254.')) { return $s }
            }
        }
        foreach ($a in $addrs) {
            if ($a.AddressFamily -eq 'InterNetwork' -and -not [System.Net.IPAddress]::IsLoopback($a)) { return $a.ToString() }
        }
    } catch { }
    return ''
}

function Get-TunnelUrl {
    if (-not [string]::IsNullOrEmpty($script:PublicUrl)) { return $script:PublicUrl }
    if (((Get-Date) - $script:LastCfLogCheck).TotalSeconds -lt 1) { return '' }
    $script:LastCfLogCheck = Get-Date
    if (-not (Test-Path $CfLogFile)) { return '' }
    try {
        $txt = [System.IO.File]::ReadAllText($CfLogFile)
        $m = [regex]::Match($txt, 'https://[A-Za-z0-9-]+\.trycloudflare\.com')
        if ($m.Success) { $script:PublicUrl = $m.Value; return $script:PublicUrl }
    } catch { }
    return ''
}

# 注意：账号可反复用、不过期，所以不按时间清理已取出的记录。
# 取出的账号一直在 taken.json 里，直到工人点「释放」放回仓库；
# 万一有人取了不放，老板可以在 BOSS 端的取用记录里点「释放」强制收回。

$HtmlShell = @'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>小梦云</title>
<link rel="icon" type="image/png" href="/icon.png">
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon-512.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="小梦云">
<meta name="theme-color" content="#0b1220">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #0b1220; color: #e2e8f0; font: 14px/1.5 -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif; padding: 18px; }
  header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; flex-wrap: wrap; gap: 8px; }
  header h1 { font-size: 22px; }
  .badge-top { background: #14532d; border: 1px solid #166534; color: #86efac; border-radius: 999px; padding: 5px 12px; font-size: 12px; }
  .role-badge { background: #1d4ed8; color: #fff; font-size: 11px; border-radius: 4px; padding: 2px 8px; vertical-align: middle; letter-spacing: 1px; }
  .server-off { background: #7f1d1d; border: 1px solid #991b1b; color: #fca5a5; border-radius: 8px; padding: 10px 14px; margin-bottom: 16px; display: none; }
  .wrap { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; align-items: start; }
  @media (max-width: 900px) { .wrap { grid-template-columns: 1fr; } }
  .card { background: #111c2e; border: 1px solid #1e293b; border-radius: 12px; padding: 16px; margin-bottom: 16px; }
  .card h2 { font-size: 15px; display: flex; justify-content: space-between; align-items: center; }
  .tag { background: #1d4ed8; color: #fff; font-size: 10px; border-radius: 4px; padding: 2px 7px; letter-spacing: 1px; }
  .sub { color: #7c8aa0; font-size: 12px; margin: 6px 0 12px; }
  textarea { width: 100%; min-height: 130px; background: #0b1526; border: 1px solid #243449; color: #e2e8f0; border-radius: 8px; padding: 10px; font: 13px/1.6 Consolas, monospace; resize: vertical; }
  textarea::placeholder { color: #475569; }
  .btns { display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap; align-items: center; }
  .btns.big button { padding: 12px 24px; font-size: 15px; }
  button { background: #1d4ed8; color: #fff; border: none; border-radius: 7px; padding: 7px 14px; cursor: pointer; font-size: 13px; }
  button:hover { background: #2563eb; }
  button.ghost { background: #1e293b; color: #cbd5e1; border: 1px solid #334155; }
  button.ghost:hover { background: #273449; }
  button.danger { background: #7f1d1d; }
  button.danger:hover { background: #991b1b; }
  button:disabled { opacity: .45; cursor: not-allowed; }
  .note { color: #64748b; font-size: 12px; margin-top: 10px; }
  .note-warn { background: #422006; border: 1px solid #78350f; color: #fcd34d; border-radius: 8px; padding: 10px 14px; margin-bottom: 16px; font-size: 13px; }
  .share-box { background: #0b1526; border: 1px solid #243449; border-radius: 8px; padding: 12px; font: 14px/1.6 Consolas, monospace; word-break: break-all; color: #4ade80; }
  .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 16px; }
  @media (max-width: 700px) { .stats { grid-template-columns: repeat(2, 1fr); } }
  .stat { background: #111c2e; border: 1px solid #1e293b; border-radius: 10px; padding: 14px; }
  .stat b { font-size: 26px; display: block; }
  .stat span { color: #7c8aa0; font-size: 12px; }
  .panel-head { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; }
  .panel-head input[type=search] { background: #0b1526; border: 1px solid #243449; color: #e2e8f0; border-radius: 7px; padding: 7px 10px; width: 220px; font-size: 13px; }
  table { width: 100%; border-collapse: collapse; margin-top: 12px; }
  th { text-align: left; color: #7c8aa0; font-size: 12px; font-weight: normal; padding: 8px 6px; border-bottom: 1px solid #1e293b; }
  td { padding: 10px 6px; border-bottom: 1px solid #16233a; vertical-align: middle; }
  .code { color: #4ade80; font-weight: 700; font-size: 17px; letter-spacing: 2px; cursor: pointer; }
  .code.empty { color: #475569; letter-spacing: 4px; cursor: default; }
  /* 验证码三格子：TikTok / PixVerse / 可灵 各一格，各显示各平台的最新码，互不顶掉 */
  .code-cells { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 6px; min-width: 250px; }
  .code-cell { background: #0b1526; border: 1px solid #1e293b; border-radius: 8px; padding: 6px 8px; min-width: 0; }
  .code-cell.got { border-color: #166534; }
  .code-plat { font-size: 11px; color: #64748b; margin-bottom: 2px; white-space: nowrap; }
  .code-cell.got .code-plat { color: #86efac; }
  .code-cell .code { font-size: 16px; letter-spacing: 1px; }
  .code-time { color: #64748b; font-size: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .pill { background: #334155; color: #e2e8f0; border-radius: 999px; padding: 3px 10px; font-size: 12px; white-space: nowrap; }
  .pill.ok { background: #14532d; color: #86efac; }
  .pill.wait { background: #78350f; color: #fcd34d; }
  .pill.err { background: #7f1d1d; color: #fca5a5; }
  .rowbtns { display: flex; gap: 6px; flex-wrap: wrap; }
  .rowbtns button { padding: 5px 10px; font-size: 12px; }
  .empty-tip { color: #475569; text-align: center; padding: 26px 0; }
  .hint { margin-top: 10px; font-size: 12px; color: #f59e0b; display: none; }
  .paste-result { margin-top: 10px; font-size: 13px; display: none; }
  .paste-result select { background: #0b1526; border: 1px solid #243449; color: #e2e8f0; border-radius: 6px; padding: 6px; margin: 0 6px; max-width: 220px; }
  ol.help { padding-left: 20px; color: #94a3b8; font-size: 13px; }
  ol.help li { margin: 6px 0; }
  .toast { position: fixed; left: 50%; bottom: 26px; transform: translateX(-50%); background: #1e293b; border: 1px solid #334155; color: #e2e8f0; padding: 9px 16px; border-radius: 8px; font-size: 13px; display: none; z-index: 9; box-shadow: 0 6px 24px rgba(0,0,0,.5); }
  .label-copy { cursor: pointer; }
  .label-copy:hover { text-decoration: underline; color: #93c5fd; }
  .qr-modal { position: fixed; inset: 0; background: rgba(2,6,23,.92); display: none; align-items: center; justify-content: center; z-index: 30; padding: 16px; }
  .qr-modal.open { display: flex; }
  .qr-box { background: #0f172a; border: 1px solid #243449; border-radius: 14px; padding: 24px 22px; width: 380px; max-width: calc(100% - 24px); text-align: center; max-height: calc(100vh - 40px); overflow: auto; }
  .qr-box h3 { font-size: 17px; margin-bottom: 4px; }
  .qr-box p { color: #94a3b8; font-size: 13px; margin-bottom: 12px; }
  .qr-img { background: #fff; border-radius: 10px; padding: 12px; display: inline-block; line-height: 0; }
  .qr-img svg { display: block; }
  .qr-list { text-align: left; background: #0b1526; border: 1px solid #243449; border-radius: 8px; padding: 10px 12px; font-size: 12px; color: #94a3b8; max-height: 150px; overflow: auto; word-break: break-all; margin: 12px 0; white-space: pre-wrap; }
  .qr-hint { color: #f59e0b; font-size: 13px; margin: 10px 0 14px; }
  .auto { color: #4ade80; font-size: 12px; }
  .tabs { display: flex; gap: 4px; border-bottom: 1px solid #1e293b; margin-bottom: 14px; }
  .tabs button { background: none; border: none; color: #94a3b8; border-radius: 0; padding: 9px 16px; font-size: 14px; border-bottom: 2px solid transparent; margin-bottom: -1px; }
  .tabs button:hover { background: none; color: #e2e8f0; }
  .tabs button.on { color: #60a5fa; border-bottom-color: #2563eb; font-weight: 600; }
  .plat-ticks { display: flex; gap: 4px; margin-top: 6px; flex-wrap: wrap; }
  button.plat-tick { background: #0b1526; border: 1px solid #334155; color: #64748b; border-radius: 999px; padding: 2px 8px; font-size: 11px; }
  /* TikTok 是最主要的用途：勾加粗、加边，没用过时蓝色高亮（可领来注册 TikTok），用过是实心绿 */
  button.plat-tick.tk { font-weight: 700; border-width: 2px; }
  button.plat-tick.tk:not(.on) { border-color: #2563eb; color: #93c5fd; background: #172554; }
  button.plat-tick.on { background: #14532d; border-color: #166534; color: #86efac; }
  button.plat-tick:disabled { opacity: .5; cursor: default; }
  .lock { position: fixed; inset: 0; background: rgba(2,6,23,.94); display: flex; align-items: center; justify-content: center; z-index: 20; }
  .lock-box { background: #0f172a; border: 1px solid #243449; border-radius: 14px; padding: 28px 30px; width: 360px; text-align: center; }
  .lock-logo { width: 72px; height: 72px; border-radius: 18px; margin-bottom: 12px; }
  .head-logo { width: 30px; height: 30px; border-radius: 8px; vertical-align: middle; margin-right: 8px; }
  .lock-box h2 { font-size: 20px; margin-bottom: 6px; }
  .lock-box p { color: #94a3b8; font-size: 13px; margin-bottom: 16px; }
  .lock-box input { width: 100%; background: #0b1526; border: 1px solid #243449; color: #e2e8f0; border-radius: 8px; padding: 11px 12px; font-size: 15px; margin-bottom: 10px; }
  .lock-box .err { color: #fca5a5; font-size: 13px; min-height: 18px; margin: 2px 0 8px; }
  .lock-box .link { background: none; border: none; color: #60a5fa; font-size: 12px; cursor: pointer; margin-top: 10px; padding: 0; }
  .lock-box .link:hover { text-decoration: underline; }
  #lockRoleTabs button { flex: 1; }
  #lockRoleTabs button.on { background: #1d4ed8; color: #fff; border-color: #1d4ed8; }
  .txtin { background: #0b1526; border: 1px solid #243449; color: #e2e8f0; border-radius: 7px; padding: 7px 10px; font-size: 13px; }
  /* ---------- 手机竖屏（BOSS 手机后台）：字够大、按钮够大、不左右滑动 ---------- */
  @media (max-width: 640px) {
    body { padding: 12px; font-size: 15px; }
    header h1 { font-size: 20px; }
    .card { padding: 14px; }
    .card h2 { font-size: 16px; }
    .sub { font-size: 13px; }
    button { min-height: 44px; padding: 12px 18px; font-size: 15px; }
    .btns button { flex: 1 1 auto; }
    .rowbtns button { min-height: 40px; padding: 10px 14px; font-size: 14px; }
    button.plat-tick { min-height: 40px; padding: 9px 12px; font-size: 13px; }
    .tabs button { min-height: 44px; padding: 12px 14px; font-size: 15px; }
    textarea { font-size: 16px; padding: 12px; }
    .txtin, .panel-head input[type=search], select.txtin { font-size: 16px; padding: 12px; min-height: 44px; }
    .txtin { width: 100% !important; }
    .panel-head input[type=search] { width: 100%; }
    .lock-box { width: calc(100% - 24px); padding: 24px 20px; }
    .lock-box input { font-size: 16px; }
    .lock-box .link { font-size: 14px; padding: 10px; }
    .code { font-size: 20px; }
    .code-cells { min-width: 0; }
    .code-cells .code { font-size: 16px; }
    .stat b { font-size: 22px; }
    .share-box { font-size: 13px; }
    /* 表格改卡片：每行一张卡，不左右滑动 */
    table, tbody, tr, td { display: block; width: 100%; }
    thead { display: none; }
    table { margin-top: 8px; }
    tbody tr { background: #0f172a; border: 1px solid #1e293b; border-radius: 10px; margin-bottom: 10px; padding: 8px 12px; }
    tbody td { border: none; padding: 7px 0; }
    tbody td[data-label]::before { content: attr(data-label); display: block; color: #7c8aa0; font-size: 11px; margin-bottom: 2px; }
    tbody td:first-child { font-weight: 600; font-size: 15px; word-break: break-all; }
    .rowbtns { gap: 8px; }
  }
</style>
</head>
<body>
<div class="lock" id="lockScreen" style="display:none">
  <div class="lock-box">
    <img class="lock-logo" src="/icon.png" alt="小梦云" onerror="this.style.display='none'">
    <h2 id="lockTitle">小梦云</h2>
    <p id="lockSub"></p>
    <div id="lockRoleTabs" style="display:flex;gap:6px;margin-bottom:12px">
      <button class="ghost" id="tabBoss">我是老板</button>
      <button class="ghost" id="tabWorker">我是成员</button>
      <button class="ghost" id="tabRegister">注册账号</button>
    </div>
    <input id="lockNick" placeholder="昵称" autocomplete="off" style="display:none">
    <input type="password" id="lockPwOld" placeholder="原密码" autocomplete="off" style="display:none">
    <input type="password" id="lockPw1" placeholder="密码" autocomplete="off">
    <input type="password" id="lockPw2" placeholder="再输入一次确认" autocomplete="off" style="display:none">
    <input id="lockCode" placeholder="注册码（找老板要）" autocomplete="off" style="display:none">
    <div class="err" id="lockErr"></div>
    <button id="lockBtn" style="width:100%">登录</button>
    <button class="link" id="lockChange" style="display:none">修改密码</button>
    <button class="link" id="lockBack" style="display:none">返回登录</button>
  </div>
</div>
<div id="app"></div>
<div class="toast" id="toast"></div>
<div class="qr-modal" id="qrModal">
  <div class="qr-box">
    <h3 id="qrTitle">邮箱二维码</h3>
    <p id="qrSub"></p>
    <div class="qr-img" id="qrImg"></div>
    <div class="qr-list" id="qrList"></div>
    <div class="qr-hint">扫码后在手机页面点复制；想存备忘录：手机点浏览器分享 → 存储到备忘录</div>
    <button id="qrClose" style="width:100%">关闭</button>
  </div>
</div>
<script>
// ===== 二维码库 qrcode-generator v1.4.4 (MIT License, 本地嵌入，离线可用，不调任何外部接口) =====
//---------------------------------------------------------------------
//
// QR Code Generator for JavaScript
//
// Copyright (c) 2009 Kazuhiko Arase
//
// URL: http://www.d-project.com/
//
// Licensed under the MIT license:
//  http://www.opensource.org/licenses/mit-license.php
//
// The word 'QR Code' is registered trademark of
// DENSO WAVE INCORPORATED
//  http://www.denso-wave.com/qrcode/faqpatent-e.html
//
//---------------------------------------------------------------------

var qrcode = function() {

  //---------------------------------------------------------------------
  // qrcode
  //---------------------------------------------------------------------

  /**
   * qrcode
   * @param typeNumber 1 to 40
   * @param errorCorrectionLevel 'L','M','Q','H'
   */
  var qrcode = function(typeNumber, errorCorrectionLevel) {

    var PAD0 = 0xEC;
    var PAD1 = 0x11;

    var _typeNumber = typeNumber;
    var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
    var _modules = null;
    var _moduleCount = 0;
    var _dataCache = null;
    var _dataList = [];

    var _this = {};

    var makeImpl = function(test, maskPattern) {

      _moduleCount = _typeNumber * 4 + 17;
      _modules = function(moduleCount) {
        var modules = new Array(moduleCount);
        for (var row = 0; row < moduleCount; row += 1) {
          modules[row] = new Array(moduleCount);
          for (var col = 0; col < moduleCount; col += 1) {
            modules[row][col] = null;
          }
        }
        return modules;
      }(_moduleCount);

      setupPositionProbePattern(0, 0);
      setupPositionProbePattern(_moduleCount - 7, 0);
      setupPositionProbePattern(0, _moduleCount - 7);
      setupPositionAdjustPattern();
      setupTimingPattern();
      setupTypeInfo(test, maskPattern);

      if (_typeNumber >= 7) {
        setupTypeNumber(test);
      }

      if (_dataCache == null) {
        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
      }

      mapData(_dataCache, maskPattern);
    };

    var setupPositionProbePattern = function(row, col) {

      for (var r = -1; r <= 7; r += 1) {

        if (row + r <= -1 || _moduleCount <= row + r) continue;

        for (var c = -1; c <= 7; c += 1) {

          if (col + c <= -1 || _moduleCount <= col + c) continue;

          if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )
              || (0 <= c && c <= 6 && (r == 0 || r == 6) )
              || (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
            _modules[row + r][col + c] = true;
          } else {
            _modules[row + r][col + c] = false;
          }
        }
      }
    };

    var getBestMaskPattern = function() {

      var minLostPoint = 0;
      var pattern = 0;

      for (var i = 0; i < 8; i += 1) {

        makeImpl(true, i);

        var lostPoint = QRUtil.getLostPoint(_this);

        if (i == 0 || minLostPoint > lostPoint) {
          minLostPoint = lostPoint;
          pattern = i;
        }
      }

      return pattern;
    };

    var setupTimingPattern = function() {

      for (var r = 8; r < _moduleCount - 8; r += 1) {
        if (_modules[r][6] != null) {
          continue;
        }
        _modules[r][6] = (r % 2 == 0);
      }

      for (var c = 8; c < _moduleCount - 8; c += 1) {
        if (_modules[6][c] != null) {
          continue;
        }
        _modules[6][c] = (c % 2 == 0);
      }
    };

    var setupPositionAdjustPattern = function() {

      var pos = QRUtil.getPatternPosition(_typeNumber);

      for (var i = 0; i < pos.length; i += 1) {

        for (var j = 0; j < pos.length; j += 1) {

          var row = pos[i];
          var col = pos[j];

          if (_modules[row][col] != null) {
            continue;
          }

          for (var r = -2; r <= 2; r += 1) {

            for (var c = -2; c <= 2; c += 1) {

              if (r == -2 || r == 2 || c == -2 || c == 2
                  || (r == 0 && c == 0) ) {
                _modules[row + r][col + c] = true;
              } else {
                _modules[row + r][col + c] = false;
              }
            }
          }
        }
      }
    };

    var setupTypeNumber = function(test) {

      var bits = QRUtil.getBCHTypeNumber(_typeNumber);

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
      }

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
      }
    };

    var setupTypeInfo = function(test, maskPattern) {

      var data = (_errorCorrectionLevel << 3) | maskPattern;
      var bits = QRUtil.getBCHTypeInfo(data);

      // vertical
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 6) {
          _modules[i][8] = mod;
        } else if (i < 8) {
          _modules[i + 1][8] = mod;
        } else {
          _modules[_moduleCount - 15 + i][8] = mod;
        }
      }

      // horizontal
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 8) {
          _modules[8][_moduleCount - i - 1] = mod;
        } else if (i < 9) {
          _modules[8][15 - i - 1 + 1] = mod;
        } else {
          _modules[8][15 - i - 1] = mod;
        }
      }

      // fixed module
      _modules[_moduleCount - 8][8] = (!test);
    };

    var mapData = function(data, maskPattern) {

      var inc = -1;
      var row = _moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;
      var maskFunc = QRUtil.getMaskFunction(maskPattern);

      for (var col = _moduleCount - 1; col > 0; col -= 2) {

        if (col == 6) col -= 1;

        while (true) {

          for (var c = 0; c < 2; c += 1) {

            if (_modules[row][col - c] == null) {

              var dark = false;

              if (byteIndex < data.length) {
                dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);
              }

              var mask = maskFunc(row, col - c);

              if (mask) {
                dark = !dark;
              }

              _modules[row][col - c] = dark;
              bitIndex -= 1;

              if (bitIndex == -1) {
                byteIndex += 1;
                bitIndex = 7;
              }
            }
          }

          row += inc;

          if (row < 0 || _moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    };

    var createBytes = function(buffer, rsBlocks) {

      var offset = 0;

      var maxDcCount = 0;
      var maxEcCount = 0;

      var dcdata = new Array(rsBlocks.length);
      var ecdata = new Array(rsBlocks.length);

      for (var r = 0; r < rsBlocks.length; r += 1) {

        var dcCount = rsBlocks[r].dataCount;
        var ecCount = rsBlocks[r].totalCount - dcCount;

        maxDcCount = Math.max(maxDcCount, dcCount);
        maxEcCount = Math.max(maxEcCount, ecCount);

        dcdata[r] = new Array(dcCount);

        for (var i = 0; i < dcdata[r].length; i += 1) {
          dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];
        }
        offset += dcCount;

        var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
        var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);

        var modPoly = rawPoly.mod(rsPoly);
        ecdata[r] = new Array(rsPoly.getLength() - 1);
        for (var i = 0; i < ecdata[r].length; i += 1) {
          var modIndex = i + modPoly.getLength() - ecdata[r].length;
          ecdata[r][i] = (modIndex >= 0)? modPoly.getAt(modIndex) : 0;
        }
      }

      var totalCodeCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalCodeCount += rsBlocks[i].totalCount;
      }

      var data = new Array(totalCodeCount);
      var index = 0;

      for (var i = 0; i < maxDcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < dcdata[r].length) {
            data[index] = dcdata[r][i];
            index += 1;
          }
        }
      }

      for (var i = 0; i < maxEcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < ecdata[r].length) {
            data[index] = ecdata[r][i];
            index += 1;
          }
        }
      }

      return data;
    };

    var createData = function(typeNumber, errorCorrectionLevel, dataList) {

      var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);

      var buffer = qrBitBuffer();

      for (var i = 0; i < dataList.length; i += 1) {
        var data = dataList[i];
        buffer.put(data.getMode(), 4);
        buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
        data.write(buffer);
      }

      // calc num max data.
      var totalDataCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalDataCount += rsBlocks[i].dataCount;
      }

      if (buffer.getLengthInBits() > totalDataCount * 8) {
        throw 'code length overflow. ('
          + buffer.getLengthInBits()
          + '>'
          + totalDataCount * 8
          + ')';
      }

      // end code
      if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
        buffer.put(0, 4);
      }

      // padding
      while (buffer.getLengthInBits() % 8 != 0) {
        buffer.putBit(false);
      }

      // padding
      while (true) {

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD0, 8);

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD1, 8);
      }

      return createBytes(buffer, rsBlocks);
    };

    _this.addData = function(data, mode) {

      mode = mode || 'Byte';

      var newData = null;

      switch(mode) {
      case 'Numeric' :
        newData = qrNumber(data);
        break;
      case 'Alphanumeric' :
        newData = qrAlphaNum(data);
        break;
      case 'Byte' :
        newData = qr8BitByte(data);
        break;
      case 'Kanji' :
        newData = qrKanji(data);
        break;
      default :
        throw 'mode:' + mode;
      }

      _dataList.push(newData);
      _dataCache = null;
    };

    _this.isDark = function(row, col) {
      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
        throw row + ',' + col;
      }
      return _modules[row][col];
    };

    _this.getModuleCount = function() {
      return _moduleCount;
    };

    _this.make = function() {
      if (_typeNumber < 1) {
        var typeNumber = 1;

        for (; typeNumber < 40; typeNumber++) {
          var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);
          var buffer = qrBitBuffer();

          for (var i = 0; i < _dataList.length; i++) {
            var data = _dataList[i];
            buffer.put(data.getMode(), 4);
            buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
            data.write(buffer);
          }

          var totalDataCount = 0;
          for (var i = 0; i < rsBlocks.length; i++) {
            totalDataCount += rsBlocks[i].dataCount;
          }

          if (buffer.getLengthInBits() <= totalDataCount * 8) {
            break;
          }
        }

        _typeNumber = typeNumber;
      }

      makeImpl(false, getBestMaskPattern() );
    };

    _this.createTableTag = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var qrHtml = '';

      qrHtml += '<table style="';
      qrHtml += ' border-width: 0px; border-style: none;';
      qrHtml += ' border-collapse: collapse;';
      qrHtml += ' padding: 0px; margin: ' + margin + 'px;';
      qrHtml += '">';
      qrHtml += '<tbody>';

      for (var r = 0; r < _this.getModuleCount(); r += 1) {

        qrHtml += '<tr>';

        for (var c = 0; c < _this.getModuleCount(); c += 1) {
          qrHtml += '<td style="';
          qrHtml += ' border-width: 0px; border-style: none;';
          qrHtml += ' border-collapse: collapse;';
          qrHtml += ' padding: 0px; margin: 0px;';
          qrHtml += ' width: ' + cellSize + 'px;';
          qrHtml += ' height: ' + cellSize + 'px;';
          qrHtml += ' background-color: ';
          qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';
          qrHtml += ';';
          qrHtml += '"/>';
        }

        qrHtml += '</tr>';
      }

      qrHtml += '</tbody>';
      qrHtml += '</table>';

      return qrHtml;
    };

    _this.createSvgTag = function(cellSize, margin, alt, title) {

      var opts = {};
      if (typeof arguments[0] == 'object') {
        // Called by options.
        opts = arguments[0];
        // overwrite cellSize and margin.
        cellSize = opts.cellSize;
        margin = opts.margin;
        alt = opts.alt;
        title = opts.title;
      }

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      // Compose alt property surrogate
      alt = (typeof alt === 'string') ? {text: alt} : alt || {};
      alt.text = alt.text || null;
      alt.id = (alt.text) ? alt.id || 'qrcode-description' : null;

      // Compose title property surrogate
      title = (typeof title === 'string') ? {text: title} : title || {};
      title.text = title.text || null;
      title.id = (title.text) ? title.id || 'qrcode-title' : null;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var c, mc, r, mr, qrSvg='', rect;

      rect = 'l' + cellSize + ',0 0,' + cellSize +
        ' -' + cellSize + ',0 0,-' + cellSize + 'z ';

      qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
      qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : '';
      qrSvg += ' viewBox="0 0 ' + size + ' ' + size + '" ';
      qrSvg += ' preserveAspectRatio="xMinYMin meet"';
      qrSvg += (title.text || alt.text) ? ' role="img" aria-labelledby="' +
          escapeXml([title.id, alt.id].join(' ').trim() ) + '"' : '';
      qrSvg += '>';
      qrSvg += (title.text) ? '<title id="' + escapeXml(title.id) + '">' +
          escapeXml(title.text) + '</title>' : '';
      qrSvg += (alt.text) ? '<description id="' + escapeXml(alt.id) + '">' +
          escapeXml(alt.text) + '</description>' : '';
      qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
      qrSvg += '<path d="';

      for (r = 0; r < _this.getModuleCount(); r += 1) {
        mr = r * cellSize + margin;
        for (c = 0; c < _this.getModuleCount(); c += 1) {
          if (_this.isDark(r, c) ) {
            mc = c*cellSize+margin;
            qrSvg += 'M' + mc + ',' + mr + rect;
          }
        }
      }

      qrSvg += '" stroke="transparent" fill="black"/>';
      qrSvg += '</svg>';

      return qrSvg;
    };

    _this.createDataURL = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      return createDataURL(size, size, function(x, y) {
        if (min <= x && x < max && min <= y && y < max) {
          var c = Math.floor( (x - min) / cellSize);
          var r = Math.floor( (y - min) / cellSize);
          return _this.isDark(r, c)? 0 : 1;
        } else {
          return 1;
        }
      } );
    };

    _this.createImgTag = function(cellSize, margin, alt) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;

      var img = '';
      img += '<img';
      img += '\u0020src="';
      img += _this.createDataURL(cellSize, margin);
      img += '"';
      img += '\u0020width="';
      img += size;
      img += '"';
      img += '\u0020height="';
      img += size;
      img += '"';
      if (alt) {
        img += '\u0020alt="';
        img += escapeXml(alt);
        img += '"';
      }
      img += '/>';

      return img;
    };

    var escapeXml = function(s) {
      var escaped = '';
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charAt(i);
        switch(c) {
        case '<': escaped += '&lt;'; break;
        case '>': escaped += '&gt;'; break;
        case '&': escaped += '&amp;'; break;
        case '"': escaped += '&quot;'; break;
        default : escaped += c; break;
        }
      }
      return escaped;
    };

    var _createHalfASCII = function(margin) {
      var cellSize = 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r1, r2, p;

      var blocks = {
        '██': '█',
        '█ ': '▀',
        ' █': '▄',
        '  ': ' '
      };

      var blocksLastLineNoMargin = {
        '██': '▀',
        '█ ': '▀',
        ' █': ' ',
        '  ': ' '
      };

      var ascii = '';
      for (y = 0; y < size; y += 2) {
        r1 = Math.floor((y - min) / cellSize);
        r2 = Math.floor((y + 1 - min) / cellSize);
        for (x = 0; x < size; x += 1) {
          p = '█';

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
            p = ' ';
          }

          if (min <= x && x < max && min <= y+1 && y+1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
            p += ' ';
          }
          else {
            p += '█';
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          ascii += (margin < 1 && y+1 >= max) ? blocksLastLineNoMargin[p] : blocks[p];
        }

        ascii += '\n';
      }

      if (size % 2 && margin > 0) {
        return ascii.substring(0, ascii.length - size - 1) + Array(size+1).join('▀');
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.createASCII = function(cellSize, margin) {
      cellSize = cellSize || 1;

      if (cellSize < 2) {
        return _createHalfASCII(margin);
      }

      cellSize -= 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r, p;

      var white = Array(cellSize+1).join('██');
      var black = Array(cellSize+1).join('  ');

      var ascii = '';
      var line = '';
      for (y = 0; y < size; y += 1) {
        r = Math.floor( (y - min) / cellSize);
        line = '';
        for (x = 0; x < size; x += 1) {
          p = 1;

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
            p = 0;
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          line += p ? white : black;
        }

        for (r = 0; r < cellSize; r += 1) {
          ascii += line + '\n';
        }
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.renderTo2dContext = function(context, cellSize) {
      cellSize = cellSize || 2;
      var length = _this.getModuleCount();
      for (var row = 0; row < length; row++) {
        for (var col = 0; col < length; col++) {
          context.fillStyle = _this.isDark(row, col) ? 'black' : 'white';
          context.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);
        }
      }
    }

    return _this;
  };

  //---------------------------------------------------------------------
  // qrcode.stringToBytes
  //---------------------------------------------------------------------

  qrcode.stringToBytesFuncs = {
    'default' : function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        bytes.push(c & 0xff);
      }
      return bytes;
    }
  };

  qrcode.stringToBytes = qrcode.stringToBytesFuncs['default'];

  //---------------------------------------------------------------------
  // qrcode.createStringToBytes
  //---------------------------------------------------------------------

  /**
   * @param unicodeData base64 string of byte array.
   * [16bit Unicode],[16bit Bytes], ...
   * @param numChars
   */
  qrcode.createStringToBytes = function(unicodeData, numChars) {

    // create conversion map.

    var unicodeMap = function() {

      var bin = base64DecodeInputStream(unicodeData);
      var read = function() {
        var b = bin.read();
        if (b == -1) throw 'eof';
        return b;
      };

      var count = 0;
      var unicodeMap = {};
      while (true) {
        var b0 = bin.read();
        if (b0 == -1) break;
        var b1 = read();
        var b2 = read();
        var b3 = read();
        var k = String.fromCharCode( (b0 << 8) | b1);
        var v = (b2 << 8) | b3;
        unicodeMap[k] = v;
        count += 1;
      }
      if (count != numChars) {
        throw count + ' != ' + numChars;
      }

      return unicodeMap;
    }();

    var unknownChar = '?'.charCodeAt(0);

    return function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        if (c < 128) {
          bytes.push(c);
        } else {
          var b = unicodeMap[s.charAt(i)];
          if (typeof b == 'number') {
            if ( (b & 0xff) == b) {
              // 1byte
              bytes.push(b);
            } else {
              // 2bytes
              bytes.push(b >>> 8);
              bytes.push(b & 0xff);
            }
          } else {
            bytes.push(unknownChar);
          }
        }
      }
      return bytes;
    };
  };

  //---------------------------------------------------------------------
  // QRMode
  //---------------------------------------------------------------------

  var QRMode = {
    MODE_NUMBER :    1 << 0,
    MODE_ALPHA_NUM : 1 << 1,
    MODE_8BIT_BYTE : 1 << 2,
    MODE_KANJI :     1 << 3
  };

  //---------------------------------------------------------------------
  // QRErrorCorrectionLevel
  //---------------------------------------------------------------------

  var QRErrorCorrectionLevel = {
    L : 1,
    M : 0,
    Q : 3,
    H : 2
  };

  //---------------------------------------------------------------------
  // QRMaskPattern
  //---------------------------------------------------------------------

  var QRMaskPattern = {
    PATTERN000 : 0,
    PATTERN001 : 1,
    PATTERN010 : 2,
    PATTERN011 : 3,
    PATTERN100 : 4,
    PATTERN101 : 5,
    PATTERN110 : 6,
    PATTERN111 : 7
  };

  //---------------------------------------------------------------------
  // QRUtil
  //---------------------------------------------------------------------

  var QRUtil = function() {

    var PATTERN_POSITION_TABLE = [
      [],
      [6, 18],
      [6, 22],
      [6, 26],
      [6, 30],
      [6, 34],
      [6, 22, 38],
      [6, 24, 42],
      [6, 26, 46],
      [6, 28, 50],
      [6, 30, 54],
      [6, 32, 58],
      [6, 34, 62],
      [6, 26, 46, 66],
      [6, 26, 48, 70],
      [6, 26, 50, 74],
      [6, 30, 54, 78],
      [6, 30, 56, 82],
      [6, 30, 58, 86],
      [6, 34, 62, 90],
      [6, 28, 50, 72, 94],
      [6, 26, 50, 74, 98],
      [6, 30, 54, 78, 102],
      [6, 28, 54, 80, 106],
      [6, 32, 58, 84, 110],
      [6, 30, 58, 86, 114],
      [6, 34, 62, 90, 118],
      [6, 26, 50, 74, 98, 122],
      [6, 30, 54, 78, 102, 126],
      [6, 26, 52, 78, 104, 130],
      [6, 30, 56, 82, 108, 134],
      [6, 34, 60, 86, 112, 138],
      [6, 30, 58, 86, 114, 142],
      [6, 34, 62, 90, 118, 146],
      [6, 30, 54, 78, 102, 126, 150],
      [6, 24, 50, 76, 102, 128, 154],
      [6, 28, 54, 80, 106, 132, 158],
      [6, 32, 58, 84, 110, 136, 162],
      [6, 26, 54, 82, 110, 138, 166],
      [6, 30, 58, 86, 114, 142, 170]
    ];
    var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);
    var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);
    var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);

    var _this = {};

    var getBCHDigit = function(data) {
      var digit = 0;
      while (data != 0) {
        digit += 1;
        data >>>= 1;
      }
      return digit;
    };

    _this.getBCHTypeInfo = function(data) {
      var d = data << 10;
      while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
        d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );
      }
      return ( (data << 10) | d) ^ G15_MASK;
    };

    _this.getBCHTypeNumber = function(data) {
      var d = data << 12;
      while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
        d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );
      }
      return (data << 12) | d;
    };

    _this.getPatternPosition = function(typeNumber) {
      return PATTERN_POSITION_TABLE[typeNumber - 1];
    };

    _this.getMaskFunction = function(maskPattern) {

      switch (maskPattern) {

      case QRMaskPattern.PATTERN000 :
        return function(i, j) { return (i + j) % 2 == 0; };
      case QRMaskPattern.PATTERN001 :
        return function(i, j) { return i % 2 == 0; };
      case QRMaskPattern.PATTERN010 :
        return function(i, j) { return j % 3 == 0; };
      case QRMaskPattern.PATTERN011 :
        return function(i, j) { return (i + j) % 3 == 0; };
      case QRMaskPattern.PATTERN100 :
        return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };
      case QRMaskPattern.PATTERN101 :
        return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };
      case QRMaskPattern.PATTERN110 :
        return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };
      case QRMaskPattern.PATTERN111 :
        return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };

      default :
        throw 'bad maskPattern:' + maskPattern;
      }
    };

    _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
      var a = qrPolynomial([1], 0);
      for (var i = 0; i < errorCorrectLength; i += 1) {
        a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );
      }
      return a;
    };

    _this.getLengthInBits = function(mode, type) {

      if (1 <= type && type < 10) {

        // 1 - 9

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 10;
        case QRMode.MODE_ALPHA_NUM : return 9;
        case QRMode.MODE_8BIT_BYTE : return 8;
        case QRMode.MODE_KANJI     : return 8;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 27) {

        // 10 - 26

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 12;
        case QRMode.MODE_ALPHA_NUM : return 11;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 10;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 41) {

        // 27 - 40

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 14;
        case QRMode.MODE_ALPHA_NUM : return 13;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 12;
        default :
          throw 'mode:' + mode;
        }

      } else {
        throw 'type:' + type;
      }
    };

    _this.getLostPoint = function(qrcode) {

      var moduleCount = qrcode.getModuleCount();

      var lostPoint = 0;

      // LEVEL1

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount; col += 1) {

          var sameCount = 0;
          var dark = qrcode.isDark(row, col);

          for (var r = -1; r <= 1; r += 1) {

            if (row + r < 0 || moduleCount <= row + r) {
              continue;
            }

            for (var c = -1; c <= 1; c += 1) {

              if (col + c < 0 || moduleCount <= col + c) {
                continue;
              }

              if (r == 0 && c == 0) {
                continue;
              }

              if (dark == qrcode.isDark(row + r, col + c) ) {
                sameCount += 1;
              }
            }
          }

          if (sameCount > 5) {
            lostPoint += (3 + sameCount - 5);
          }
        }
      };

      // LEVEL2

      for (var row = 0; row < moduleCount - 1; row += 1) {
        for (var col = 0; col < moduleCount - 1; col += 1) {
          var count = 0;
          if (qrcode.isDark(row, col) ) count += 1;
          if (qrcode.isDark(row + 1, col) ) count += 1;
          if (qrcode.isDark(row, col + 1) ) count += 1;
          if (qrcode.isDark(row + 1, col + 1) ) count += 1;
          if (count == 0 || count == 4) {
            lostPoint += 3;
          }
        }
      }

      // LEVEL3

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount - 6; col += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row, col + 1)
              &&  qrcode.isDark(row, col + 2)
              &&  qrcode.isDark(row, col + 3)
              &&  qrcode.isDark(row, col + 4)
              && !qrcode.isDark(row, col + 5)
              &&  qrcode.isDark(row, col + 6) ) {
            lostPoint += 40;
          }
        }
      }

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount - 6; row += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row + 1, col)
              &&  qrcode.isDark(row + 2, col)
              &&  qrcode.isDark(row + 3, col)
              &&  qrcode.isDark(row + 4, col)
              && !qrcode.isDark(row + 5, col)
              &&  qrcode.isDark(row + 6, col) ) {
            lostPoint += 40;
          }
        }
      }

      // LEVEL4

      var darkCount = 0;

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount; row += 1) {
          if (qrcode.isDark(row, col) ) {
            darkCount += 1;
          }
        }
      }

      var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
      lostPoint += ratio * 10;

      return lostPoint;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // QRMath
  //---------------------------------------------------------------------

  var QRMath = function() {

    var EXP_TABLE = new Array(256);
    var LOG_TABLE = new Array(256);

    // initialize tables
    for (var i = 0; i < 8; i += 1) {
      EXP_TABLE[i] = 1 << i;
    }
    for (var i = 8; i < 256; i += 1) {
      EXP_TABLE[i] = EXP_TABLE[i - 4]
        ^ EXP_TABLE[i - 5]
        ^ EXP_TABLE[i - 6]
        ^ EXP_TABLE[i - 8];
    }
    for (var i = 0; i < 255; i += 1) {
      LOG_TABLE[EXP_TABLE[i] ] = i;
    }

    var _this = {};

    _this.glog = function(n) {

      if (n < 1) {
        throw 'glog(' + n + ')';
      }

      return LOG_TABLE[n];
    };

    _this.gexp = function(n) {

      while (n < 0) {
        n += 255;
      }

      while (n >= 256) {
        n -= 255;
      }

      return EXP_TABLE[n];
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrPolynomial
  //---------------------------------------------------------------------

  function qrPolynomial(num, shift) {

    if (typeof num.length == 'undefined') {
      throw num.length + '/' + shift;
    }

    var _num = function() {
      var offset = 0;
      while (offset < num.length && num[offset] == 0) {
        offset += 1;
      }
      var _num = new Array(num.length - offset + shift);
      for (var i = 0; i < num.length - offset; i += 1) {
        _num[i] = num[i + offset];
      }
      return _num;
    }();

    var _this = {};

    _this.getAt = function(index) {
      return _num[index];
    };

    _this.getLength = function() {
      return _num.length;
    };

    _this.multiply = function(e) {

      var num = new Array(_this.getLength() + e.getLength() - 1);

      for (var i = 0; i < _this.getLength(); i += 1) {
        for (var j = 0; j < e.getLength(); j += 1) {
          num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i) ) + QRMath.glog(e.getAt(j) ) );
        }
      }

      return qrPolynomial(num, 0);
    };

    _this.mod = function(e) {

      if (_this.getLength() - e.getLength() < 0) {
        return _this;
      }

      var ratio = QRMath.glog(_this.getAt(0) ) - QRMath.glog(e.getAt(0) );

      var num = new Array(_this.getLength() );
      for (var i = 0; i < _this.getLength(); i += 1) {
        num[i] = _this.getAt(i);
      }

      for (var i = 0; i < e.getLength(); i += 1) {
        num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i) ) + ratio);
      }

      // recursive call
      return qrPolynomial(num, 0).mod(e);
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // QRRSBlock
  //---------------------------------------------------------------------

  var QRRSBlock = function() {

    var RS_BLOCK_TABLE = [

      // L
      // M
      // Q
      // H

      // 1
      [1, 26, 19],
      [1, 26, 16],
      [1, 26, 13],
      [1, 26, 9],

      // 2
      [1, 44, 34],
      [1, 44, 28],
      [1, 44, 22],
      [1, 44, 16],

      // 3
      [1, 70, 55],
      [1, 70, 44],
      [2, 35, 17],
      [2, 35, 13],

      // 4
      [1, 100, 80],
      [2, 50, 32],
      [2, 50, 24],
      [4, 25, 9],

      // 5
      [1, 134, 108],
      [2, 67, 43],
      [2, 33, 15, 2, 34, 16],
      [2, 33, 11, 2, 34, 12],

      // 6
      [2, 86, 68],
      [4, 43, 27],
      [4, 43, 19],
      [4, 43, 15],

      // 7
      [2, 98, 78],
      [4, 49, 31],
      [2, 32, 14, 4, 33, 15],
      [4, 39, 13, 1, 40, 14],

      // 8
      [2, 121, 97],
      [2, 60, 38, 2, 61, 39],
      [4, 40, 18, 2, 41, 19],
      [4, 40, 14, 2, 41, 15],

      // 9
      [2, 146, 116],
      [3, 58, 36, 2, 59, 37],
      [4, 36, 16, 4, 37, 17],
      [4, 36, 12, 4, 37, 13],

      // 10
      [2, 86, 68, 2, 87, 69],
      [4, 69, 43, 1, 70, 44],
      [6, 43, 19, 2, 44, 20],
      [6, 43, 15, 2, 44, 16],

      // 11
      [4, 101, 81],
      [1, 80, 50, 4, 81, 51],
      [4, 50, 22, 4, 51, 23],
      [3, 36, 12, 8, 37, 13],

      // 12
      [2, 116, 92, 2, 117, 93],
      [6, 58, 36, 2, 59, 37],
      [4, 46, 20, 6, 47, 21],
      [7, 42, 14, 4, 43, 15],

      // 13
      [4, 133, 107],
      [8, 59, 37, 1, 60, 38],
      [8, 44, 20, 4, 45, 21],
      [12, 33, 11, 4, 34, 12],

      // 14
      [3, 145, 115, 1, 146, 116],
      [4, 64, 40, 5, 65, 41],
      [11, 36, 16, 5, 37, 17],
      [11, 36, 12, 5, 37, 13],

      // 15
      [5, 109, 87, 1, 110, 88],
      [5, 65, 41, 5, 66, 42],
      [5, 54, 24, 7, 55, 25],
      [11, 36, 12, 7, 37, 13],

      // 16
      [5, 122, 98, 1, 123, 99],
      [7, 73, 45, 3, 74, 46],
      [15, 43, 19, 2, 44, 20],
      [3, 45, 15, 13, 46, 16],

      // 17
      [1, 135, 107, 5, 136, 108],
      [10, 74, 46, 1, 75, 47],
      [1, 50, 22, 15, 51, 23],
      [2, 42, 14, 17, 43, 15],

      // 18
      [5, 150, 120, 1, 151, 121],
      [9, 69, 43, 4, 70, 44],
      [17, 50, 22, 1, 51, 23],
      [2, 42, 14, 19, 43, 15],

      // 19
      [3, 141, 113, 4, 142, 114],
      [3, 70, 44, 11, 71, 45],
      [17, 47, 21, 4, 48, 22],
      [9, 39, 13, 16, 40, 14],

      // 20
      [3, 135, 107, 5, 136, 108],
      [3, 67, 41, 13, 68, 42],
      [15, 54, 24, 5, 55, 25],
      [15, 43, 15, 10, 44, 16],

      // 21
      [4, 144, 116, 4, 145, 117],
      [17, 68, 42],
      [17, 50, 22, 6, 51, 23],
      [19, 46, 16, 6, 47, 17],

      // 22
      [2, 139, 111, 7, 140, 112],
      [17, 74, 46],
      [7, 54, 24, 16, 55, 25],
      [34, 37, 13],

      // 23
      [4, 151, 121, 5, 152, 122],
      [4, 75, 47, 14, 76, 48],
      [11, 54, 24, 14, 55, 25],
      [16, 45, 15, 14, 46, 16],

      // 24
      [6, 147, 117, 4, 148, 118],
      [6, 73, 45, 14, 74, 46],
      [11, 54, 24, 16, 55, 25],
      [30, 46, 16, 2, 47, 17],

      // 25
      [8, 132, 106, 4, 133, 107],
      [8, 75, 47, 13, 76, 48],
      [7, 54, 24, 22, 55, 25],
      [22, 45, 15, 13, 46, 16],

      // 26
      [10, 142, 114, 2, 143, 115],
      [19, 74, 46, 4, 75, 47],
      [28, 50, 22, 6, 51, 23],
      [33, 46, 16, 4, 47, 17],

      // 27
      [8, 152, 122, 4, 153, 123],
      [22, 73, 45, 3, 74, 46],
      [8, 53, 23, 26, 54, 24],
      [12, 45, 15, 28, 46, 16],

      // 28
      [3, 147, 117, 10, 148, 118],
      [3, 73, 45, 23, 74, 46],
      [4, 54, 24, 31, 55, 25],
      [11, 45, 15, 31, 46, 16],

      // 29
      [7, 146, 116, 7, 147, 117],
      [21, 73, 45, 7, 74, 46],
      [1, 53, 23, 37, 54, 24],
      [19, 45, 15, 26, 46, 16],

      // 30
      [5, 145, 115, 10, 146, 116],
      [19, 75, 47, 10, 76, 48],
      [15, 54, 24, 25, 55, 25],
      [23, 45, 15, 25, 46, 16],

      // 31
      [13, 145, 115, 3, 146, 116],
      [2, 74, 46, 29, 75, 47],
      [42, 54, 24, 1, 55, 25],
      [23, 45, 15, 28, 46, 16],

      // 32
      [17, 145, 115],
      [10, 74, 46, 23, 75, 47],
      [10, 54, 24, 35, 55, 25],
      [19, 45, 15, 35, 46, 16],

      // 33
      [17, 145, 115, 1, 146, 116],
      [14, 74, 46, 21, 75, 47],
      [29, 54, 24, 19, 55, 25],
      [11, 45, 15, 46, 46, 16],

      // 34
      [13, 145, 115, 6, 146, 116],
      [14, 74, 46, 23, 75, 47],
      [44, 54, 24, 7, 55, 25],
      [59, 46, 16, 1, 47, 17],

      // 35
      [12, 151, 121, 7, 152, 122],
      [12, 75, 47, 26, 76, 48],
      [39, 54, 24, 14, 55, 25],
      [22, 45, 15, 41, 46, 16],

      // 36
      [6, 151, 121, 14, 152, 122],
      [6, 75, 47, 34, 76, 48],
      [46, 54, 24, 10, 55, 25],
      [2, 45, 15, 64, 46, 16],

      // 37
      [17, 152, 122, 4, 153, 123],
      [29, 74, 46, 14, 75, 47],
      [49, 54, 24, 10, 55, 25],
      [24, 45, 15, 46, 46, 16],

      // 38
      [4, 152, 122, 18, 153, 123],
      [13, 74, 46, 32, 75, 47],
      [48, 54, 24, 14, 55, 25],
      [42, 45, 15, 32, 46, 16],

      // 39
      [20, 147, 117, 4, 148, 118],
      [40, 75, 47, 7, 76, 48],
      [43, 54, 24, 22, 55, 25],
      [10, 45, 15, 67, 46, 16],

      // 40
      [19, 148, 118, 6, 149, 119],
      [18, 75, 47, 31, 76, 48],
      [34, 54, 24, 34, 55, 25],
      [20, 45, 15, 61, 46, 16]
    ];

    var qrRSBlock = function(totalCount, dataCount) {
      var _this = {};
      _this.totalCount = totalCount;
      _this.dataCount = dataCount;
      return _this;
    };

    var _this = {};

    var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {

      switch(errorCorrectionLevel) {
      case QRErrorCorrectionLevel.L :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
      case QRErrorCorrectionLevel.M :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
      case QRErrorCorrectionLevel.Q :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
      case QRErrorCorrectionLevel.H :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
      default :
        return undefined;
      }
    };

    _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {

      var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);

      if (typeof rsBlock == 'undefined') {
        throw 'bad rs block @ typeNumber:' + typeNumber +
            '/errorCorrectionLevel:' + errorCorrectionLevel;
      }

      var length = rsBlock.length / 3;

      var list = [];

      for (var i = 0; i < length; i += 1) {

        var count = rsBlock[i * 3 + 0];
        var totalCount = rsBlock[i * 3 + 1];
        var dataCount = rsBlock[i * 3 + 2];

        for (var j = 0; j < count; j += 1) {
          list.push(qrRSBlock(totalCount, dataCount) );
        }
      }

      return list;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrBitBuffer
  //---------------------------------------------------------------------

  var qrBitBuffer = function() {

    var _buffer = [];
    var _length = 0;

    var _this = {};

    _this.getBuffer = function() {
      return _buffer;
    };

    _this.getAt = function(index) {
      var bufIndex = Math.floor(index / 8);
      return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
    };

    _this.put = function(num, length) {
      for (var i = 0; i < length; i += 1) {
        _this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
      }
    };

    _this.getLengthInBits = function() {
      return _length;
    };

    _this.putBit = function(bit) {

      var bufIndex = Math.floor(_length / 8);
      if (_buffer.length <= bufIndex) {
        _buffer.push(0);
      }

      if (bit) {
        _buffer[bufIndex] |= (0x80 >>> (_length % 8) );
      }

      _length += 1;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrNumber
  //---------------------------------------------------------------------

  var qrNumber = function(data) {

    var _mode = QRMode.MODE_NUMBER;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var data = _data;

      var i = 0;

      while (i + 2 < data.length) {
        buffer.put(strToNum(data.substring(i, i + 3) ), 10);
        i += 3;
      }

      if (i < data.length) {
        if (data.length - i == 1) {
          buffer.put(strToNum(data.substring(i, i + 1) ), 4);
        } else if (data.length - i == 2) {
          buffer.put(strToNum(data.substring(i, i + 2) ), 7);
        }
      }
    };

    var strToNum = function(s) {
      var num = 0;
      for (var i = 0; i < s.length; i += 1) {
        num = num * 10 + chatToNum(s.charAt(i) );
      }
      return num;
    };

    var chatToNum = function(c) {
      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      }
      throw 'illegal char :' + c;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrAlphaNum
  //---------------------------------------------------------------------

  var qrAlphaNum = function(data) {

    var _mode = QRMode.MODE_ALPHA_NUM;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var s = _data;

      var i = 0;

      while (i + 1 < s.length) {
        buffer.put(
          getCode(s.charAt(i) ) * 45 +
          getCode(s.charAt(i + 1) ), 11);
        i += 2;
      }

      if (i < s.length) {
        buffer.put(getCode(s.charAt(i) ), 6);
      }
    };

    var getCode = function(c) {

      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      } else if ('A' <= c && c <= 'Z') {
        return c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;
      } else {
        switch (c) {
        case ' ' : return 36;
        case '$' : return 37;
        case '%' : return 38;
        case '*' : return 39;
        case '+' : return 40;
        case '-' : return 41;
        case '.' : return 42;
        case '/' : return 43;
        case ':' : return 44;
        default :
          throw 'illegal char :' + c;
        }
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qr8BitByte
  //---------------------------------------------------------------------

  var qr8BitByte = function(data) {

    var _mode = QRMode.MODE_8BIT_BYTE;
    var _data = data;
    var _bytes = qrcode.stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _bytes.length;
    };

    _this.write = function(buffer) {
      for (var i = 0; i < _bytes.length; i += 1) {
        buffer.put(_bytes[i], 8);
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrKanji
  //---------------------------------------------------------------------

  var qrKanji = function(data) {

    var _mode = QRMode.MODE_KANJI;
    var _data = data;

    var stringToBytes = qrcode.stringToBytesFuncs['SJIS'];
    if (!stringToBytes) {
      throw 'sjis not supported.';
    }
    !function(c, code) {
      // self test for sjis support.
      var test = stringToBytes(c);
      if (test.length != 2 || ( (test[0] << 8) | test[1]) != code) {
        throw 'sjis not supported.';
      }
    }('\u53cb', 0x9746);

    var _bytes = stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return ~~(_bytes.length / 2);
    };

    _this.write = function(buffer) {

      var data = _bytes;

      var i = 0;

      while (i + 1 < data.length) {

        var c = ( (0xff & data[i]) << 8) | (0xff & data[i + 1]);

        if (0x8140 <= c && c <= 0x9FFC) {
          c -= 0x8140;
        } else if (0xE040 <= c && c <= 0xEBBF) {
          c -= 0xC140;
        } else {
          throw 'illegal char at ' + (i + 1) + '/' + c;
        }

        c = ( (c >>> 8) & 0xff) * 0xC0 + (c & 0xff);

        buffer.put(c, 13);

        i += 2;
      }

      if (i < data.length) {
        throw 'illegal char at ' + (i + 1);
      }
    };

    return _this;
  };

  //=====================================================================
  // GIF Support etc.
  //

  //---------------------------------------------------------------------
  // byteArrayOutputStream
  //---------------------------------------------------------------------

  var byteArrayOutputStream = function() {

    var _bytes = [];

    var _this = {};

    _this.writeByte = function(b) {
      _bytes.push(b & 0xff);
    };

    _this.writeShort = function(i) {
      _this.writeByte(i);
      _this.writeByte(i >>> 8);
    };

    _this.writeBytes = function(b, off, len) {
      off = off || 0;
      len = len || b.length;
      for (var i = 0; i < len; i += 1) {
        _this.writeByte(b[i + off]);
      }
    };

    _this.writeString = function(s) {
      for (var i = 0; i < s.length; i += 1) {
        _this.writeByte(s.charCodeAt(i) );
      }
    };

    _this.toByteArray = function() {
      return _bytes;
    };

    _this.toString = function() {
      var s = '';
      s += '[';
      for (var i = 0; i < _bytes.length; i += 1) {
        if (i > 0) {
          s += ',';
        }
        s += _bytes[i];
      }
      s += ']';
      return s;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64EncodeOutputStream
  //---------------------------------------------------------------------

  var base64EncodeOutputStream = function() {

    var _buffer = 0;
    var _buflen = 0;
    var _length = 0;
    var _base64 = '';

    var _this = {};

    var writeEncoded = function(b) {
      _base64 += String.fromCharCode(encode(b & 0x3f) );
    };

    var encode = function(n) {
      if (n < 0) {
        // error.
      } else if (n < 26) {
        return 0x41 + n;
      } else if (n < 52) {
        return 0x61 + (n - 26);
      } else if (n < 62) {
        return 0x30 + (n - 52);
      } else if (n == 62) {
        return 0x2b;
      } else if (n == 63) {
        return 0x2f;
      }
      throw 'n:' + n;
    };

    _this.writeByte = function(n) {

      _buffer = (_buffer << 8) | (n & 0xff);
      _buflen += 8;
      _length += 1;

      while (_buflen >= 6) {
        writeEncoded(_buffer >>> (_buflen - 6) );
        _buflen -= 6;
      }
    };

    _this.flush = function() {

      if (_buflen > 0) {
        writeEncoded(_buffer << (6 - _buflen) );
        _buffer = 0;
        _buflen = 0;
      }

      if (_length % 3 != 0) {
        // padding
        var padlen = 3 - _length % 3;
        for (var i = 0; i < padlen; i += 1) {
          _base64 += '=';
        }
      }
    };

    _this.toString = function() {
      return _base64;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64DecodeInputStream
  //---------------------------------------------------------------------

  var base64DecodeInputStream = function(str) {

    var _str = str;
    var _pos = 0;
    var _buffer = 0;
    var _buflen = 0;

    var _this = {};

    _this.read = function() {

      while (_buflen < 8) {

        if (_pos >= _str.length) {
          if (_buflen == 0) {
            return -1;
          }
          throw 'unexpected end of file./' + _buflen;
        }

        var c = _str.charAt(_pos);
        _pos += 1;

        if (c == '=') {
          _buflen = 0;
          return -1;
        } else if (c.match(/^\s$/) ) {
          // ignore if whitespace.
          continue;
        }

        _buffer = (_buffer << 6) | decode(c.charCodeAt(0) );
        _buflen += 6;
      }

      var n = (_buffer >>> (_buflen - 8) ) & 0xff;
      _buflen -= 8;
      return n;
    };

    var decode = function(c) {
      if (0x41 <= c && c <= 0x5a) {
        return c - 0x41;
      } else if (0x61 <= c && c <= 0x7a) {
        return c - 0x61 + 26;
      } else if (0x30 <= c && c <= 0x39) {
        return c - 0x30 + 52;
      } else if (c == 0x2b) {
        return 62;
      } else if (c == 0x2f) {
        return 63;
      } else {
        throw 'c:' + c;
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // gifImage (B/W)
  //---------------------------------------------------------------------

  var gifImage = function(width, height) {

    var _width = width;
    var _height = height;
    var _data = new Array(width * height);

    var _this = {};

    _this.setPixel = function(x, y, pixel) {
      _data[y * _width + x] = pixel;
    };

    _this.write = function(out) {

      //---------------------------------
      // GIF Signature

      out.writeString('GIF87a');

      //---------------------------------
      // Screen Descriptor

      out.writeShort(_width);
      out.writeShort(_height);

      out.writeByte(0x80); // 2bit
      out.writeByte(0);
      out.writeByte(0);

      //---------------------------------
      // Global Color Map

      // black
      out.writeByte(0x00);
      out.writeByte(0x00);
      out.writeByte(0x00);

      // white
      out.writeByte(0xff);
      out.writeByte(0xff);
      out.writeByte(0xff);

      //---------------------------------
      // Image Descriptor

      out.writeString(',');
      out.writeShort(0);
      out.writeShort(0);
      out.writeShort(_width);
      out.writeShort(_height);
      out.writeByte(0);

      //---------------------------------
      // Local Color Map

      //---------------------------------
      // Raster Data

      var lzwMinCodeSize = 2;
      var raster = getLZWRaster(lzwMinCodeSize);

      out.writeByte(lzwMinCodeSize);

      var offset = 0;

      while (raster.length - offset > 255) {
        out.writeByte(255);
        out.writeBytes(raster, offset, 255);
        offset += 255;
      }

      out.writeByte(raster.length - offset);
      out.writeBytes(raster, offset, raster.length - offset);
      out.writeByte(0x00);

      //---------------------------------
      // GIF Terminator
      out.writeString(';');
    };

    var bitOutputStream = function(out) {

      var _out = out;
      var _bitLength = 0;
      var _bitBuffer = 0;

      var _this = {};

      _this.write = function(data, length) {

        if ( (data >>> length) != 0) {
          throw 'length over';
        }

        while (_bitLength + length >= 8) {
          _out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );
          length -= (8 - _bitLength);
          data >>>= (8 - _bitLength);
          _bitBuffer = 0;
          _bitLength = 0;
        }

        _bitBuffer = (data << _bitLength) | _bitBuffer;
        _bitLength = _bitLength + length;
      };

      _this.flush = function() {
        if (_bitLength > 0) {
          _out.writeByte(_bitBuffer);
        }
      };

      return _this;
    };

    var getLZWRaster = function(lzwMinCodeSize) {

      var clearCode = 1 << lzwMinCodeSize;
      var endCode = (1 << lzwMinCodeSize) + 1;
      var bitLength = lzwMinCodeSize + 1;

      // Setup LZWTable
      var table = lzwTable();

      for (var i = 0; i < clearCode; i += 1) {
        table.add(String.fromCharCode(i) );
      }
      table.add(String.fromCharCode(clearCode) );
      table.add(String.fromCharCode(endCode) );

      var byteOut = byteArrayOutputStream();
      var bitOut = bitOutputStream(byteOut);

      // clear code
      bitOut.write(clearCode, bitLength);

      var dataIndex = 0;

      var s = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;

      while (dataIndex < _data.length) {

        var c = String.fromCharCode(_data[dataIndex]);
        dataIndex += 1;

        if (table.contains(s + c) ) {

          s = s + c;

        } else {

          bitOut.write(table.indexOf(s), bitLength);

          if (table.size() < 0xfff) {

            if (table.size() == (1 << bitLength) ) {
              bitLength += 1;
            }

            table.add(s + c);
          }

          s = c;
        }
      }

      bitOut.write(table.indexOf(s), bitLength);

      // end code
      bitOut.write(endCode, bitLength);

      bitOut.flush();

      return byteOut.toByteArray();
    };

    var lzwTable = function() {

      var _map = {};
      var _size = 0;

      var _this = {};

      _this.add = function(key) {
        if (_this.contains(key) ) {
          throw 'dup key:' + key;
        }
        _map[key] = _size;
        _size += 1;
      };

      _this.size = function() {
        return _size;
      };

      _this.indexOf = function(key) {
        return _map[key];
      };

      _this.contains = function(key) {
        return typeof _map[key] != 'undefined';
      };

      return _this;
    };

    return _this;
  };

  var createDataURL = function(width, height, getPixel) {
    var gif = gifImage(width, height);
    for (var y = 0; y < height; y += 1) {
      for (var x = 0; x < width; x += 1) {
        gif.setPixel(x, y, getPixel(x, y) );
      }
    }

    var b = byteArrayOutputStream();
    gif.write(b);

    var base64 = base64EncodeOutputStream();
    var bytes = b.toByteArray();
    for (var i = 0; i < bytes.length; i += 1) {
      base64.writeByte(bytes[i]);
    }
    base64.flush();

    return 'data:image/gif;base64,' + base64;
  };

  //---------------------------------------------------------------------
  // returns qrcode function.

  return qrcode;
}();

// multibyte support
!function() {

  qrcode.stringToBytesFuncs['UTF-8'] = function(s) {
    // http://stackoverflow.com/questions/18729405/how-to-convert-utf8-string-to-byte-array
    function toUTF8Array(str) {
      var utf8 = [];
      for (var i=0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);
        else if (charcode < 0x800) {
          utf8.push(0xc0 | (charcode >> 6),
              0x80 | (charcode & 0x3f));
        }
        else if (charcode < 0xd800 || charcode >= 0xe000) {
          utf8.push(0xe0 | (charcode >> 12),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
        // surrogate pair
        else {
          i++;
          // UTF-16 encodes 0x10000-0x10FFFF by
          // subtracting 0x10000 and splitting the
          // 20 bits of 0x0-0xFFFFF into two halves
          charcode = 0x10000 + (((charcode & 0x3ff)<<10)
            | (str.charCodeAt(i) & 0x3ff));
          utf8.push(0xf0 | (charcode >>18),
              0x80 | ((charcode>>12) & 0x3f),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
      }
      return utf8;
    }
    return toUTF8Array(s);
  };

}();

(function (factory) {
  if (typeof define === 'function' && define.amd) {
      define([], factory);
  } else if (typeof exports === 'object') {
      module.exports = factory();
  }
}(function () {
    return qrcode;
}));
</script>
<script>
var KEY = 'xiaomengyunAccountsV1';
var accounts = [];
var role = '', nickname = '';
var authToken = sessionStorage.getItem('xiaomengyunToken') || '';
var counts = { emails: 0, phones: 0, noLink: 0, noLinkEmail: 0, noLinkPhone: 0, usedPhones: 0, usedEmails: 0 };
var apiBase = '';
var serverOK = false;
var LAN_IP = '__LAN_IP__';
var LAN_PORT = __LAN_PORT__;
var viewTabFilter = ''; var workerTab = 'phone'; var autoPaused = false; var nextRefreshIn = 20;
var takeNeedPlatform = '';

function $(id) { return document.getElementById(id); }
function toast(msg) { var t = $('toast'); t.textContent = msg; t.style.display = 'block'; setTimeout(function(){ t.style.display = 'none'; }, 2200); }
function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function isEmail(s) { return s.indexOf('@') !== -1; }
function digits(s) { return String(s).replace(/\D/g, ''); }
function authHeaders() { var h = { 'Content-Type': 'application/json' }; if (authToken) h['X-Auth-Token'] = authToken; return h; }
function api(path, body, method) {
  var url = apiBase + path;
  var opts = { method: method || (body ? 'POST' : 'GET'), headers: authHeaders() };
  if (body) opts.body = JSON.stringify(body);
  return fetch(url, opts).then(function (r) { return r.json(); });
}

// 内网优先探测：能连上主机局域网地址就走内网（更快），不通就自动用当前链接（隧道）
function probeLan() {
  if (!LAN_IP) return Promise.resolve(false);
  var url = 'http://' + LAN_IP + ':' + LAN_PORT + '/api/ping';
  var ctrl;
  try { ctrl = new AbortController(); } catch (e) { return Promise.resolve(false); }
  var timer = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, 2000);
  return fetch(url, { signal: ctrl.signal }).then(function (r) { return r.json(); }).then(function (j) {
    clearTimeout(timer);
    if (j && j.ok) { apiBase = 'http://' + LAN_IP + ':' + LAN_PORT; return true; }
    return false;
  }).catch(function () { clearTimeout(timer); return false; });
}

// ---------- 工作区（本机浏览器） ----------
function load() { try { accounts = JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { accounts = []; } }
function save() { localStorage.setItem(KEY, JSON.stringify(accounts)); }

// 渠道/来源：有发件方就显示发件方，否则显示收码渠道
function sourceOf(a) {
  if (a.sender) return a.sender;
  if (a.type === 'email') return '邮箱收件箱';
  return '短信接口';
}

// ---------- 每个平台一个格子：验证码按平台分开存，互不顶掉 ----------
// 发件人 → 平台名（和服务端的 Get-PlatformName 同一套规则）
function platformName(sender) {
  var s = (sender || '').toLowerCase();
  if (s.indexOf('tiktok') !== -1) return 'TikTok';
  if (s.indexOf('pixverse') !== -1) return 'PixVerse';
  if (s.indexOf('kling') !== -1 || s.indexOf('可灵') !== -1) return '可灵';
  return (sender || '').split('·')[0].trim();
}
// 取出要显示的各平台码：{ 平台名: {code, time} }
// 电话只用一个平台：码显示在当前打勾的那个平台格子里（没勾默认 TikTok）；
// 邮箱：按发件人平台分格；旧数据（只有单码）用发件人平台兜底。
function displayCodes(a) {
  var out = {};
  if (a.codes) {
    for (var k in a.codes) {
      if (a.codes[k] && a.codes[k].code) out[k] = a.codes[k];
    }
  }
  if (a.type === 'phone') {
    var plat = (a.platforms && a.platforms[0]) || 'TikTok';
    var one = null;
    for (var k2 in out) { one = out[k2]; break; }
    if (!one && a.code) one = { code: a.code, time: a.time || '' };
    out = {};
    if (one) out[plat] = one;
  } else if (!Object.keys(out).length && a.code) {
    var p = platformName(a.sender) || 'TikTok';
    out[p] = { code: a.code, time: a.time || '' };
  }
  return out;
}
// 三个格子：TikTok / PixVerse / 可灵 各一格，有码显示码，没码显示等待中；
// 其他发件人的码（不在三个平台里）也单独一格，不藏起来。
function codeCellsHtml(a) {
  var known = ['TikTok', 'PixVerse', '可灵'];
  var codes = displayCodes(a);
  var html = '<div class="code-cells">';
  known.forEach(function (p) {
    var c = codes[p];
    html += '<div class="code-cell' + (c ? ' got' : '') + '"><div class="code-plat">' + p + '</div>'
      + (c ? '<span class="code" data-code="' + esc(c.code) + '" title="点击复制">' + esc(c.code) + '</span>' + (c.time ? '<div class="code-time">' + esc(c.time) + '</div>' : '')
           : '<span class="code empty">等待中</span>')
      + '</div>';
  });
  for (var k in codes) {
    if (known.indexOf(k) === -1) {
      var c2 = codes[k];
      html += '<div class="code-cell got"><div class="code-plat">' + esc(k) + '</div>'
        + '<span class="code" data-code="' + esc(c2.code) + '" title="点击复制">' + esc(c2.code) + '</span>' + (c2.time ? '<div class="code-time">' + esc(c2.time) + '</div>' : '')
        + '</div>';
    }
  }
  return html + '</div>';
}
function render() {
  var tb = $('tbody');
  if (!tb) return;
  var q = $('searchBox') ? ($('searchBox').value || '').toLowerCase() : '';
  tb.innerHTML = '';
  var shown = 0;
  accounts.forEach(function (a, idx) {
    if (q && a.label.toLowerCase().indexOf(q) === -1) return;
    if (viewTabFilter && a.type !== viewTabFilter) return;
    shown++;
    var tr = document.createElement('tr');
    var codeHtml = codeCellsHtml(a);
    var pill = a.status === 'err' ? '<span class="pill err">拉取失败</span>' : (a.code ? '<span class="pill ok">已收到</span>' : '<span class="pill wait">等待中</span>');
    // 平台勾选：三个勾（TikTok / PixVerse / 可灵），码到了自动打勾，也可手动点；三勾全满即废弃
    var plats = a.platforms || [];
    var knownPlats = ['TikTok', 'PixVerse', '可灵'];
    var platHtml = '<div class="plat-ticks">' + knownPlats.map(function (p) {
      var on = plats.indexOf(p) !== -1;
      return '<button class="plat-tick' + (on ? ' on' : '') + (p === 'TikTok' ? ' tk' : '') + '" data-plat="' + p + '" data-idx="' + idx + '" title="点一下标记/取消 ' + p + '"' + (a.spent ? ' disabled' : '') + '>' + (on ? '✓ ' : '○ ') + p + '</button>';
    }).join('') + '</div>';
    if (a.type === 'email') {
      var done = [], todo = [];
      knownPlats.forEach(function (p) { if (plats.indexOf(p) !== -1) done.push(p); else todo.push(p); });
      var other = plats.filter(function (p) { return knownPlats.indexOf(p) === -1; });
      // TikTok 是最主要的用途：状态单独一行、加粗，一眼看清这个号能不能用来注册 TikTok
      var tkUsed = plats.indexOf('TikTok') !== -1;
      platHtml += '<div style="font-size:12px;font-weight:700;color:' + (tkUsed ? '#86efac' : '#93c5fd') + '">TikTok：' + (tkUsed ? '✓ 已注册' : '○ 未注册，可领来注册 TikTok') + '</div>';
      platHtml += '<div style="color:#64748b;font-size:11px">已注册：' + (done.concat(other).join('、') || '无') + ' · 未注册：' + (todo.join('、') || '无') + '</div>';
    } else {
      platHtml += '<div style="color:#64748b;font-size:11px">' + (plats.length ? '已接：' + plats.join('、') + '（单平台，用完点确认废弃）' : '单平台：用一次就确认废弃') + '</div>';
    }
    if (a.spent) platHtml += '<div style="color:#fca5a5;font-size:11px">已废弃（不会再被取用）</div>';
    tr.innerHTML = '<td data-label="账号"><span class="label-copy" data-label-copy="' + esc(a.label) + '" title="点一下复制邮箱">' + esc(a.label) + '</span>' + platHtml + (a.status === 'err' && a.error ? '<div style="color:#fca5a5;font-size:11px" title="' + esc(a.error) + '">拉取失败，鼠标悬停看原因</div>' : '') + '</td>'
      + '<td data-label="验证码">' + codeHtml + '</td>'
      + '<td data-label="状态">' + pill + '</td>'
      + '<td data-label="来源" style="color:#94a3b8;font-size:12px">' + esc(sourceOf(a)) + '</td>'
      + '<td data-label="下次访问" class="next-visit" style="color:#94a3b8;font-size:12px">' + (autoPaused ? '已停止' : nextRefreshIn + ' 秒后访问') + '</td>'
      + '<td data-label="操作"><div class="rowbtns">'
      + ((a.type === 'phone' && plats.length) ? '' : '<button class="ghost" data-release="' + idx + '">释放</button>')
      + '<button class="ghost" data-confirm="' + idx + '">确认</button>'
      + '<button class="ghost" data-refresh="' + idx + '">重试</button>'
      + '<button class="ghost" data-blacklist="' + idx + '">拉黑</button>'
      + (a.url ? '<button class="ghost" data-open="' + idx + '">打开收件箱</button>' : '')
      + '</div></td>';
    tb.appendChild(tr);
  });
  if ($('emptyTip')) $('emptyTip').style.display = shown ? 'none' : 'block';
  var got = accounts.filter(function (a) { return !!a.code; }).length;
  if ($('stActive')) $('stActive').textContent = accounts.length;
  if ($('stGot')) $('stGot').textContent = got;
  if ($('stStoreEmail')) $('stStoreEmail').textContent = counts.emails;
  if ($('stStorePhone')) $('stStorePhone').textContent = counts.phones;
  var be = $('btnAddEmail'), bp = $('btnAddPhone');
  if (be) { be.textContent = '＋ 添加邮箱（剩 ' + counts.emails + '）'; be.disabled = counts.emails === 0; }
  if (bp) { bp.textContent = '＋ 添加电话号码（剩 ' + counts.phones + '）'; bp.disabled = counts.phones === 0; }
  var bt = $('btnTake');
  if (bt) {
    var left = workerTab === 'email' ? counts.emails : counts.phones;
    bt.textContent = '获取号码（剩 ' + left + '）';
    bt.disabled = left === 0;
  }
  var ac = $('activeCount');
  if (ac) ac.textContent = autoPaused ? '已停止接码 · ' + accounts.length + ' 个号码' : '接码中 · ' + accounts.length + ' 个号码';
  if ($('storeNoteEmail')) $('storeNoteEmail').textContent = '仓库邮箱 ' + counts.emails + ' 个' + (counts.noLinkEmail ? '，其中 ' + counts.noLinkEmail + ' 个没有链接（取不出来，让老板补链接）' : '') + (counts.usedEmails ? '，已废弃 ' + counts.usedEmails + ' 个' : '');
  if ($('storeNotePhone')) $('storeNotePhone').textContent = '仓库电话 ' + counts.phones + ' 个' + (counts.noLinkPhone ? '，其中 ' + counts.noLinkPhone + ' 个没有链接（取不出来，让老板补链接）' : '') + (counts.usedPhones ? '，已废弃 ' + counts.usedPhones + ' 个（电话用一次就作废）' : '');
}

function refreshCounts() {
  return api('/api/storage-counts').then(function (res) {
    if (res && typeof res.emails === 'number') {
      counts.emails = res.emails; counts.phones = res.phones;
      counts.noLink = res.noLink || 0; counts.noLinkEmail = res.noLinkEmail || 0; counts.noLinkPhone = res.noLinkPhone || 0;
      counts.usedPhones = res.usedPhones || 0; counts.usedEmails = res.usedEmails || 0;
      render();
    }
  }).catch(function () {});
}

function takeOne(type) {
  var body = { type: type };
  if (type === 'email' && takeNeedPlatform) body.needPlatform = takeNeedPlatform;
  api('/api/take', body, 'POST').then(function (res) {
    if (!res.ok) { toast(res.error || '取不到了'); return; }
    accounts.push({ label: res.label, url: res.url || '', type: res.type, code: '', time: '', sender: '', status: 'wait', platforms: res.platforms || [], firstUse: res.firstUse || '', spent: !!res.spent, codes: {} });
    save(); render(); refreshCounts();
    fetchOne(accounts.length - 1);
  }).catch(function () { toast('服务未连接'); });
}

function fetchOne(idx) {
  var a = accounts[idx];
  if (!a) return Promise.resolve();
  return api('/api/fetch', { label: a.label }, 'POST').then(function (res) {
    if (res.needAuth) { lockNow(); return; }
    if (res.ok) {
      if (res.code) {
        // 只更新收到新码的那个平台的格子，其他平台的格子不动；同平台新码换旧码；
        // 没收到新码时一个格子也不动，刷新本身不清空任何格子
        var plat = res.platform || (a.platforms && a.platforms[0]) || 'TikTok';
        a.codes = a.codes || {};
        a.codes[plat] = { code: res.code, time: res.time || new Date().toLocaleString('zh-CN', { hour12: false }) };
        a.code = res.code; a.time = a.codes[plat].time;
      }
      if (res.sender) a.sender = res.sender;
      if (res.platforms) a.platforms = res.platforms;
      if (res.spent && !a.spent) { a.spent = true; toast(a.label + ' 已用满，已废弃（码已收到，先复制再点释放移除）'); }
      else if (res.spent) a.spent = true;
      a.status = a.code ? 'ok' : 'wait';
      a.error = '';
    } else if (res.gone) {
      var gi = accounts.findIndex(function (x) { return x.label === a.label; });
      if (gi !== -1) accounts.splice(gi, 1);
      save(); render(); refreshCounts();
      toast(a.label + ' 已不在服务器上（已废弃或已释放），已从列表移除');
      return;
    } else {
      a.status = 'err';
      a.error = res.error || '拉取失败';
    }
    save(); render();
  }).catch(function () {
    a.status = 'err'; a.error = '服务未连接'; save(); render();
  });
}

var refreshing = false;
function refreshAll() {
  if (!accounts.length) { toast('没有账号可刷新'); return; }
  if (refreshing) return;
  refreshing = true;
  nextRefreshIn = 20;
  var hint = $('fetchHint');
  if (hint) hint.style.display = 'none';
  var queue = [];
  accounts.forEach(function (a, i) { queue.push(i); });
  var running = 0;
  function next() {
    while (running < 5 && queue.length) {
      var i = queue.shift(); running++;
      fetchOne(i).then(function () { running--; next(); }, function () { running--; next(); });
    }
    if (!queue.length && running === 0) {
      refreshing = false;
      var got = accounts.filter(function (a) { return !!a.code; }).length;
      var err = accounts.filter(function (a) { return a.status === 'err'; }).length;
      if (hint) {
        if (err && !got) { hint.style.display = 'block'; hint.textContent = '拉取失败：服务可能没启动，或网络不通。'; }
        else if (err) { hint.style.display = 'block'; hint.textContent = err + ' 个账号拉取失败（鼠标悬停在“拉取失败”上看原因），其余正常。'; }
      }
    }
  }
  next();
}

// ---------- 仓库添加（老板/管理员） ----------
function storageAddText(type, append, text) {
  if (!text || !text.trim()) { toast('先粘贴账号或选一个文档'); return; }
  api('/api/storage-add', { text: text, append: append, type: type }, 'POST').then(function (res) {
    if (!res.ok) { toast(res.error || '存入失败'); return; }
    toast('已存入 ' + res.added + ' 个' + (res.skipped ? '，' + res.skipped + ' 个跳过（重复）' : '') + (res.noLinkAdded ? '，其中 ' + res.noLinkAdded + ' 个没有链接（取不出来）' : ''));
    refreshCounts();
  }).catch(function () { toast('服务未连接'); });
}
function storageAdd(type, append) {
  var ta = $(type === 'email' ? 'importEmail' : 'importPhone');
  storageAddText(type, append, ta ? ta.value : '');
}
function wirePanel(suf) {
  var type = suf === 'Email' ? 'email' : 'phone';
  function on(id, fn) { var el = $(id); if (el) el.onclick = fn; }
  on('btnImport' + suf, function () { storageAdd(type, false); });
  on('btnAppend' + suf, function () { storageAdd(type, true); });
  on('btnExample' + suf, function () {
    var ta = $('import' + suf);
    if (ta) ta.value = type === 'email'
      ? 'sample@icloud.com----https://mail.niantu.xyz/mail/xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
      : '+17150000000----https://api.sms8.net/api/record?token=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
    toast('已填入示例，改成你自己的再存入');
  });
  on('btnClearImport' + suf, function () { var ta = $('import' + suf); if (ta) ta.value = ''; toast('输入框已清空'); });
  var fileBtn = $('btnFile' + suf), fileIn = $('file' + suf);
  if (fileBtn && fileIn) {
    fileBtn.onclick = function () { fileIn.click(); };
    fileIn.onchange = function () {
      var f = fileIn.files[0]; if (!f) return;
      var rd = new FileReader();
      rd.onload = function () { storageAddText(type, true, String(rd.result || '')); };
      rd.onerror = function () { toast('读文件失败'); };
      rd.readAsText(f, 'UTF-8');
      fileIn.value = '';
    };
  }
  on('btnClear' + suf, function () {
    if (!confirm('确定要清空' + (type === 'email' ? '邮箱' : '电话') + '仓库吗？已取出的不受影响。')) return;
    api('/api/storage-clear', { type: type }, 'POST').then(function (res) {
      if (res.ok) { toast('已清空'); refreshCounts(); } else toast(res.error || '清空失败');
    }).catch(function () { toast('服务未连接'); });
  });
  on('btnDel' + suf, function () {
    var inp = $('delLabel' + suf);
    var label = inp ? inp.value.trim() : '';
    if (!label) { toast('先输入要删除的账号'); return; }
    if (!confirm('确定删除 ' + label + ' 吗？已取出的这个账号也会失效。')) return;
    api('/api/storage-delete', { label: label }, 'POST').then(function (res) {
      if (res.ok) { toast('已删除'); if (inp) inp.value = ''; refreshCounts(); } else toast(res.error || '删除失败');
    }).catch(function () { toast('服务未连接'); });
  });
}

// ---------- 工作区行操作 ----------
// ---------- 点击复制邮箱 ----------
function copyText(t, okMsg) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(t).then(function(){ toast(okMsg); }).catch(function(){ toast(t); });
  } else { toast(t); }
}
// ---------- 批量二维码：当前列表全部邮箱合进一个码，扫一次全拿到 ----------
// 批量二维码：把一批邮箱发给服务端换一个短链接，二维码里只放短链接
// （直接放邮箱原文会被 iPhone 认成 mailto 跳去 Mail，没法复制；放短链接，扫码打开手机页就能复制/存备忘录）
// 二维码里放服务端返回的完整链接（内网 IP 或隧道链接），手机才能打开
// 不能用 window.location.origin 拼：电脑用 127.0.0.1 打开时 origin 是本机地址，手机扫了打不开（v1.0.2 的 bug）
function showQrForEmails(emails) {
  if (!emails.length) { toast('没有邮箱'); return; }
  api('/api/qr-share', { emails: emails }, 'POST').then(function (res) {
    if (!res.ok) { toast(res.error || '生成失败'); return; }
    if (res.shareUrl) { renderQr(res.shareUrl, emails); return; }
    // 兼容旧版接口：没给 shareUrl 时自己拼；本机地址（127.0.0.1/localhost）手机打不开，先拿内网/隧道链接
    var host = window.location.hostname;
    if (host === '127.0.0.1' || host === 'localhost' || host === '::1') {
      api('/api/share-link').then(function (r2) {
        var base = (r2 && r2.ok && (r2.lanLink || r2.link)) ? (r2.lanLink || r2.link) : window.location.origin + '/';
        renderQr(base.replace(/\/+$/, '') + '/e/' + res.token, emails);
      }).catch(function () { renderQr(window.location.origin + '/e/' + res.token, emails); });
    } else {
      renderQr(window.location.origin + '/e/' + res.token, emails);
    }
  }).catch(function () { toast('服务未连接'); });
}
function renderQr(shortUrl, emails) {
  try {
    var qr = qrcode(0, 'L');
    qr.addData(shortUrl);
    qr.make();
    var n = qr.getModuleCount();
    var cell = Math.max(1, Math.floor(280 / n));
    $('qrImg').innerHTML = qr.createSvgTag(cell, 8);
  } catch (err) { toast('二维码生成失败，请重试'); return; }
  $('qrTitle').textContent = '邮箱二维码（' + emails.length + ' 个）';
  $('qrSub').textContent = '手机扫一下，打开邮箱页面，点复制就能用';
  $('qrList').textContent = emails.join('\n');
  $('qrModal').classList.add('open');
}
function showBatchQr() {
  var emails = accounts.filter(function (a) { return a.type === 'email'; }).map(function (a) { return a.label; });
  if (!emails.length) { toast('列表里没有邮箱，先点「获取号码」取几个邮箱'); return; }
  showQrForEmails(emails);
}
// BOSS 页：对仓库里显示的邮箱生成二维码，拿多少个就合多少个
function showBossQr() {
  api('/api/storage-list').then(function (res) {
    if (!res.ok) { toast(res.error || '读取仓库失败'); return; }
    var emails = (res.accounts || []).filter(function (a) { return a.type === 'email'; }).map(function (a) { return a.label; });
    if (!emails.length) { toast('仓库里没有邮箱'); return; }
    showQrForEmails(emails);
  }).catch(function () { toast('服务未连接'); });
}
function hideQr() { var m = $('qrModal'); if (m) m.classList.remove('open'); }
function onRowClick(e) {
  var t = e.target;
  if (t.dataset.labelCopy) { copyText(t.dataset.labelCopy, '已复制邮箱'); return; }
  if (t.dataset.code) {
    var code = t.dataset.code;
    if (navigator.clipboard) navigator.clipboard.writeText(code).then(function(){ toast('已复制 ' + code); });
    else toast(code);
    return;
  }
  if (t.dataset.refresh !== undefined) { fetchOne(parseInt(t.dataset.refresh, 10)); return; }
  if (t.dataset.open !== undefined) {
    var a = accounts[parseInt(t.dataset.open, 10)];
    if (a && a.url) window.open(a.url, '_blank');
    return;
  }
  if (t.dataset.release !== undefined) { releaseOne(parseInt(t.dataset.release, 10)); return; }
  if (t.dataset.confirm !== undefined) { confirmOne(parseInt(t.dataset.confirm, 10)); return; }
  if (t.dataset.blacklist !== undefined) { blacklistOne(parseInt(t.dataset.blacklist, 10)); return; }
  if (t.dataset.plat !== undefined) { togglePlatform(parseInt(t.dataset.idx, 10), t.dataset.plat); return; }
}
// 手动打勾/取消勾：标记这个账号用在哪个平台（没经过工具收码时用，或纠错）
function togglePlatform(idx, platform) {
  var a = accounts[idx];
  if (!a || a.spent) return;
  var plats = a.platforms || [];
  var on = plats.indexOf(platform) === -1;
  api('/api/set-platform', { label: a.label, platform: platform, on: on }, 'POST').then(function (res) {
    if (!res.ok) { toast(res.error || '设置失败'); return; }
    a.platforms = res.platforms || [];
    if (res.firstUse) a.firstUse = res.firstUse;
    if (res.spent) { a.spent = true; toast(a.label + ' 已用满 3 个平台，已废弃（先复制码，再点释放移除）'); }
    save(); render(); refreshCounts();
  }).catch(function () { toast('服务未连接'); });
}
// 确认：用完了，立即废弃（两种账号都有）
function confirmOne(idx) {
  var a = accounts[idx];
  if (!a) return;
  var msg = a.type === 'phone'
    ? '确认这个号码用完了吗？确认后号码立即废弃，再也取不到了。'
    : '确认这个邮箱用完了吗？确认后邮箱立即废弃，再也取不到了。';
  if (!confirm(msg)) return;
  api('/api/confirm', { label: a.label }, 'POST').then(function (res) {
    if (!res.ok) { toast(res.error || '确认失败'); return; }
    accounts.splice(idx, 1); save(); render(); refreshCounts(); toast('已废弃');
  }).catch(function () { toast('服务未连接'); });
}
// 释放：把账号放回仓库（可再取），同时从本机工作区移除
function releaseOne(idx) {
  var a = accounts[idx];
  if (!a) return;
  api('/api/release', { label: a.label }, 'POST').then(function (res) {
    accounts.splice(idx, 1); save(); render(); refreshCounts();
    toast(res && res.discarded ? '已废弃，这个号码再也取不到了' : '已释放回仓库，可以再取');
  }).catch(function () {
    accounts.splice(idx, 1); save(); render(); toast('已从列表移除（服务器未连接，仓库可能没收回）');
  });
}
// 拉黑：这个账号以后再也不会被取出来（老板可在 BOSS 端取消拉黑）
function blacklistOne(idx) {
  var a = accounts[idx];
  if (!a) return;
  if (!confirm('拉黑 ' + a.label + ' 吗？拉黑后这个账号再也不会被取出来（老板可以在 BOSS 端取消拉黑）。')) return;
  api('/api/blacklist', { label: a.label }, 'POST').then(function (res) {
    if (res.ok) { accounts.splice(idx, 1); save(); render(); refreshCounts(); toast('已拉黑'); }
    else toast(res.error || '拉黑失败');
  }).catch(function () { toast('服务未连接'); });
}
function clearActive() {
  if (!accounts.length) return;
  if (!confirm('确定要清空列表吗？没用过的账号会放回仓库，可以再取；已经用过的电话会直接废弃。')) return;
  var labels = accounts.map(function (a) { return a.label; });
  Promise.all(labels.map(function (l) { return api('/api/release', { label: l }, 'POST').catch(function () {}); })).then(function () {
    accounts = []; save(); render(); refreshCounts(); toast('列表已清空，号码已放回仓库');
  });
}
function exportTxt() {
  if (!accounts.length) { toast('没有账号可导出'); return; }
  var lines = accounts.map(function (a) {
    var parts = [];
    var codes = displayCodes(a);
    ['TikTok', 'PixVerse', '可灵'].forEach(function (p) { if (codes[p]) parts.push(p + '：' + codes[p].code); });
    for (var k in codes) { if (['TikTok', 'PixVerse', '可灵'].indexOf(k) === -1) parts.push(k + '：' + codes[k].code); }
    return a.label + '----' + (parts.length ? parts.join(' / ') : '（无验证码）');
  });
  var blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  var link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = '验证码-' + new Date().toISOString().slice(0, 10) + '.txt';
  link.click();
  URL.revokeObjectURL(link.href);
  toast('已导出 TXT');
}

// ---------- 粘贴识别（备用） ----------
function extractCodes(text) {
  var found = [];
  function isCode(s) { return /^[A-Za-z0-9]{4,10}$/.test(s) && /\d/.test(s); }
  try {
    var j = JSON.parse(text.trim());
    if (j && j.data && j.data.code && isCode(String(j.data.code))) found.push(String(j.data.code));
    else if (j && j.code && isCode(String(j.code))) found.push(String(j.code));
  } catch (e) {}
  var re = /(?:验证码|验证代码|verification\s*code(?:\s+is)?)[^A-Za-z0-9]{0,6}?([A-Za-z0-9]{4,10})/gi, m;
  while ((m = re.exec(text)) !== null) { if (isCode(m[1]) && found.indexOf(m[1]) === -1) found.push(m[1]); }
  var re2 = /\bcode\s*[:：]\s*([A-Za-z0-9]{4,10})/gi;
  while ((m = re2.exec(text)) !== null) { if (isCode(m[1]) && found.indexOf(m[1]) === -1) found.push(m[1]); }
  if (!found.length) {
    var re3 = /(^|\D)(\d{6})(?!\d)/g;
    while ((m = re3.exec(text)) !== null) { if (found.indexOf(m[2]) === -1) found.push(m[2]); }
  }
  if (!found.length) {
    var re4 = /\b(?=[A-Za-z0-9]*[A-Za-z])(?=[A-Za-z0-9]*\d)[A-Za-z0-9]{4,10}\b/g;
    while ((m = re4.exec(text)) !== null) { if (found.indexOf(m[0]) === -1) found.push(m[0]); }
  }
  return found;
}
function matchAccount(text) {
  var low = text.toLowerCase();
  for (var i = 0; i < accounts.length; i++) {
    var a = accounts[i];
    if (a.type === 'email' && low.indexOf(a.label.toLowerCase()) !== -1) return i;
    if (a.type === 'phone') {
      var d = digits(a.label);
      if (d.length >= 7 && low.indexOf(d) !== -1) return i;
      if (d.length >= 10 && low.indexOf(d.slice(-10)) !== -1) return i;
    }
  }
  return -1;
}
function fillCode(idx, code, sender) {
  var a = accounts[idx];
  var plat = platformName(sender) || (a.platforms && a.platforms[0]) || 'TikTok';
  a.codes = a.codes || {};
  a.codes[plat] = { code: code, time: new Date().toLocaleString('zh-CN', { hour12: false }) };
  a.code = code; a.status = 'ok';
  a.time = a.codes[plat].time;
  if (sender) a.sender = sender;
  save(); render();
}
function senderOf(text) {
  var m = text.match(/([A-Za-z][A-Za-z0-9 ._-]{1,30})\s*[·•|]\s*\d{4}-\d{2}-\d{2}/);
  return m ? m[1].trim() : '';
}
function onParse() {
  var text = $('pasteBox').value;
  var res = $('pasteResult');
  if (!text.trim()) { toast('请先粘贴邮件或短信内容'); return; }
  if (/----/.test(text) && /https?:\/\//.test(text) && !/验证码|verification\s*code/i.test(text)) {
    res.style.display = 'block';
    res.innerHTML = '你粘贴的是账号导入行（邮箱----链接），里面没有验证码。<br>正确做法：点右边账号旁的「打开收件箱」，在收件箱页面按 Ctrl+A 全选、Ctrl+C 复制，再粘贴到这里识别。';
    return;
  }
  var codes = extractCodes(text);
  if (!codes.length) { res.style.display = 'block'; res.innerHTML = '没有识别到验证码，请确认粘贴的是包含验证码的邮件全文或短信原文。'; return; }
  var idx = matchAccount(text);
  if (idx >= 0) {
    fillCode(idx, codes[0], senderOf(text));
    res.style.display = 'block';
    res.innerHTML = '已填入：' + esc(accounts[idx].label) + ' → <b style="color:#4ade80">' + esc(codes[0]) + '</b>';
    toast('验证码已填入 ' + accounts[idx].label);
  } else {
    res.style.display = 'block';
    var opts = accounts.map(function (a, i) { return '<option value="' + i + '">' + esc(a.label) + '</option>'; }).join('');
    res.innerHTML = '识别到验证码 <b style="color:#4ade80">' + esc(codes[0]) + '</b>，内容里没找到已导入的账号，请选择要填入的账号：'
      + '<select id="assignSel">' + opts + '</select>'
      + '<button id="assignBtn">填入</button>';
    $('assignBtn').onclick = function () {
      var i = parseInt($('assignSel').value, 10);
      fillCode(i, codes[0], senderOf(text));
      res.innerHTML = '已填入：' + esc(accounts[i].label) + ' → <b style="color:#4ade80">' + esc(codes[0]) + '</b>';
      toast('验证码已填入 ' + accounts[i].label);
    };
  }
}

// ---------- 老板：人员 / 邀请码 / 分享链接 / 取用记录 ----------
function loadPeople() {
  api('/api/people').then(function (res) {
    var tb = $('peopleBody'); if (!tb || !res.ok) return;
    tb.innerHTML = '';
    res.people.forEach(function (p) {
      var tr = document.createElement('tr');
      var roleName = p.role === 'admin' ? '管理员' : '工人';
      var en = p.enabled ? '<span class="pill ok">启用</span>' : '<span class="pill err">停用</span>';
      var acts = '';
      if (p.role === 'admin') acts += '<button class="ghost" data-act="demote" data-nick="' + esc(p.nickname) + '">降为工人</button>';
      else acts += '<button class="ghost" data-act="promote" data-nick="' + esc(p.nickname) + '">设为管理员</button>';
      acts += p.enabled
        ? '<button class="ghost" data-act="disable" data-nick="' + esc(p.nickname) + '">停用</button>'
        : '<button class="ghost" data-act="enable" data-nick="' + esc(p.nickname) + '">启用</button>';
      acts += '<button class="ghost" data-act="resetpw" data-nick="' + esc(p.nickname) + '">改密码</button>';
      acts += '<button class="ghost" data-act="del" data-nick="' + esc(p.nickname) + '">删除</button>';
      tr.innerHTML = '<td data-label="昵称">' + esc(p.nickname) + '</td><td data-label="角色">' + roleName + '</td><td data-label="状态">' + en + '</td><td data-label="注册时间">' + esc(p.created || '') + '</td><td data-label="余额">' + (p.balance === null || p.balance === undefined ? '不限' : esc(String(p.balance))) + '</td><td data-label="操作"><div class="rowbtns">' + acts + '</div></td>';
      tb.appendChild(tr);
    });
    if ($('peopleCount')) $('peopleCount').textContent = '共 ' + res.people.length + ' 人';
  }).catch(function () {});
}
function onPeopleClick(e) {
  var t = e.target;
  var act = t.dataset.act, nick = t.dataset.nick;
  if (!act || !nick) return;
  if (act === 'promote') {
    if (!confirm('把 ' + nick + ' 设为管理员吗？管理员只能添加账号，不能踢人、不能删仓库。')) return;
    api('/api/person-set-role', { nickname: nick, role: 'admin' }, 'POST').then(function (r) { toast(r.ok ? '已设为管理员' : (r.error || '失败')); loadPeople(); });
  } else if (act === 'demote') {
    if (!confirm('把 ' + nick + ' 降为工人吗？他马上失去添加账号的权限。')) return;
    api('/api/person-set-role', { nickname: nick, role: 'worker' }, 'POST').then(function (r) { toast(r.ok ? '已降为工人' : (r.error || '失败')); loadPeople(); });
  } else if (act === 'disable') {
    if (!confirm('停用 ' + nick + ' 吗？他马上登录不进来。')) return;
    api('/api/person-set-enabled', { nickname: nick, enabled: false }, 'POST').then(function (r) { toast(r.ok ? '已停用' : (r.error || '失败')); loadPeople(); });
  } else if (act === 'enable') {
    api('/api/person-set-enabled', { nickname: nick, enabled: true }, 'POST').then(function (r) { toast(r.ok ? '已启用' : (r.error || '失败')); loadPeople(); });
  } else if (act === 'del') {
    if (!confirm('删除成员 ' + nick + ' 吗？他马上登录不进来，删了就没了。')) return;
    api('/api/person-delete', { nickname: nick }, 'POST').then(function (r) { toast(r.ok ? '已删除' : (r.error || '失败')); loadPeople(); });
  } else if (act === 'resetpw') {
    var npw = prompt('给 ' + nick + ' 设置新密码（至少 4 位）：');
    if (!npw) return;
    if (npw.length < 4) { toast('密码至少 4 位'); return; }
    api('/api/boss-reset-worker-password', { nickname: nick, newPassword: npw }, 'POST').then(function (r) { toast(r.ok ? '密码已改，告诉他新密码' : (r.error || '失败')); });
  }
}
function loadRegcode() {
  api('/api/regcode-status').then(function (res) {
    var el = $('regcodeNow');
    if (el) el.textContent = (res && res.hasCode) ? res.code : '未设置';
  }).catch(function () {});
}
function loadShareLink() {
  api('/api/share-link').then(function (res) {
    var el = $('shareLink');
    if (!el) return;
    if (res && res.link) {
      el.textContent = res.link;
      var b = $('btnCopyLink'); if (b) b.disabled = false;
    } else {
      el.textContent = '隧道正在生成…（稍等几秒后自动刷新）';
      setTimeout(loadShareLink, 5000);
    }
    var lan = $('lanLink');
    if (lan) {
      if (res && res.lanLink) {
        lan.textContent = res.lanLink;
        var lb = $('btnCopyLan'); if (lb) lb.disabled = false;
      } else {
        lan.textContent = '内网地址获取中…';
      }
    }
  }).catch(function () { setTimeout(loadShareLink, 8000); });
}
function loadTakelog() {
  api('/api/takelog').then(function (res) {
    var tb = $('takelogBody'); if (!tb || !res.ok) return;
    tb.innerHTML = '';
    if (!res.log.length) { tb.innerHTML = '<tr><td colspan="4" style="color:#475569">还没有人取过账号</td></tr>'; return; }
    res.log.slice(0, 50).forEach(function (r) {
      var tr = document.createElement('tr');
      tr.innerHTML = '<td data-label="账号">' + esc(r.label) + '</td><td data-label="类型">' + (r.type === 'email' ? '邮箱' : '电话') + '</td><td data-label="工人">' + esc(r.nickname) + '</td><td data-label="时间">' + esc(r.time) + '</td><td data-label="操作"><button class="ghost" data-takelog-release="' + esc(r.label) + '">释放</button></td>';
      tb.appendChild(tr);
    });
  }).catch(function () {});
}
// 使用记录（BOSS/管理员）：账号用过哪些平台、谁用的、什么时候
function loadUsage() {
  api('/api/usage').then(function (res) {
    var tb = $('usageBody'); if (!tb || !res.ok) return;
    tb.innerHTML = '';
    if (!res.log.length) { tb.innerHTML = '<tr><td colspan="4" style="color:#475569">还没有使用记录</td></tr>'; return; }
    res.log.slice(0, 100).forEach(function (r) {
      var tr = document.createElement('tr');
      tr.innerHTML = '<td data-label="账号">' + esc(r.label) + '</td><td data-label="平台">' + esc(r.platform) + (r.manual ? '（手动）' : '') + '</td><td data-label="工人">' + esc(r.nickname) + '</td><td data-label="时间">' + esc(r.time) + '</td>';
      tb.appendChild(tr);
    });
  }).catch(function () {});
}
// 仓库账号列表（BOSS/管理员）：每个账号已注册/未注册哪些平台、首次使用时间
function loadStorageList() {
  api('/api/storage-list').then(function (res) {
    var tb = $('storageListBody'); if (!tb || !res.ok) return;
    tb.innerHTML = '';
    if (!res.accounts.length) { tb.innerHTML = '<tr><td colspan="5" style="color:#475569">仓库是空的</td></tr>'; return; }
    res.accounts.forEach(function (a) {
      var tr = document.createElement('tr');
      var plats = a.platforms || [];
      var known = ['TikTok', 'PixVerse', '可灵'];
      var done = [], todo = [];
      known.forEach(function (p) { if (plats.indexOf(p) !== -1) done.push(p); else todo.push(p); });
      var other = plats.filter(function (p) { return known.indexOf(p) === -1; });
      var platTxt = a.type === 'email'
        ? 'TikTok：' + (done.indexOf('TikTok') !== -1 ? '✓ 已注册' : '○ 未注册') + ' · 已注册：' + (done.concat(other).join('、') || '无') + ' · 未注册：' + (todo.join('、') || '无')
        : (plats.length ? '已接：' + plats.join('、') : '未使用');
      tr.innerHTML = '<td data-label="账号"><span class="label-copy" data-label-copy="' + esc(a.label) + '" title="点一下复制">' + esc(a.label) + '</span></td><td data-label="类型">' + (a.type === 'email' ? '邮箱' : '电话') + '</td><td data-label="平台" style="color:#94a3b8;font-size:12px">' + esc(platTxt) + '</td><td data-label="首次使用" style="color:#64748b;font-size:12px">' + esc(a.firstUse || '—') + '</td>' + (role === 'boss' ? '<td data-label="操作"><button class="ghost" data-storage-del="' + esc(a.label) + '">删除</button></td>' : '');
      tb.appendChild(tr);
    });
    if ($('storageListCount')) $('storageListCount').textContent = '共 ' + res.total + ' 个' + (res.total > res.accounts.length ? '（只显示前 ' + res.accounts.length + ' 个）' : '');
  }).catch(function () {});
}
function runCleanup() {
  api('/api/cleanup', {}, 'POST').then(function (res) {
    if (!res.ok) { toast(res.error || '清理失败'); return; }
    toast(res.removed ? ('已清理 ' + res.removed + ' 个废弃账号') : '没有需要清理的账号');
    refreshCounts(); loadStorageList();
  }).catch(function () { toast('服务未连接'); });
}
// 黑名单（BOSS）：被拉黑的账号
function loadBlacklist() {
  api('/api/blacklist-list').then(function (res) {
    var tb = $('blacklistBody'); if (!tb || !res.ok) return;
    tb.innerHTML = '';
    if (!res.list.length) { tb.innerHTML = '<tr><td colspan="5" style="color:#475569">黑名单是空的</td></tr>'; return; }
    res.list.forEach(function (b) {
      var tr = document.createElement('tr');
      tr.innerHTML = '<td data-label="账号">' + esc(b.label) + '</td><td data-label="类型">' + (b.type === 'email' ? '邮箱' : '电话') + '</td><td data-label="工人">' + esc(b.nickname || '') + '</td><td data-label="时间">' + esc(b.time || '') + '</td><td data-label="操作"><button class="ghost" data-unblacklist="' + esc(b.label) + '">取消拉黑</button></td>';
      tb.appendChild(tr);
    });
  }).catch(function () {});
}
// 当前在用（BOSS）：谁正拿着哪个号、拿了多久、多久没动静，超时的会自动放回
function loadHolds() {
  api('/api/holds').then(function (res) {
    var tb = $('holdsBody'); if (!tb || !res.ok) return;
    tb.innerHTML = '';
    if (!res.holds.length) { tb.innerHTML = '<tr><td colspan="6" style="color:#475569">现在没人拿着账号</td></tr>'; return; }
    res.holds.forEach(function (h) {
      var tr = document.createElement('tr');
      var plats = (h.platforms || []).join('、') || '未使用';
      var warn = h.idleMinutes >= (res.holdTimeoutMinutes || 30) ? ' style="color:#fca5a5;font-weight:700"' : '';
      tr.innerHTML = '<td data-label="账号">' + esc(h.label) + '</td><td data-label="类型">' + (h.type === 'email' ? '邮箱' : '电话') + '</td><td data-label="工人">' + esc(h.nickname) + '</td><td data-label="拿了多久">' + h.heldMinutes + ' 分钟</td><td data-label="多久没动静"' + warn + '>' + h.idleMinutes + ' 分钟</td><td data-label="平台">' + esc(plats) + '</td><td data-label="操作"><button class="ghost" data-hold-release="' + esc(h.label) + '">强制放回</button></td>';
      tb.appendChild(tr);
    });
    if ($('holdsCount')) $('holdsCount').textContent = '共 ' + res.holds.length + ' 个在用 · 超过 ' + (res.holdTimeoutMinutes || 30) + ' 分钟没动静自动放回';
  }).catch(function () {});
}
function loadSettings() {
  api('/api/settings').then(function (res) {
    var inp = $('holdTimeoutInput'); if (!inp || !res.ok) return;
    inp.value = res.holdTimeoutMinutes || 30;
  }).catch(function () {});
}
function saveSettings() {
  var inp = $('holdTimeoutInput'); if (!inp) return;
  api('/api/settings', { holdTimeoutMinutes: parseInt(inp.value, 10) || 30 }, 'POST').then(function (res) {
    if (!res.ok) { toast(res.error || '保存失败'); return; }
    toast('已保存：超过 ' + res.holdTimeoutMinutes + ' 分钟没动静自动放回');
    loadHolds();
  }).catch(function () { toast('服务未连接'); });
}
// 备份（BOSS）：一键备份、下载、删除、恢复
function loadBackups() {
  api('/api/backup-list').then(function (res) {
    var tb = $('backupBody'); if (!tb || !res.ok) return;
    tb.innerHTML = '';
    if (!res.backups.length) { tb.innerHTML = '<tr><td colspan="4" style="color:#475569">还没有备份，点“一键备份”存一份</td></tr>'; return; }
    res.backups.forEach(function (b) {
      var tr = document.createElement('tr');
      var kb = Math.round(b.size / 1024);
      tr.innerHTML = '<td data-label="备份文件">' + esc(b.name) + '</td><td data-label="大小">' + kb + ' KB</td><td data-label="时间">' + esc(b.time) + '</td><td data-label="操作"><div class="rowbtns"><button class="ghost" data-backup-dl="' + esc(b.name) + '">下载</button><button class="ghost" data-backup-del="' + esc(b.name) + '">删除</button></div></td>';
      tb.appendChild(tr);
    });
  }).catch(function () {});
}
function doBackup() {
  api('/api/backup', {}, 'POST').then(function (res) {
    if (!res.ok) { toast(res.error || '备份失败'); return; }
    toast('已备份：' + res.name);
    loadBackups();
  }).catch(function () { toast('服务未连接'); });
}
function downloadBackup(name) {
  fetch(apiBase + '/api/backup-download', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Auth-Token': token }, body: JSON.stringify({ name: name }) }).then(function (r) {
    if (!r.ok) throw new Error('下载失败');
    return r.blob();
  }).then(function (blob) {
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    URL.revokeObjectURL(a.href);
  }).catch(function () { toast('下载失败'); });
}
function deleteBackup(name) {
  if (!confirm('确定删除备份 ' + name + ' 吗？')) return;
  api('/api/backup-delete', { name: name }, 'POST').then(function (res) {
    if (!res.ok) { toast(res.error || '删除失败'); return; }
    toast('已删除'); loadBackups();
  }).catch(function () { toast('服务未连接'); });
}
function doRestore(file) {
  if (!file) return;
  if (!confirm('确定从这个备份恢复吗？现在的数据（账号、工人、使用记录）会被备份里的数据替换。')) { return; }
  fetch(apiBase + '/api/restore', { method: 'POST', headers: { 'X-Auth-Token': token }, body: file }).then(function (r) { return r.json(); }).then(function (res) {
    if (!res.ok) { toast(res.error || '恢复失败'); return; }
    toast('已恢复 ' + (res.restored || []).length + ' 个数据文件');
    refreshCounts(); loadStorageList(); loadPeople(); loadUsage(); loadTakelog(); loadHolds(); loadBackups();
  }).catch(function () { toast('服务未连接'); });
}
// 版本与更新（BOSS）
function loadVersion() {
  api('/api/version').then(function (res) {
    var tag = $('versionTag'); if (tag) tag.textContent = 'v' + (res.version || '?');
    var st = $('updateStatus');
    if (st) {
      if (res.lastUpdate && res.lastUpdate.ok) st.textContent = '当前版本 v' + res.version + '（上次更新 ' + res.lastUpdate.time + ' 成功）';
      else st.textContent = '当前版本 v' + res.version + (res.manifestConfigured ? '' : '（未配置自动更新源，可用下面的一键更新）');
    }
    var up = $('serverStatus');
    if (up) {
      var mins = res.uptimeMinutes || 0;
      var h = Math.floor(mins / 60), m = mins % 60;
      up.textContent = '运行中 · 已运行 ' + (h ? h + ' 小时 ' : '') + m + ' 分钟（启动于 ' + (res.startTime || '') + '）';
    }
  }).catch(function () {});
}
function pollAfterUpdate() {
  var tries = 0;
  var timer = setInterval(function () {
    tries++;
    api('/api/ping').then(function (j) {
      if (j && j.ok) { clearInterval(timer); loadVersion(); toast('更新完成，已重启到新版本'); }
    }).catch(function () {});
    if (tries > 40) { clearInterval(timer); toast('服务还没回来，稍等一下再刷新页面'); }
  }, 3000);
}

// ---------- 锁屏 / 登录 / 注册 ----------
var lockMode = 'worker';
var appStarted = false;
function showLock(mode) {
  lockMode = mode;
  var t = $('lockTitle'), s = $('lockSub'), b = $('lockBtn');
  $('lockErr').textContent = '';
  ['lockNick','lockPwOld','lockPw1','lockPw2','lockCode'].forEach(function (id) { var el = $(id); if (el) el.value = ''; });
  function show(id, on) { var el = $(id); if (el) el.style.display = on ? '' : 'none'; }
  show('lockNick', false); show('lockPwOld', false); show('lockPw2', false); show('lockCode', false);
  show('lockRoleTabs', false); show('lockChange', false); show('lockBack', false);
  ['tabBoss','tabWorker','tabRegister'].forEach(function (id) { var el = $(id); if (el) el.classList.remove('on'); });
  if (mode === 'setup') {
    t.textContent = '小梦云 · 首次设置';
    s.textContent = '设置老板密码（以后用这个密码进 BOSS 端）和邀请码（发给成员注册用）';
    $('lockPw1').placeholder = '老板密码（至少 4 位）';
    show('lockPw2', true); show('lockCode', true);
    $('lockCode').placeholder = '邀请码（至少 4 位，发给成员）';
    b.textContent = '设置并进入';
  } else if (mode === 'boss') {
    t.textContent = '小梦云';
    s.textContent = '老板登录（BOSS 端）';
    $('lockPw1').placeholder = '老板密码';
    show('lockRoleTabs', true); show('lockChange', true);
    var tb = $('tabBoss'); if (tb) tb.classList.add('on');
    b.textContent = '登录';
  } else if (mode === 'worker') {
    t.textContent = '小梦云';
    s.textContent = '成员登录（客户端）';
    show('lockNick', true); show('lockRoleTabs', true); show('lockChange', true);
    $('lockNick').placeholder = '昵称';
    $('lockPw1').placeholder = '密码';
    var tw = $('tabWorker'); if (tw) tw.classList.add('on');
    b.textContent = '登录';
  } else if (mode === 'register') {
    t.textContent = '小梦云 · 注册';
    s.textContent = '找老板要邀请码，注册后用昵称 + 密码登录';
    show('lockNick', true); show('lockPw2', true); show('lockCode', true); show('lockRoleTabs', true);
    $('lockNick').placeholder = '昵称（不能和别人重名）';
    $('lockPw1').placeholder = '密码（至少 4 位）';
    $('lockPw2').placeholder = '再输入一次密码';
    $('lockCode').placeholder = '邀请码';
    var tr = $('tabRegister'); if (tr) tr.classList.add('on');
    b.textContent = '注册';
  } else if (mode === 'change') {
    t.textContent = '修改密码';
    s.textContent = '输入原密码和新密码';
    show('lockPwOld', true); show('lockPw2', true); show('lockBack', true);
    $('lockPw1').placeholder = '新密码（至少 4 位）';
    $('lockPw2').placeholder = '再输入一次新密码';
    b.textContent = '修改密码';
  }
  $('lockScreen').style.display = 'flex';
  setTimeout(function () {
    var f = ($('lockNick').style.display !== 'none') ? $('lockNick') : $('lockPw1');
    if (f) f.focus();
  }, 50);
}
function hideLock() { $('lockScreen').style.display = 'none'; }
function unlockDone(token, r, nick) {
  authToken = token || ''; role = r || ''; nickname = nick || '';
  sessionStorage.setItem('xiaomengyunToken', authToken);
  sessionStorage.setItem('xiaomengyunRole', role);
  sessionStorage.setItem('xiaomengyunNick', nickname);
  hideLock();
  loadView();
}
function lockNow() {
  authToken = ''; role = ''; nickname = '';
  sessionStorage.removeItem('xiaomengyunToken');
  sessionStorage.removeItem('xiaomengyunRole');
  sessionStorage.removeItem('xiaomengyunNick');
  $('app').innerHTML = '';
  appStarted = false;
  showLock('worker');
}
function loadView() {
  api('/api/view').then(function (res) {
    if (!res.ok) { lockNow(); return; }
    role = res.role; nickname = res.nickname;
    $('app').innerHTML = res.html;
    initView();
    if (!appStarted) startApp();
  }).catch(function () { toast('服务未连接'); });
}
function submitLock() {
  var err = $('lockErr'); err.textContent = '';
  var nick = $('lockNick').value.trim();
  var pw1 = $('lockPw1').value, pw2 = $('lockPw2').value, pwOld = $('lockPwOld').value, code = $('lockCode').value.trim();
  if (lockMode === 'setup') {
    if (pw1.length < 4) { err.textContent = '老板密码至少 4 位'; return; }
    if (pw1 !== pw2) { err.textContent = '两次输入的密码不一样'; return; }
    if (code.length < 4) { err.textContent = '邀请码至少 4 位'; return; }
    api('/api/setup', { bossPassword: pw1, regCode: code }, 'POST').then(function (j) {
      if (j.ok) { toast('设置好了'); unlockDone(j.token, 'boss', 'BOSS'); }
      else err.textContent = j.error || '设置失败';
    }).catch(function () { err.textContent = '服务未连接'; });
  } else if (lockMode === 'boss') {
    if (!pw1) { err.textContent = '请输入老板密码'; return; }
    api('/api/auth', { password: pw1 }, 'POST').then(function (j) {
      if (j.ok) unlockDone(j.token, 'boss', 'BOSS');
      else err.textContent = j.error || '密码不对';
    }).catch(function () { err.textContent = '服务未连接'; });
  } else if (lockMode === 'worker') {
    if (!nick) { err.textContent = '请输入昵称'; return; }
    if (!pw1) { err.textContent = '请输入密码'; return; }
    api('/api/worker-auth', { nickname: nick, password: pw1 }, 'POST').then(function (j) {
      if (j.ok) unlockDone(j.token, j.role, j.nickname);
      else err.textContent = j.error || '昵称或密码不对';
    }).catch(function () { err.textContent = '服务未连接'; });
  } else if (lockMode === 'register') {
    if (!nick) { err.textContent = '请输入昵称'; return; }
    if (pw1.length < 4) { err.textContent = '密码至少 4 位'; return; }
    if (pw1 !== pw2) { err.textContent = '两次输入的密码不一样'; return; }
    if (!code) { err.textContent = '请输入邀请码（找老板要）'; return; }
    api('/api/register', { nickname: nick, password: pw1, code: code }, 'POST').then(function (j) {
      if (j.ok) { toast('注册成功，请登录'); showLock('worker'); $('lockNick').value = nick; }
      else err.textContent = j.error || '注册失败';
    }).catch(function () { err.textContent = '服务未连接'; });
  } else if (lockMode === 'change') {
    if (pw1.length < 4) { err.textContent = '新密码至少 4 位'; return; }
    if (pw1 !== pw2) { err.textContent = '两次输入的新密码不一样'; return; }
    var path = role === 'boss' ? '/api/change-boss-password' : '/api/worker-change-password';
    api(path, { oldPassword: pwOld, newPassword: pw1 }, 'POST').then(function (j) {
      if (j.ok) { toast('密码已修改'); hideLock(); }
      else err.textContent = j.error || '修改失败';
    }).catch(function () { err.textContent = '服务未连接'; });
  }
}
function checkServer() {
  return api('/api/ping').then(function (j) {
    serverOK = !!j.ok;
    var el = $('serverOff');
    if (el) el.style.display = serverOK ? 'none' : 'block';
    var an = $('autoNote');
    if (an) an.textContent = serverOK ? '● 自动拉取正常' : '';
    return serverOK;
  }).catch(function () {
    serverOK = false;
    var el = $('serverOff');
    if (el) el.style.display = 'block';
    var an = $('autoNote');
    if (an) an.textContent = '';
    return false;
  });
}
function startApp() {
  appStarted = true;
  load();
  render();
  refreshCounts();
  checkServer();
  if (accounts.length) refreshAll();
  setInterval(function () {
    if (document.visibilityState !== 'visible') return;
    refreshCounts();
    if (autoPaused) return;
    if (!accounts.length) return;
    checkServer().then(function (ok) { if (ok) refreshAll(); });
  }, 20000);
  setInterval(function () {
    var txt = autoPaused ? '已停止' : (nextRefreshIn + ' 秒后访问');
    var cells = document.querySelectorAll('.next-visit');
    for (var i = 0; i < cells.length; i++) cells[i].textContent = txt;
    var el = $('nextRefresh');
    if (el) el.textContent = autoPaused ? '已停止' : ('下次刷新：' + nextRefreshIn + ' 秒');
    if (!autoPaused) { nextRefreshIn--; if (nextRefreshIn <= 0) nextRefreshIn = 20; }
  }, 1000);
}
// 工人页页签：手机号接码 / 邮箱接码（只两个，没有 TikTok 2FA）
function setWorkerTab(type) {
  workerTab = type;
  viewTabFilter = type;
  var tp = $('tabPhone'), te = $('tabEmail');
  if (tp) tp.classList.toggle('on', type === 'phone');
  if (te) te.classList.toggle('on', type === 'email');
  var ca = $('colAccount');
  if (ca) ca.textContent = type === 'phone' ? '手机号' : '邮箱';
  var tpSel = $('takePlatformWrap');
  if (tpSel) tpSel.style.display = type === 'email' ? '' : 'none';
  render();
}
function initView() {
  viewTabFilter = '';
  var wn = $('whoNick'); if (wn) wn.textContent = nickname || '';
  var bl = $('btnLock'); if (bl) bl.onclick = lockNow;
  var sb = $('searchBox'); if (sb) sb.oninput = render;
  var tb = $('tbody'); if (tb) tb.addEventListener('click', onRowClick);
  if ($('btnBatchQr')) $('btnBatchQr').onclick = showBatchQr;
  if ($('qrClose')) $('qrClose').onclick = hideQr;
  if ($('qrModal')) $('qrModal').addEventListener('click', function (e) { if (e.target === $('qrModal')) hideQr(); });
  if ($('btnRefreshAll')) $('btnRefreshAll').onclick = refreshAll;
  if ($('btnExport')) $('btnExport').onclick = exportTxt;
  if ($('btnClearActive')) $('btnClearActive').onclick = clearActive;
  if ($('btnAddEmail')) $('btnAddEmail').onclick = function () { takeOne('email'); };
  if ($('btnAddPhone')) $('btnAddPhone').onclick = function () { takeOne('phone'); };
  var tp = $('tabPhone'), te = $('tabEmail');
  if (tp && te) {
    tp.onclick = function () { setWorkerTab('phone'); };
    te.onclick = function () { setWorkerTab('email'); };
    setWorkerTab('phone');
  }
  if ($('btnTake')) $('btnTake').onclick = function () { takeOne(workerTab); };
  if ($('btnStop')) {
    $('btnStop').onclick = function () {
      autoPaused = !autoPaused;
      $('btnStop').textContent = autoPaused ? '开始接码' : '停止接码';
      render();
    };
  }
  if ($('btnParse')) $('btnParse').onclick = onParse;
  if ($('btnPasteClear')) $('btnPasteClear').onclick = function () { $('pasteBox').value = ''; $('pasteResult').style.display = 'none'; };
  wirePanel('Email'); wirePanel('Phone');
  if ($('peopleBody')) { $('peopleBody').addEventListener('click', onPeopleClick); loadPeople(); }
  if ($('btnSetRegcode')) {
    loadRegcode();
    $('btnSetRegcode').onclick = function () {
      var code = ($('regcodeInput').value || '').trim();
      if (code.length < 4) { toast('邀请码至少 4 位'); return; }
      if (!confirm('把邀请码换成这个吗？旧邀请码马上失效。')) return;
      api('/api/set-regcode', { code: code }, 'POST').then(function (r) {
        if (r.ok) { toast('邀请码已更换，记得发给成员'); $('regcodeInput').value = ''; loadRegcode(); } else toast(r.error || '更换失败');
      }).catch(function () { toast('服务未连接'); });
    };
  }
  if ($('btnCopyRegcode')) {
    $('btnCopyRegcode').onclick = function () {
      var code = $('regcodeNow') ? $('regcodeNow').textContent : '';
      if (!code || code === '未设置') { toast('还没设置邀请码'); return; }
      if (navigator.clipboard) navigator.clipboard.writeText(code).then(function () { toast('邀请码已复制'); });
      else toast(code);
    };
  }
  if ($('btnCopyLink')) {
    $('btnCopyLink').onclick = function () {
      var link = $('shareLink') ? $('shareLink').textContent : '';
      if (!link || link.indexOf('http') !== 0) { toast('链接还没生成'); return; }
      if (navigator.clipboard) navigator.clipboard.writeText(link).then(function () { toast('链接已复制'); });
      else toast(link);
    };
    loadShareLink();
  }
  if ($('btnCopyLan')) {
    $('btnCopyLan').onclick = function () {
      var link = $('lanLink') ? $('lanLink').textContent : '';
      if (!link || link.indexOf('http') !== 0) { toast('内网链接还没生成'); return; }
      if (navigator.clipboard) navigator.clipboard.writeText(link).then(function () { toast('内网链接已复制'); });
      else toast(link);
    };
  }
  if ($('takelogBody')) {
    $('takelogBody').addEventListener('click', function (e) {
      var t = e.target;
      if (t.dataset.takelogRelease) {
        var label = t.dataset.takelogRelease;
        if (!confirm('把 ' + label + ' 从取走的人那里收回来吗？邮箱放回仓库，电话如果已用过会直接废弃。')) return;
        api('/api/release', { label: label }, 'POST').then(function (r) { toast(r.ok ? (r.discarded ? '已收回并废弃' : '已收回仓库') : (r.error || '失败')); loadTakelog(); refreshCounts(); });
      }
    });
    loadTakelog();
  }
  if ($('storageListBody')) {
    $('storageListBody').addEventListener('click', function (e) {
      var t = e.target;
      if (t.dataset.labelCopy) { copyText(t.dataset.labelCopy, '已复制邮箱'); return; }
      if (t.dataset.storageDel) {
        var label = t.dataset.storageDel;
        if (!confirm('删除 ' + label + ' 吗？')) return;
        api('/api/storage-delete', { label: label }, 'POST').then(function (r) { toast(r.ok ? '已删除' : (r.error || '删除失败')); loadStorageList(); refreshCounts(); });
      }
    });
    loadStorageList();
  }
  if ($('usageBody')) loadUsage();
  if ($('btnCleanup')) $('btnCleanup').onclick = function () { if (confirm('现在清理仓库吗？只清废弃/过期的账号，能用的不会动。')) runCleanup(); };
  if ($('btnBossQr')) $('btnBossQr').onclick = showBossQr;
  if ($('takePlatform')) $('takePlatform').onchange = function () { takeNeedPlatform = $('takePlatform').value; };
  if ($('blacklistBody')) {
    $('blacklistBody').addEventListener('click', function (e) {
      var t = e.target;
      if (t.dataset.unblacklist) {
        var label = t.dataset.unblacklist;
        if (!confirm('取消拉黑 ' + label + ' 吗？取消后需要重新导入才能进仓库。')) return;
        api('/api/blacklist-remove', { label: label }, 'POST').then(function (r) { toast(r.ok ? '已取消拉黑' : (r.error || '失败')); loadBlacklist(); });
      }
    });
    loadBlacklist();
  }
  if ($('holdsBody')) {
    $('holdsBody').addEventListener('click', function (e) {
      var t = e.target;
      if (t.dataset.holdRelease) {
        var label = t.dataset.holdRelease;
        if (!confirm('把 ' + label + ' 从拿着的人那里强制收回来吗？邮箱放回仓库，电话如果已用过会直接废弃。')) return;
        api('/api/release', { label: label }, 'POST').then(function (r) { toast(r.ok ? (r.discarded ? '已收回并废弃' : '已收回仓库') : (r.error || '失败')); loadHolds(); loadTakelog(); refreshCounts(); });
      }
    });
    loadHolds();
    setInterval(function () { if (role === 'boss') loadHolds(); }, 60000);
  }
  if ($('holdTimeoutInput')) { loadSettings(); }
  if ($('btnSaveSettings')) $('btnSaveSettings').onclick = saveSettings;
  if ($('backupBody')) {
    $('backupBody').addEventListener('click', function (e) {
      var t = e.target;
      if (t.dataset.backupDl) { downloadBackup(t.dataset.backupDl); return; }
      if (t.dataset.backupDel) { deleteBackup(t.dataset.backupDel); return; }
    });
    loadBackups();
  }
  if ($('btnBackup')) $('btnBackup').onclick = doBackup;
  var fri = $('fileRestore');
  if (fri) {
    fri.onchange = function () {
      var f = fri.files && fri.files[0];
      fri.value = '';
      if (f) doRestore(f);
    };
  }
  var brb = $('btnRestoreFile');
  if (brb && fri) { brb.onclick = function () { fri.click(); }; }
  function doUpdateFromLink(url) {
    if (!confirm('现在更新吗？更新时会重启服务，正在用的工人会断开几秒，账号和记录不会动。')) return;
    var st = $('updateStatus'); if (st) st.textContent = '正在下载更新包…';
    api('/api/update-from-link', { url: url }, 'POST').then(function (res) {
      if (!res.ok) { toast(res.error || '更新失败'); if (st) st.textContent = '更新失败：' + (res.error || ''); return; }
      if (st) st.textContent = '更新包已就绪，正在重启服务…';
      setTimeout(pollAfterUpdate, 3000);
    }).catch(function () { if (st) st.textContent = '正在重启服务…'; setTimeout(pollAfterUpdate, 3000); });
  }
  if ($('btnCheckUpdate')) {
    loadVersion();
    $('btnCheckUpdate').onclick = function () {
      var st = $('updateStatus'); if (st) st.textContent = '正在检查更新…';
      api('/api/check-update', {}, 'POST').then(function (res) {
        if (!st) return;
        if (!res.configured) { st.textContent = '没有配置自动更新源（update.json 里的 manifestUrl 为空），请用下面的一键更新。'; return; }
        if (res.error) { st.textContent = '检查失败：' + res.error + '。可以改用下面的一键更新。'; return; }
        if (res.updateAvailable) {
          st.textContent = '发现新版 v' + res.version + '（当前 v' + res.current + '）：' + (res.notes || '');
          if (res.downloadUrl) {
            var inp = $('updateLink'); if (inp) inp.value = res.downloadUrl;
            st.textContent += ' 新版下载链接已填到下面，点「更新」即可一键更新。';
            if (confirm('发现新版 v' + res.version + '，现在更新吗？更新时会重启服务，账号和记录不会动。')) doUpdateFromLink(res.downloadUrl);
          } else {
            st.textContent += ' 清单里没有下载地址，请把新版链接粘到下面更新。';
          }
        }
        else st.textContent = '已是最新版 v' + res.current + '。';
      }).catch(function () { if (st) st.textContent = '检查失败，服务未连接。'; });
    };
  }
  if ($('btnUpdateLink')) {
    $('btnUpdateLink').onclick = function () {
      var url = ($('updateLink').value || '').trim();
      if (!url) { toast('先粘贴新版下载链接'); return; }
      doUpdateFromLink(url);
    };
  }
  var fub = $('btnUpdateFile'), fui = $('fileUpdate');
  if (fub && fui) {
    fub.onclick = function () { fui.click(); };
    fui.onchange = function () {
      var f = fui.files[0]; if (!f) return;
      if (!confirm('用这个更新包更新吗？更新时会重启服务，账号和记录不会动。')) { fui.value = ''; return; }
      var st = $('updateStatus'); if (st) st.textContent = '正在上传更新包…';
      fetch(apiBase + '/api/update-upload', { method: 'POST', headers: authHeaders(), body: f }).then(function (r) { return r.json(); }).then(function (res) {
        if (!res.ok) { toast(res.error || '更新失败'); if (st) st.textContent = '更新失败：' + (res.error || ''); return; }
        if (st) st.textContent = '更新包已就绪，正在重启服务…';
        setTimeout(pollAfterUpdate, 3000);
      }).catch(function () { if (st) st.textContent = '正在重启服务…'; setTimeout(pollAfterUpdate, 3000); });
      fui.value = '';
    };
  }
  refreshCounts();
}
function boot() {
  api('/api/auth-status').then(function (j) {
    if (!j.hasBossPassword) { showLock('setup'); return; }
    if (j.unlocked && j.role) { unlockDone(authToken, j.role, j.nickname); return; }
    showLock(sessionStorage.getItem('xiaomengyunRole') === 'boss' ? 'boss' : 'worker');
  }).catch(function () { showLock('worker'); });
}

$('lockBtn').onclick = submitLock;
$('tabBoss').onclick = function () { showLock('boss'); };
$('tabWorker').onclick = function () { showLock('worker'); };
$('tabRegister').onclick = function () { showLock('register'); };
$('lockChange').onclick = function () { showLock('change'); };
$('lockBack').onclick = function () { showLock(role === 'boss' ? 'boss' : 'worker'); };
['lockNick','lockPw1','lockPw2','lockPwOld','lockCode'].forEach(function (id) {
  var el = $(id); if (el) el.addEventListener('keydown', function (e) { if (e.key === 'Enter') submitLock(); });
});
probeLan().then(function () { boot(); });
</script>
</body>
</html>
'@

# ================= 视图：工人 / 管理员 / BOSS =================
$WorkAreaCard = @'
<section class="card">
  <div class="panel-head">
    <div>
      <h2>我的工作区 <span class="auto" id="autoNote"></span></h2>
      <p class="sub">取出来的账号在这里自动拉验证码 · 每 20 秒自动刷新</p>
    </div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <input type="search" id="searchBox" placeholder="搜索邮箱 / 手机号...">
    </div>
  </div>
  <div class="btns">
    <button id="btnAddEmail">＋ 添加邮箱</button>
    <button id="btnAddPhone">＋ 添加电话号码</button>
    <button class="ghost" id="btnRefreshAll">刷新全部</button>
    <button class="ghost" id="btnExport">导出 TXT</button>
    <button class="danger" id="btnClearActive">清空工作区</button>
  </div>
  <div class="hint" id="fetchHint"></div>
  <table>
    <thead><tr><th>账号</th><th>验证码</th><th>状态</th><th>来源</th><th>下次访问</th><th>操作</th></tr></thead>
    <tbody id="tbody"></tbody>
  </table>
  <div class="empty-tip" id="emptyTip">工作区是空的，点上面“＋ 添加邮箱 / 电话”取一个出来</div>
</section>
'@

$PasteCard = @'
<section class="card">
  <h2>粘贴邮件 / 短信 <span class="tag">INBOX</span></h2>
  <p class="sub">备用方式：自动拉取不到时，把收到的邮件全文或短信内容粘贴到这里识别</p>
  <textarea id="pasteBox" placeholder="粘贴收件箱页面的内容或短信原文。&#10;例如：您的验证码是 499826，5 分钟内有效。"></textarea>
  <div class="btns">
    <button id="btnParse">识别并填入验证码</button>
    <button class="ghost" id="btnPasteClear">清空内容</button>
  </div>
  <div class="paste-result" id="pasteResult"></div>
</section>
'@

$ViewWorker = @'
<header>
  <h1><img class="head-logo" src="/icon.png" alt="" onerror="this.style.display='none'">小梦云 <span class="role-badge">客户端</span></h1>
  <div style="display:flex;gap:8px;align-items:center">
    <span class="badge-top" id="whoNick"></span>
    <button class="ghost" id="btnRefreshAll">刷新</button>
    <button class="ghost" id="btnLock">退出登录</button>
  </div>
</header>
<div class="server-off" id="serverOff">服务未连接：请检查主机有没有开着。</div>
<div class="tabs">
  <button id="tabPhone" class="on">手机号接码</button>
  <button id="tabEmail">邮箱接码</button>
</div>
<div class="btns" style="margin:0 0 12px">
  <button id="btnTake">获取号码</button>
  <span id="takePlatformWrap" style="display:none">
    <select id="takePlatform" class="txtin">
      <option value="">任意平台</option>
      <option value="TikTok">要注册 TikTok</option>
      <option value="PixVerse">要注册 PixVerse</option>
      <option value="可灵">要注册 可灵</option>
    </select>
  </span>
  <button class="ghost" id="btnStop">停止接码</button>
  <button class="ghost" id="btnClearActive">清空列表</button>
  <button class="ghost" id="btnBatchQr">生成二维码</button>
  <span class="pill" id="activeCount" style="margin-left:auto">接码中 · 0 个号码</span>
</div>
<section class="card">
  <div class="panel-head">
    <div><h2>接码列表 <span class="auto" id="autoNote"></span></h2></div>
  </div>
  <div class="hint" id="fetchHint"></div>
  <table>
    <thead><tr><th id="colAccount">手机号</th><th>验证码</th><th>状态</th><th>来源</th><th>下次访问</th><th>操作</th></tr></thead>
    <tbody id="tbody"></tbody>
  </table>
  <div class="empty-tip" id="emptyTip">还没有号码，点[获取号码]开始接码</div>
</section>
'@ + $PasteCard + @'
<section class="card">
  <h2>使用说明</h2>
  <ol class="help">
    <li>点「获取号码」，点一次取一个出来，用几个点几次。邮箱页签可以选要注册的平台（TikTok / PixVerse / 可灵），只取还没注册过那个平台的邮箱。</li>
    <li>取出来就自动拉验证码，点一下验证码就能复制。</li>
    <li>电话号码只能用一个平台：用完点「确认」，号码立即废弃；没收到码点「释放」可以放回仓库。</li>
    <li>邮箱可以给三个平台用：每收到一个平台的码，勾自动打上；三个勾全满就废弃了。用完一个平台就点「释放」放回仓库，别人还能用剩下的平台。</li>
    <li>勾也可以手动点：没经过工具收码、或者打错了，点一下改过来。</li>
    <li>用完点那一行的「释放」放回仓库，或点「清空列表」一次清光（已经用过的电话会直接废弃）。</li>
    <li>一次取太多会变慢，一般一次取几个就够了。</li>
  </ol>
</section>
'@

$PanelEmailAdmin = @'
<section class="card">
  <h2>邮箱仓库 <span class="tag">EMAIL</span></h2>
  <p class="sub">一次粘贴很多个存进去，不设上限。也可以选一个 .txt 文档整份导入（一行一个「账号----链接」）。</p>
  <textarea id="importEmail" placeholder="邮箱----收件箱链接，一行一个&#10;也可以只写邮箱（没有链接的存进去取不出来）&#10;例如：sample@icloud.com----https://mail.niantu.xyz/mail/xxxx"></textarea>
  <div class="btns">
    <button id="btnImportEmail">存入邮箱仓库</button>
    <button class="ghost" id="btnAppendEmail">追加</button>
    <button class="ghost" id="btnFileEmail">选择文档导入</button>
    <input type="file" id="fileEmail" accept=".txt" style="display:none">
    <button class="ghost" id="btnExampleEmail">填示例</button>
    <button class="ghost" id="btnClearImportEmail">清空输入框</button>
  </div>
  <p class="note" id="storeNoteEmail"></p>
</section>
'@

$PanelPhoneAdmin = @'
<section class="card">
  <h2>电话仓库 <span class="tag">PHONE</span></h2>
  <p class="sub">一次粘贴很多个存进去，不设上限。也可以选一个 .txt 文档整份导入（一行一个「账号----链接」）。</p>
  <textarea id="importPhone" placeholder="手机号----接口地址，一行一个&#10;也可以只写手机号（没有链接的存进去取不出来）&#10;例如：+17150000000----https://api.sms8.net/api/record?token=xxxx"></textarea>
  <div class="btns">
    <button id="btnImportPhone">存入电话仓库</button>
    <button class="ghost" id="btnAppendPhone">追加</button>
    <button class="ghost" id="btnFilePhone">选择文档导入</button>
    <input type="file" id="filePhone" accept=".txt" style="display:none">
    <button class="ghost" id="btnExamplePhone">填示例</button>
    <button class="ghost" id="btnClearImportPhone">清空输入框</button>
  </div>
  <p class="note" id="storeNotePhone"></p>
</section>
'@

$PanelEmailBoss = @'
<section class="card">
  <h2>邮箱仓库 <span class="tag">EMAIL</span></h2>
  <p class="sub">一次粘贴很多个存进去，不设上限。也可以选一个 .txt 文档整份导入（一行一个「账号----链接」）。</p>
  <textarea id="importEmail" placeholder="邮箱----收件箱链接，一行一个&#10;也可以只写邮箱（没有链接的存进去取不出来）&#10;例如：sample@icloud.com----https://mail.niantu.xyz/mail/xxxx"></textarea>
  <div class="btns">
    <button id="btnImportEmail">存入邮箱仓库</button>
    <button class="ghost" id="btnAppendEmail">追加</button>
    <button class="ghost" id="btnFileEmail">选择文档导入</button>
    <input type="file" id="fileEmail" accept=".txt" style="display:none">
    <button class="ghost" id="btnExampleEmail">填示例</button>
    <button class="ghost" id="btnClearImportEmail">清空输入框</button>
    <button class="danger" id="btnClearEmail">清空邮箱仓库</button>
  </div>
  <div class="btns">
    <input id="delLabelEmail" class="txtin" placeholder="输入要删除的邮箱" style="width:260px">
    <button class="ghost" id="btnDelEmail">删除这个邮箱</button>
  </div>
  <p class="note" id="storeNoteEmail"></p>
</section>
'@

$PanelPhoneBoss = @'
<section class="card">
  <h2>电话仓库 <span class="tag">PHONE</span></h2>
  <p class="sub">一次粘贴很多个存进去，不设上限。也可以选一个 .txt 文档整份导入（一行一个「账号----链接」）。</p>
  <textarea id="importPhone" placeholder="手机号----接口地址，一行一个&#10;也可以只写手机号（没有链接的存进去取不出来）&#10;例如：+17150000000----https://api.sms8.net/api/record?token=xxxx"></textarea>
  <div class="btns">
    <button id="btnImportPhone">存入电话仓库</button>
    <button class="ghost" id="btnAppendPhone">追加</button>
    <button class="ghost" id="btnFilePhone">选择文档导入</button>
    <input type="file" id="filePhone" accept=".txt" style="display:none">
    <button class="ghost" id="btnExamplePhone">填示例</button>
    <button class="ghost" id="btnClearImportPhone">清空输入框</button>
    <button class="danger" id="btnClearPhone">清空电话仓库</button>
  </div>
  <div class="btns">
    <input id="delLabelPhone" class="txtin" placeholder="输入要删除的手机号" style="width:260px">
    <button class="ghost" id="btnDelPhone">删除这个号码</button>
  </div>
  <p class="note" id="storeNotePhone"></p>
</section>
'@

$StorageListCardAdmin = @'
<section class="card">
  <div class="panel-head">
    <div><h2>仓库账号 <span class="tag" id="storageListCount"></span></h2>
    <p class="sub">每个账号已注册/未注册哪些平台、首次使用时间（只读）</p></div>
    <button class="ghost" id="btnCleanup">清理</button>
  </div>
  <table>
    <thead><tr><th>账号</th><th>类型</th><th>平台</th><th>首次使用</th></tr></thead>
    <tbody id="storageListBody"></tbody>
  </table>
</section>
'@

$StorageListCardBoss = @'
<section class="card">
  <div class="panel-head">
    <div><h2>仓库账号 <span class="tag" id="storageListCount"></span></h2>
    <p class="sub">每个账号已注册/未注册哪些平台、首次使用时间。清理只清废弃/过期的，能用的不会动。</p></div>
    <button class="ghost" id="btnBossQr">生成二维码</button>
    <button class="ghost" id="btnCleanup">清理</button>
  </div>
  <table>
    <thead><tr><th>账号</th><th>类型</th><th>平台</th><th>首次使用</th><th>操作</th></tr></thead>
    <tbody id="storageListBody"></tbody>
  </table>
</section>
'@

$UsageCard = @'
<section class="card">
  <h2>使用记录</h2>
  <p class="sub">哪个账号用过哪个平台、谁用的、什么时候（只读，清理仓库也不会删掉这里）</p>
  <table>
    <thead><tr><th>账号</th><th>平台</th><th>谁用的</th><th>时间</th></tr></thead>
    <tbody id="usageBody"></tbody>
  </table>
</section>
'@

$StatsRow = @'
<div class="stats">
  <div class="stat"><b id="stActive">0</b><span>工作区账号</span></div>
  <div class="stat"><b id="stGot">0</b><span>已收到验证码</span></div>
  <div class="stat"><b id="stStoreEmail">0</b><span>仓库邮箱</span></div>
  <div class="stat"><b id="stStorePhone">0</b><span>仓库电话</span></div>
</div>
'@

$ViewAdmin = @'
<header>
  <h1><img class="head-logo" src="/icon.png" alt="" onerror="this.style.display='none'">小梦云 <span class="role-badge">管理员端</span></h1>
  <div style="display:flex;gap:8px;align-items:center">
    <span class="badge-top" id="whoNick"></span>
    <button class="ghost" id="btnLock">退出登录</button>
  </div>
</header>
<div class="server-off" id="serverOff">服务未连接：请检查主机有没有开着。</div>
<p class="note-warn">你是管理员：只能添加邮箱和电话号码到仓库，不能删除仓库、不能管理成员、不能改邀请码。</p>
<div class="wrap">
'@ + $PanelEmailAdmin + $PanelPhoneAdmin + @'
</div>
'@ + $StorageListCardAdmin + $UsageCard + $StatsRow + $WorkAreaCard + $PasteCard + @'
<section class="card">
  <h2>使用说明</h2>
  <ol class="help">
    <li>邮箱和电话号码分两个面板，各管各的。一次粘贴很多个存进去，不设上限；也可以选 .txt 文档整份导入。</li>
    <li>电话号码只能用一个平台，工人用完点「确认」就废弃；邮箱可以给三个平台（TikTok / PixVerse / 可灵）用，满 3 个平台自动废弃，注册过 1 个平台以上、首次使用超过 3 天的也会在清理时清掉，没注册过的永远不清理。</li>
    <li>仓库账号列表里能看到每个账号已注册/未注册哪些平台；使用记录里能看到谁在什么时候用了哪个平台。</li>
    <li>点「清理」可以马上清理一次仓库（只清废弃/过期的，能用的不会动）。</li>
    <li>取出来的账号在「我的工作区」里自动拉验证码，和工人一样用。</li>
  </ol>
</section>
'@

$ViewBoss = @'
<header>
  <h1><img class="head-logo" src="/icon.png" alt="" onerror="this.style.display='none'">小梦云 <span class="role-badge">BOSS端</span></h1>
  <div style="display:flex;gap:8px;align-items:center">
    <span class="badge-top">BOSS</span>
    <button class="ghost" id="btnLock">退出登录</button>
  </div>
</header>
<div class="server-off" id="serverOff">服务未连接：请检查主机有没有开着。</div>
<section class="card" style="border-color:#b45309">
  <h2>分享链接 <span class="tag">SHARE</span></h2>
  <p class="sub">把这个链接发给成员，他们打开就能注册登录。</p>
  <div class="share-box" style="font-size:17px;font-weight:700"><span id="shareLink">隧道正在生成…</span></div>
  <div class="btns"><button id="btnCopyLink" disabled>复制链接</button></div>
  <p style="color:#fbbf24;font-size:13px;font-weight:700;margin:8px 0 0">⚠️ 主机每次重启后这个链接都会变，要重新发给工人。</p>
  <p style="color:#fbbf24;font-size:13px;font-weight:700;margin:4px 0 0">⚠️ 如果主屏幕图标是用上面这个隧道链接加的，链接一变图标就打不开了，要删掉图标重新加一次；用下面内网链接加的图标不会有这个问题。</p>
  <p class="sub" style="margin-top:12px">内网链接（稳定，添加到主屏幕用这个）：</p>
  <div class="share-box" style="font-size:15px;font-weight:700"><span id="lanLink">—</span></div>
  <div class="btns"><button id="btnCopyLan" disabled>复制内网链接</button></div>
  <p class="sub" style="margin-top:6px">📱 添加到主屏幕（默认用内网链接）：手机和主机连同一个 Wi-Fi，先用下面这个内网链接打开，再点浏览器「分享 → 添加到主屏幕」，图标就是小梦云 logo，点图标直接进 BOSS 页，不用再找链接。内网链接不会变（主机 IP 不变的话）；隧道链接每次重启都会变，用它加的图标失效后要重新加一次。</p>
  <p class="sub" id="serverStatus" style="margin-top:6px">运行状态：正在连接…</p>
  <p class="sub" style="margin-top:2px">主机电脑要一直开着，关了工人就用不了。已设开机自启，重启电脑后小梦云会自动跑起来。</p>
</section>
<section class="card">
  <h2>备份 <span class="tag">BACKUP</span></h2>
  <p class="sub">备份账号、工人、密码、使用记录。每天自动存一份（只留最近 7 份），也可以随时手动备份。备份文件存在工具文件夹里的 backups/，不在数据文件夹里，更新程序时不会动它。</p>
  <div class="btns">
    <button id="btnBackup">一键备份</button>
    <button class="ghost" id="btnRestoreFile">从备份恢复…</button>
    <input type="file" id="fileRestore" accept=".zip" style="display:none">
  </div>
  <table>
    <thead><tr><th>备份文件</th><th>大小</th><th>时间</th><th>操作</th></tr></thead>
    <tbody id="backupBody"></tbody>
  </table>
</section>
<section class="card">
  <h2>版本与更新 <span class="tag" id="versionTag">v1.0.0</span></h2>
  <p class="sub" id="updateStatus">正在检查…</p>
  <div class="btns">
    <button id="btnCheckUpdate">检查更新</button>
  </div>
  <p class="sub" style="margin-top:14px">一键更新：粘贴新版下载链接，或者选一个已下载的 .zip 更新包，点更新后工具会自动替换程序文件并重启（账号、工人、记录都不会动）。</p>
  <div class="btns">
    <input id="updateLink" class="txtin" placeholder="粘贴新版下载链接（https://…zip）" style="width:320px">
    <button id="btnUpdateLink">更新</button>
    <button class="ghost" id="btnUpdateFile">选择更新包 (.zip)</button>
    <input type="file" id="fileUpdate" accept=".zip" style="display:none">
  </div>
</section>
<div class="wrap">
'@ + $PanelEmailBoss + $PanelPhoneBoss + @'
</div>
'@ + $StorageListCardBoss + $UsageCard + $StatsRow + $WorkAreaCard + $PasteCard + @'
<section class="card">
  <h2>人员管理 <span class="tag" id="peopleCount"></span></h2>
  <p class="sub">点一下就能设管理员、停用、删除。停用或删除后那个人马上登录不进来。</p>
  <table>
    <thead><tr><th>昵称</th><th>角色</th><th>状态</th><th>注册时间</th><th>余额</th><th>操作</th></tr></thead>
    <tbody id="peopleBody"></tbody>
  </table>
</section>
<section class="card">
  <h2>邀请码</h2>
  <p class="sub">成员注册要用这个码。换了码之后，旧码就注册不了了，已经注册的人不受影响。</p>
  <p>当前邀请码：<b id="regcodeNow" style="color:#4ade80;letter-spacing:2px">未设置</b> <button class="ghost" id="btnCopyRegcode">复制</button></p>
  <div class="btns">
    <input id="regcodeInput" class="txtin" placeholder="输入新邀请码（至少 4 位）" style="width:220px">
    <button id="btnSetRegcode">更换邀请码</button>
  </div>
</section>
<section class="card">
  <h2>当前在用 <span class="tag" id="holdsCount"></span></h2>
  <p class="sub">谁正拿着哪个号、拿了多久、多久没动静。拿了超过下面这个时间还没动静（没收到码、没确认、没释放），服务器会自动放回仓库。</p>
  <div class="btns">
    <label style="color:#94a3b8;font-size:13px">超时自动放回：<input id="holdTimeoutInput" class="txtin" type="number" min="5" max="1440" value="30" style="width:80px"> 分钟</label>
    <button id="btnSaveSettings">保存</button>
    <button class="ghost" onclick="loadHolds()">刷新</button>
  </div>
  <table>
    <thead><tr><th>账号</th><th>类型</th><th>谁拿着</th><th>拿了多久</th><th>多久没动静</th><th>平台</th><th>操作</th></tr></thead>
    <tbody id="holdsBody"></tbody>
  </table>
</section>
<section class="card">
  <h2>取用记录</h2>
  <p class="sub">谁取了哪个账号（最近 50 条）。点「释放」可以把账号从取走的人那里收回来。</p>
  <table>
    <thead><tr><th>账号</th><th>类型</th><th>谁取的</th><th>时间</th><th>操作</th></tr></thead>
    <tbody id="takelogBody"></tbody>
  </table>
</section>
<section class="card">
  <h2>黑名单</h2>
  <p class="sub">被拉黑的账号永远不会再被取出来。点「取消拉黑」后，需要重新导入才能进仓库。</p>
  <table>
    <thead><tr><th>账号</th><th>类型</th><th>谁拉黑的</th><th>时间</th><th>操作</th></tr></thead>
    <tbody id="blacklistBody"></tbody>
  </table>
</section>
<section class="card">
  <h2>使用说明</h2>
  <ol class="help">
    <li>你是 BOSS：加账号、删账号、管人、改邀请码、看使用记录，都在这里。</li>
    <li>电话号码只能用一个平台，工人用完点「确认」就废弃；邮箱可以给三个平台（TikTok / PixVerse / 可灵）用，满 3 个平台自动废弃，注册过 1 个平台以上、首次使用超过 3 天的也会在清理时清掉，没注册过的永远不清理。</li>
    <li>服务器每天自动清理一次仓库，启动时也会清一次；点「清理」可以马上清理一次。</li>
    <li>仓库账号列表里能看到每个账号已注册/未注册哪些平台；使用记录里能看到谁在什么时候用了哪个平台，清理仓库不会删掉使用记录。</li>
    <li>管理员只能添加账号，不能踢人、不能删仓库、不能改邀请码。</li>
    <li>拿号超时：工人拿了账号超过 30 分钟（可在“当前在用”里改）还没动静，服务器自动放回仓库；BOSS 在“当前在用”里能看到谁拿着哪个号、拿了多久，也能强制放回。</li>
    <li>备份：每天自动备份一次（只留最近 7 份），也可以点“一键备份”随时存一份；备份文件在工具文件夹里的 backups/，恢复时选一个备份 zip 就能把账号、工人、使用记录都恢复回来。</li>
    <li>手机后台：手机和主机连同一个 Wi-Fi，用分享链接卡里的内网链接打开，再点浏览器「分享 → 添加到主屏幕」，就能在手机桌面多个小梦云图标，点图标直接进 BOSS 页。内网链接不会变，隧道链接每次重启都会变。</li>
  </ol>
</section>
'@

# ================= 路由（主循环里每来一个请求调一次） =================
function Invoke-Request($method, $path, $headers, $body, $bodyBytes, $stream) {
    $req = $null
    if ($body) { try { $req = $body | ConvertFrom-Json } catch { $req = $null } }

    if ($method -eq 'OPTIONS') {
        Send-Response $stream 'text/plain' ''
    } elseif ($method -eq 'GET' -and ($path -eq '/' -or $path -eq '/index.html')) {
        Send-Response $stream 'text/html' $HtmlShellServed
    } elseif ($method -eq 'GET' -and $path -eq '/manifest.json') {
        $man = @{ name = '小梦云'; short_name = '小梦云'; description = '小梦云 - 验证码工具（BOSS / 管理员 / 工人）'; display = 'standalone'; background_color = '#0b1220'; theme_color = '#0b1220'; start_url = '/'; icons = @(@{ src = '/icon-192.png'; sizes = '192x192'; type = 'image/png' }, @{ src = '/icon-512.png'; sizes = '512x512'; type = 'image/png' }) } | ConvertTo-Json -Compress -Depth 4
        Send-Response $stream 'application/manifest+json' $man
    } elseif ($method -eq 'GET' -and ($path -eq '/icon.png' -or $path -eq '/favicon.ico' -or $path -eq '/icon-192.png' -or $path -eq '/icon-512.png')) {
        $iconPath = $IconFile
        if ($path -eq '/icon-192.png') { $iconPath = Join-Path $PSScriptRoot 'icon-192.png' }
        if ($path -eq '/icon-512.png') { $iconPath = Join-Path $PSScriptRoot 'icon-512.png' }
        if (Test-Path $iconPath) {
            $ib = [System.IO.File]::ReadAllBytes($iconPath)
            Send-BinaryResponse $stream 'image/png' $ib 86400
        } else {
            Send-Response $stream 'text/plain' 'Not Found'
        }
    } elseif ($method -eq 'GET' -and $path -like '/e/*') {
        $token = ''
        if ($path -match '^/e/([A-Za-z0-9]+)$') { $token = $Matches[1] }
        $share = $null
        if ($token) { $share = Get-QrShare $token }
        Send-Response $stream 'text/html' (Get-QrSharePage $share)
    } elseif ($method -eq 'GET' -and $path -eq '/api/ping') {
        Send-Response $stream 'application/json' '{"ok":true}'
    } elseif ($method -eq 'GET' -and $path -eq '/api/auth-status') {
        $r = Get-RequestRole $headers
        $st = @{ hasBossPassword = (-not [string]::IsNullOrEmpty((Get-BossHash))); hasRegCode = (-not [string]::IsNullOrEmpty((Get-RegCode))); unlocked = ($null -ne $r); role = ''; nickname = '' }
        if ($null -ne $r) { $st.role = $r.role; $st.nickname = $r.nickname }
        Send-Response $stream 'application/json' ($st | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/setup') {
        $res = @{ ok = $false; error = ''; token = '' }
        try {
            if (-not [string]::IsNullOrEmpty((Get-BossHash))) { $res.error = '已经设置过了' }
            else {
                $pw = [string]$req.bossPassword; $code = [string]$req.regCode
                if ($pw.Length -lt 4) { $res.error = '老板密码至少 4 位' }
                elseif ($code.Length -lt 4) { $res.error = '邀请码至少 4 位' }
                else { Set-BossHash (New-PasswordHash $pw); Set-RegCode $code; $res.ok = $true; $res.token = $script:BossToken }
            }
        } catch { $res.error = $_.Exception.Message }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/auth') {
        $res = @{ ok = $false; error = ''; token = ''; role = ''; nickname = '' }
        try {
            $hash = Get-BossHash
            if ([string]::IsNullOrEmpty($hash)) { $res.error = '还没设置老板密码' }
            else {
                $chk = Test-PasswordHash ([string]$req.password) $hash
                if ($chk -eq 'bad') { $res.error = '密码不对' }
                else {
                    if ($chk -eq 'ok-legacy') { try { Set-BossHash (New-PasswordHash ([string]$req.password)) } catch { } }
                    $res.ok = $true; $res.token = $script:BossToken; $res.role = 'boss'; $res.nickname = 'BOSS'
                }
            }
        } catch { $res.error = $_.Exception.Message }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/register') {
        $res = @{ ok = $false; error = '' }
        try {
            $nick = ([string]$req.nickname).Trim()
            $pw = [string]$req.password
            $code = [string]$req.code
            $reg = Get-RegCode
            if ([string]::IsNullOrEmpty($reg)) { $res.error = '老板还没设置邀请码，找老板要' }
            elseif ($nick.Length -lt 1 -or $nick.Length -gt 20) { $res.error = '昵称要 1 到 20 个字' }
            elseif ($pw.Length -lt 4) { $res.error = '密码至少 4 位' }
            elseif ($code -cne $reg) { $res.error = '邀请码不对，找老板要正确的' }
            elseif ($null -ne (Find-Worker $nick)) { $res.error = '这个昵称已经被用了，换一个' }
            else {
                $workers = @(Read-JsonArray $WorkersFile)
                $workers += @{ nickname = $nick; hash = (New-PasswordHash $pw); created = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); enabled = $true; role = 'worker'; balance = $null }
                Save-Workers $workers
                $res.ok = $true
            }
        } catch { $res.error = $_.Exception.Message }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/worker-auth') {
        $res = @{ ok = $false; error = ''; token = ''; role = ''; nickname = '' }
        try {
            $nick = ([string]$req.nickname).Trim()
            $w = Find-Worker $nick
            if ($null -eq $w) { $res.error = '没有这个昵称，先注册' }
            elseif (-not $w.enabled) { $res.error = '这个账号被停用了，找老板' }
            else {
                $chk = Test-PasswordHash ([string]$req.password) ([string]$w.hash)
                if ($chk -eq 'bad') { $res.error = '密码不对' }
                else {
                    if ($chk -eq 'ok-legacy') {
                        # 老哈希登录成功，顺手升级成加盐哈希
                        try {
                            $workers = @(Read-JsonArray $WorkersFile)
                            foreach ($x in $workers) { if ([string]$x.nickname -eq $nick) { $x.hash = New-PasswordHash ([string]$req.password); break } }
                            Save-Workers $workers
                        } catch { }
                    }
                    $tok = [guid]::NewGuid().ToString()
                    $script:WorkerTokens[$tok] = $w.nickname
                    $res.ok = $true; $res.token = $tok; $res.role = [string]$w.role; $res.nickname = [string]$w.nickname
                }
            }
        } catch { $res.error = $_.Exception.Message }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/change-boss-password') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能改' }
        else {
            try {
                $hash = Get-BossHash
                if ((Test-PasswordHash ([string]$req.oldPassword) $hash) -eq 'bad') { $res.error = '原密码不对' }
                elseif ([string]$req.newPassword.Length -lt 4) { $res.error = '新密码至少 4 位' }
                else { Set-BossHash (New-PasswordHash ([string]$req.newPassword)); $res.ok = $true }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/worker-change-password') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -eq 'boss') { $res.error = '没有权限' }
        else {
            try {
                $workers = @(Read-JsonArray $WorkersFile)
                $found = $false
                foreach ($w in $workers) {
                    if ([string]$w.nickname -eq $r.nickname) {
                        $found = $true
                        if ((Test-PasswordHash ([string]$req.oldPassword) ([string]$w.hash)) -eq 'bad') { $res.error = '原密码不对' }
                        elseif ([string]$req.newPassword.Length -lt 4) { $res.error = '新密码至少 4 位' }
                        else { $w.hash = New-PasswordHash ([string]$req.newPassword); $res.ok = $true }
                        break
                    }
                }
                if ($found -and $res.ok) { Save-Workers $workers }
                if (-not $found) { $res.error = '找不到这个账号' }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'GET' -and $path -eq '/api/view') {
        $r = Get-RequestRole $headers
        if ($null -eq $r) { Send-Response $stream 'application/json' '{"ok":false,"error":"需要登录","needAuth":true}' }
        else {
            $html = switch ($r.role) { 'boss' { $ViewBoss } 'admin' { $ViewAdmin } default { $ViewWorker } }
            $res = @{ ok = $true; role = $r.role; nickname = $r.nickname; html = $html }
            Send-Response $stream 'application/json' ($res | ConvertTo-Json -Depth 3 -Compress)
        }
    } elseif ($method -eq 'GET' -and $path -eq '/api/version') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能看"}' }
        else {
            $last = $null
            try {
                $uj = Join-Path $PSScriptRoot 'update-result.json'
                if (Test-Path $uj) { $last = Get-Content $uj -Raw -Encoding UTF8 | ConvertFrom-Json }
            } catch { }
            $res = @{ ok = $true; version = (Get-CurrentVersion); manifestConfigured = (-not [string]::IsNullOrWhiteSpace((Get-ManifestUrl))); lastUpdate = $last; startTime = $script:StartTime.ToString('yyyy-MM-dd HH:mm:ss'); uptimeMinutes = [math]::Floor(((Get-Date) - $script:StartTime).TotalMinutes); holdTimeoutMinutes = (Get-Settings).holdTimeoutMinutes }
            Send-Response $stream 'application/json' ($res | ConvertTo-Json -Depth 3 -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/check-update') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能检查更新"}' }
        else {
            $res = Invoke-ManifestCheck
            $res.ok = $true
            Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/update-from-link') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能更新' }
        else {
            try {
                $url = [string]$req.url
                if ($url -notmatch '^https?://') { $res.error = '链接不对，要以 http:// 或 https:// 开头' }
                else {
                    $zipPath = $UpdateZipPath
                    try {
                        if (-not (Test-Path $UpdateTempDir)) { New-Item -ItemType Directory -Force -Path $UpdateTempDir | Out-Null }
                        Invoke-WebRequest -Uri $url -OutFile $zipPath -UseBasicParsing -TimeoutSec 300 -Headers @{ 'User-Agent' = 'XiaoMengYun/1.0' }
                    } catch { throw "下载失败：$($_.Exception.Message)" }
                    $prep = Prepare-Update $zipPath
                    try { Remove-Item $zipPath -Force -ErrorAction SilentlyContinue } catch { }
                    if (-not $prep.ok) { $res.error = "解压失败：$($prep.error)" }
                    else {
                        $res.ok = $true
                        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
                        Start-UpdaterAndExit
                        $script:StopServer = $true
                        return
                    }
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/update-upload') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能更新' }
        elseif ($null -eq $bodyBytes -or $bodyBytes.Length -lt 4 -or $bodyBytes[0] -ne 0x50 -or $bodyBytes[1] -ne 0x4B) { $res.error = '这不是一个 .zip 更新包' }
        else {
            try {
                $zipPath = $UpdateZipPath
                try {
                    if (-not (Test-Path $UpdateTempDir)) { New-Item -ItemType Directory -Force -Path $UpdateTempDir | Out-Null }
                    [System.IO.File]::WriteAllBytes($zipPath, $bodyBytes)
                } catch { throw "保存更新包失败：$($_.Exception.Message)" }
                $prep = Prepare-Update $zipPath
                try { Remove-Item $zipPath -Force -ErrorAction SilentlyContinue } catch { }
                if (-not $prep.ok) { $res.error = "解压失败：$($prep.error)" }
                else {
                    $res.ok = $true
                    Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
                    Start-UpdaterAndExit
                    $script:StopServer = $true
                    return
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'GET' -and $path -eq '/api/share-link') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能看"}' }
        else {
            $link = Get-TunnelUrl
            $lanLink = ''
            if (-not [string]::IsNullOrEmpty($LanIp)) { $lanLink = "http://${LanIp}:$Port/" }
            Send-Response $stream 'application/json' (@{ ok = $true; link = $link; lanLink = $lanLink } | ConvertTo-Json -Compress)
        }
    } elseif ($method -eq 'GET' -and $path -eq '/api/storage-counts') {
        $r = Get-RequestRole $headers
        if ($null -eq $r) { Send-Response $stream 'application/json' '{"ok":false,"error":"需要登录","needAuth":true}' }
        else {
            $c = Get-StorageCounts
            Send-Response $stream 'application/json' (@{ ok = $true; emails = $c.emails; phones = $c.phones; noLink = $c.noLink; noLinkEmail = $c.noLinkEmail; noLinkPhone = $c.noLinkPhone; usedPhones = $c.usedPhones; usedEmails = $c.usedEmails; total = $c.total } | ConvertTo-Json -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/qr-share') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = ''; token = ''; shareUrl = '' }
        if ($null -eq $r) { $res.error = '需要登录'; $res.needAuth = $true }
        else {
            try {
                $emails = @()
                if ($null -ne $req.emails) { foreach ($e in @($req.emails)) { $em = ([string]$e).Trim(); if ($em) { $emails += $em } } }
                if ($emails.Count -eq 0) { $res.error = '没有邮箱' }
                elseif ($emails.Count -gt 200) { $res.error = '一次最多 200 个邮箱' }
                else {
                    $token = New-QrShare $emails
                    $res.ok = $true; $res.token = $token; $res.shareUrl = (Get-QrShareUrl $token)
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'GET' -and $path -eq '/api/storage-list') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or ($r.role -ne 'boss' -and $r.role -ne 'admin')) { Send-Response $stream 'application/json' '{"ok":false,"error":"没有权限"}' }
        else {
            $st = @(Read-JsonArray $StorageFile | Where-Object { -not [bool]$_.used })
            $list = @($st | ForEach-Object { @{ label = [string]$_.label; type = [string]$_.type; platforms = @($_.platforms); firstUse = [string]$_.firstUse } } | Select-Object -First 200)
            Send-Response $stream 'application/json' (@{ ok = $true; accounts = $list; total = $st.Count } | ConvertTo-Json -Depth 3 -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/storage-add') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = ''; added = 0; skipped = 0; noLinkAdded = 0; spentSkipped = 0; emails = 0; phones = 0 }
        if ($null -eq $r -or ($r.role -ne 'boss' -and $r.role -ne 'admin')) { $res.error = '只有老板和管理员能添加' }
        else {
            try {
                $type = [string]$req.type
                if ($type -ne 'email' -and $type -ne 'phone') { $type = '' }
                $parsed = Parse-AccountLines ([string]$req.text) $type
                $st = @(Read-JsonArray $StorageFile)
                $taken = @(Read-JsonArray $TakenFile)
                $append = $false
                try { $append = [bool]$req.append } catch { }
                if (-not $append) {
                    # 替换本类仓库时，已废弃的记录要留着（不然重导会把废号复活）
                    if ($type) { $st = @($st | Where-Object { ([string]$_.type -ne $type) -or [bool]$_.used }) }
                    else { $st = @($st | Where-Object { [bool]$_.used }) }
                }
                $seen = @{}
                foreach ($a in $st) { $seen[[string]$a.label] = 1 }
                foreach ($a in $taken) { $seen[[string]$a.label] = 1 }
                $spent = Get-SpentLabels
                $black = Get-BlacklistLabels
                foreach ($p in $parsed) {
                    if ($spent.ContainsKey($p.label) -or $black.ContainsKey($p.label)) { $res.skipped++; $res.spentSkipped++; continue }
                    if ($seen.ContainsKey($p.label)) { $res.skipped++; continue }
                    $st += @{ label = $p.label; url = $p.url; type = $p.type; platforms = @(); firstUse = ''; used = $false }
                    $seen[$p.label] = 1
                    $res.added++
                    if ([string]::IsNullOrWhiteSpace($p.url)) { $res.noLinkAdded++ }
                }
                Write-JsonArray $StorageFile $st
                $c = Get-StorageCounts
                $res.ok = $true; $res.emails = $c.emails; $res.phones = $c.phones
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/storage-delete') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能删除' }
        else {
            try {
                $label = ([string]$req.label).Trim()
                $st = @(Read-JsonArray $StorageFile | Where-Object { [string]$_.label -ne $label })
                Write-JsonArray $StorageFile $st
                $tk = @(Read-JsonArray $TakenFile | Where-Object { [string]$_.label -ne $label })
                Write-JsonArray $TakenFile $tk
                $res.ok = $true
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/storage-clear') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能清空' }
        else {
            try {
                $type = [string]$req.type
                $st = @(Read-JsonArray $StorageFile)
                # 已废弃的记录留着（不然重导会把废号复活）
                if ($type -eq 'email' -or $type -eq 'phone') { $st = @($st | Where-Object { ([string]$_.type -ne $type) -or [bool]$_.used }) }
                else { $st = @($st | Where-Object { [bool]$_.used }) }
                Write-JsonArray $StorageFile $st
                $res.ok = $true
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/cleanup') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = ''; removed = 0; items = @() }
        if ($null -eq $r -or ($r.role -ne 'boss' -and $r.role -ne 'admin')) { $res.error = '没有权限' }
        else {
            try {
                $removed = Invoke-Cleanup
                $res.ok = $true; $res.removed = $removed.Count; $res.items = $removed
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Depth 3 -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/take') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = ''; label = ''; type = ''; platforms = @(); firstUse = ''; spent = $false }
        if ($null -eq $r) { $res.error = '需要登录'; $res.needAuth = $true }
        else {
            try {
                $type = [string]$req.type
                $needPlatform = [string]$req.needPlatform
                $st = @(Read-JsonArray $StorageFile)
                $spent = Get-SpentLabels
                $black = Get-BlacklistLabels
                # 找一个能用的账号。TikTok 是最主要的用途：邮箱默认优先还没注册过 TikTok 的。
                # 第一遍先跳过已注册 TikTok 的邮箱；如果一个都没有，第二遍再放宽到任意可用邮箱。
                # 工人明确选了平台（needPlatform）时按他选的来，不做这个优先。
                $preferTikTok = (-not $needPlatform -and $type -eq 'email')
                $idx = -1
                foreach ($pass in @(0, 1)) {
                    if ($idx -ge 0) { break }
                    if ($pass -eq 1 -and -not $preferTikTok) { break }
                    for ($i = 0; $i -lt $st.Count; $i++) {
                        $a = $st[$i]
                        if ([string]$a.type -ne $type) { continue }
                        if ([bool]$a.used) { continue }
                        if ([string]::IsNullOrWhiteSpace([string]$a.url)) { continue }
                        if ($spent.ContainsKey([string]$a.label)) { continue }
                        if ($black.ContainsKey([string]$a.label)) { continue }
                        if ($needPlatform -and $type -eq 'email') {
                            if (@($a.platforms) -contains $needPlatform) { continue }
                        }
                        if ($pass -eq 0 -and $preferTikTok) {
                            if (@($a.platforms) -contains 'TikTok') { continue }
                        }
                        $idx = $i; break
                    }
                }
                if ($idx -lt 0) {
                    $res.error = if ($needPlatform) { '仓库里没有还没注册过「' + $needPlatform + '」的邮箱了' } else { '仓库里没有带链接的' + $(if ($type -eq 'email') { '邮箱' } else { '电话号码' }) + '了' }
                }
                else {
                    $item = $st[$idx]
                    $newSt = @()
                    for ($i = 0; $i -lt $st.Count; $i++) { if ($i -ne $idx) { $newSt += $st[$i] } }
                    Write-JsonArray $StorageFile $newSt
                    $tk = @(Read-JsonArray $TakenFile)
                    $tk += @{ label = [string]$item.label; url = [string]$item.url; type = [string]$item.type; platforms = @($item.platforms); firstUse = [string]$item.firstUse; used = $false; nickname = $r.nickname; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); lastSeen = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
                    Write-JsonArray $TakenFile $tk
                    Append-TakeLog ([string]$item.label) ([string]$item.type) $r.nickname
                    $res.ok = $true; $res.label = [string]$item.label; $res.type = [string]$item.type
                    $res.platforms = @($item.platforms); $res.firstUse = [string]$item.firstUse
                    if ($r.role -eq 'boss' -or $r.role -eq 'admin') { $res.url = [string]$item.url }
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Depth 3 -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/release') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = ''; discarded = $false }
        if ($null -eq $r) { $res.error = '需要登录'; $res.needAuth = $true }
        else {
            try {
                $rel = Invoke-ReleaseLabel ([string]$req.label)
                $res.ok = $true; $res.discarded = [bool]$rel.discarded
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/confirm') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = ''; discarded = $true }
        if ($null -eq $r) { $res.error = '需要登录'; $res.needAuth = $true }
        else {
            try {
                $label = ([string]$req.label).Trim()
                $tk = @(Read-JsonArray $TakenFile)
                $rec = $null
                foreach ($t in $tk) { if ([string]$t.label -eq $label) { $rec = $t; break } }
                if ($null -eq $rec) {
                    $st = @(Read-JsonArray $StorageFile)
                    foreach ($a in $st) { if ([string]$a.label -eq $label) { $rec = $a; break } }
                }
                if ($null -eq $rec) { $res.ok = $true }
                else {
                    Mark-Spent $label ([string]$rec.type) '工人确认废弃'
                    $tk2 = @($tk | Where-Object { [string]$_.label -ne $label })
                    Write-JsonArray $TakenFile $tk2
                    $res.ok = $true
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/fetch') {
        $r = Get-RequestRole $headers
        if ($null -eq $r) { Send-Response $stream 'application/json' '{"ok":false,"error":"需要登录","needAuth":true}' }
        else {
            $result = [ordered]@{ label = ''; code = ''; sender = ''; time = ''; ok = $false; error = '请求无效'; platforms = @(); spent = $false; firstUse = ''; platform = '' }
            try {
                $label = ([string]$req.label).Trim()
                $result.label = $label
                $t = Find-Taken $label
                if ($null -eq $t) { $result.error = '这个账号不在服务器上（可能已废弃或已释放），请重新取一个'; $result.gone = $true }
                else {
                    $result = Fetch-One $label ([string]$t.url) ([string]$t.type)
                    $result.label = $label
                    if ($result.ok -and $result.code) {
                        $preg = Register-Platform $label ([string]$t.type) $result.sender $r.nickname
                        $result.platform = $preg.platform
                        # 收到码 = 有动静：更新最后活动时间，超时放回按这个时间算
                        try {
                            $tk3 = @(Read-JsonArray $TakenFile)
                            foreach ($x in $tk3) { if ([string]$x.label -eq $label) { $x.lastSeen = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); break } }
                            Write-JsonArray $TakenFile $tk3
                        } catch { }
                    }
                    $t2 = Find-Taken $label
                    if ($null -ne $t2) { $result.platforms = @($t2.platforms); $result.spent = [bool]$t2.used; $result.firstUse = [string]$t2.firstUse }
                    else { $result.platforms = @(); $result.spent = $true }
                }
            } catch { $result.error = $_.Exception.Message }
            Send-Response $stream 'application/json' ($result | ConvertTo-Json -Depth 3 -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/set-platform') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = ''; platforms = @(); spent = $false; firstUse = '' }
        if ($null -eq $r) { $res.error = '需要登录'; $res.needAuth = $true }
        else {
            try {
                $label = ([string]$req.label).Trim()
                $platform = [string]$req.platform
                $on = $false
                try { $on = [bool]$req.on } catch { }
                if ($platform -notin @('TikTok', 'PixVerse', '可灵')) { $res.error = '平台不对' }
                else {
                    $taken = @(Read-JsonArray $TakenFile)
                    $rec = $null; $where = ''
                    foreach ($t in $taken) { if ([string]$t.label -eq $label) { $rec = $t; $where = 'taken'; break } }
                    if ($null -eq $rec) {
                        $st = @(Read-JsonArray $StorageFile)
                        foreach ($a in $st) { if ([string]$a.label -eq $label) { $rec = $a; $where = 'storage'; break } }
                    }
                    if ($null -eq $rec) { $res.error = '找不到这个账号' }
                    elseif ([bool]$rec.used) { $res.error = '这个账号已废弃' }
                    else {
                        $type = [string]$rec.type
                        $plats = @()
                        foreach ($p in @($rec.platforms)) { $plats += [string]$p }
                        if ($on) {
                            if ($plats -notcontains $platform) {
                                if ($type -eq 'phone' -and $plats.Count -ge 1) { $plats = @($platform) }
                                else { $plats += $platform }
                                if ([string]::IsNullOrWhiteSpace([string]$rec.firstUse)) { $rec.firstUse = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
                                $log = @(Read-JsonArray $UsageLogFile)
                                $log += @{ label = $label; type = $type; platform = $platform; nickname = $r.nickname; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); manual = $true }
                                if ($log.Count -gt 1000) { $log = $log[($log.Count - 1000)..($log.Count - 1)] }
                                Write-JsonArray $UsageLogFile $log
                                if ($type -eq 'email' -and $plats.Count -ge 3) { $rec.used = $true; $res.spent = $true }
                            }
                        } else {
                            $plats = @($plats | Where-Object { $_ -ne $platform })
                        }
                        $rec.platforms = $plats
                        $res.platforms = $plats
                        $res.firstUse = [string]$rec.firstUse
                        if ($where -eq 'taken') { Write-JsonArray $TakenFile $taken }
                        else {
                            $st2 = @(Read-JsonArray $StorageFile)
                            foreach ($a in $st2) {
                                if ([string]$a.label -eq $label) { $a.platforms = $plats; $a.firstUse = [string]$rec.firstUse; $a.used = [bool]$rec.used; break }
                            }
                            Write-JsonArray $StorageFile $st2
                        }
                        if ($res.spent) { Mark-Spent $label $type '已用满 3 个平台' }
                        $res.ok = $true
                    }
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Depth 3 -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/blacklist') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r) { $res.error = '需要登录'; $res.needAuth = $true }
        else {
            try {
                $label = ([string]$req.label).Trim()
                $type = ''
                $tk = @(Read-JsonArray $TakenFile)
                foreach ($t in $tk) { if ([string]$t.label -eq $label) { $type = [string]$t.type; break } }
                if (-not $type) {
                    $st = @(Read-JsonArray $StorageFile)
                    foreach ($a in $st) { if ([string]$a.label -eq $label) { $type = [string]$a.type; break } }
                }
                if (-not $type) { $res.error = '找不到这个账号' }
                else {
                    $tk2 = @($tk | Where-Object { [string]$_.label -ne $label })
                    Write-JsonArray $TakenFile $tk2
                    $st2 = @(Read-JsonArray $StorageFile | Where-Object { [string]$_.label -ne $label })
                    Write-JsonArray $StorageFile $st2
                    $bl = @(Read-JsonArray $BlacklistFile)
                    $exists = $false
                    foreach ($b in $bl) { if ([string]$b.label -eq $label) { $exists = $true; break } }
                    if (-not $exists) {
                        $bl += @{ label = $label; type = $type; nickname = $r.nickname; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
                        Write-JsonArray $BlacklistFile $bl
                    }
                    $res.ok = $true
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'GET' -and $path -eq '/api/blacklist-list') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能看"}' }
        else {
            $list = @(Read-JsonArray $BlacklistFile)
            [array]::Reverse($list)
            Send-Response $stream 'application/json' (@{ ok = $true; list = $list } | ConvertTo-Json -Depth 3 -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/blacklist-remove') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能操作' }
        else {
            try {
                $label = ([string]$req.label).Trim()
                $bl = @(Read-JsonArray $BlacklistFile | Where-Object { [string]$_.label -ne $label })
                Write-JsonArray $BlacklistFile $bl
                $res.ok = $true
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'GET' -and $path -eq '/api/people') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能看"}' }
        else {
            $people = @(Read-JsonArray $WorkersFile | ForEach-Object {
                @{ nickname = [string]$_.nickname; role = [string]$_.role; enabled = [bool]$_.enabled; created = [string]$_.created; balance = $_.balance }
            })
            Send-Response $stream 'application/json' (@{ ok = $true; people = $people } | ConvertTo-Json -Depth 3 -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/person-set-role') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能改角色' }
        else {
            try {
                $nick = ([string]$req.nickname).Trim()
                $newRole = [string]$req.role
                if ($newRole -ne 'admin' -and $newRole -ne 'worker') { $res.error = '角色不对' }
                else {
                    $workers = @(Read-JsonArray $WorkersFile)
                    $found = $false
                    foreach ($w in $workers) {
                        if ([string]$w.nickname -eq $nick) { $w.role = $newRole; $found = $true; break }
                    }
                    if (-not $found) { $res.error = '没有这个人' }
                    else { Save-Workers $workers; $res.ok = $true }
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/person-set-enabled') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能改' }
        else {
            try {
                $nick = ([string]$req.nickname).Trim()
                $enabled = $false
                try { $enabled = [bool]$req.enabled } catch { }
                $workers = @(Read-JsonArray $WorkersFile)
                $found = $false
                foreach ($w in $workers) {
                    if ([string]$w.nickname -eq $nick) { $w.enabled = $enabled; $found = $true; break }
                }
                if (-not $found) { $res.error = '没有这个人' }
                else {
                    Save-Workers $workers
                    if (-not $enabled) {
                        $keys = @($script:WorkerTokens.Keys)
                        foreach ($k in $keys) { if ($script:WorkerTokens[$k] -eq $nick) { $script:WorkerTokens.Remove($k) } }
                    }
                    $res.ok = $true
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/person-delete') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能删除' }
        else {
            try {
                $nick = ([string]$req.nickname).Trim()
                $workers = @(Read-JsonArray $WorkersFile | Where-Object { [string]$_.nickname -ne $nick })
                Save-Workers $workers
                $keys = @($script:WorkerTokens.Keys)
                foreach ($k in $keys) { if ($script:WorkerTokens[$k] -eq $nick) { $script:WorkerTokens.Remove($k) } }
                $res.ok = $true
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/set-regcode') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能改邀请码' }
        else {
            try {
                $code = [string]$req.code
                if ($code.Length -lt 4) { $res.error = '邀请码至少 4 位' }
                else { Set-RegCode $code; $res.ok = $true }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'GET' -and $path -eq '/api/regcode-status') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能看"}' }
        else {
            $code = Get-RegCode
            Send-Response $stream 'application/json' (@{ ok = $true; hasCode = (-not [string]::IsNullOrEmpty($code)); code = $code } | ConvertTo-Json -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/boss-reset-worker-password') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能改' }
        else {
            try {
                $nick = ([string]$req.nickname).Trim()
                $npw = [string]$req.newPassword
                if ($npw.Length -lt 4) { $res.error = '新密码至少 4 位' }
                else {
                    $workers = @(Read-JsonArray $WorkersFile)
                    $found = $false
                    foreach ($w in $workers) {
                        if ([string]$w.nickname -eq $nick) { $w.hash = New-PasswordHash $npw; $found = $true; break }
                    }
                    if (-not $found) { $res.error = '没有这个人' }
                    else {
                        Save-Workers $workers
                        $keys = @($script:WorkerTokens.Keys)
                        foreach ($k in $keys) { if ($script:WorkerTokens[$k] -eq $nick) { $script:WorkerTokens.Remove($k) } }
                        $res.ok = $true
                    }
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'GET' -and $path -eq '/api/takelog') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能看"}' }
        else {
            $log = @(Read-JsonArray $TakeLogFile)
            [array]::Reverse($log)
            $log = @($log | Select-Object -First 50)
            Send-Response $stream 'application/json' (@{ ok = $true; log = $log } | ConvertTo-Json -Depth 3 -Compress)
        }
    } elseif ($method -eq 'GET' -and $path -eq '/api/usage') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or ($r.role -ne 'boss' -and $r.role -ne 'admin')) { Send-Response $stream 'application/json' '{"ok":false,"error":"没有权限"}' }
        else {
            $log = @(Read-JsonArray $UsageLogFile)
            [array]::Reverse($log)
            $log = @($log | Select-Object -First 100)
            Send-Response $stream 'application/json' (@{ ok = $true; log = $log } | ConvertTo-Json -Depth 3 -Compress)
        }
    } elseif ($method -eq 'GET' -and $path -eq '/api/settings') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能看"}' }
        else {
            $s = Get-Settings
            Send-Response $stream 'application/json' (@{ ok = $true; holdTimeoutMinutes = $s.holdTimeoutMinutes } | ConvertTo-Json -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/settings') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能改' }
        else {
            try {
                $m = 0
                try { $m = [int]$req.holdTimeoutMinutes } catch { }
                if ($m -lt 5 -or $m -gt 1440) { $res.error = '超时时间要在 5 到 1440 分钟之间' }
                else { Set-Settings @{ holdTimeoutMinutes = $m }; $res.ok = $true; $res.holdTimeoutMinutes = $m }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'GET' -and $path -eq '/api/holds') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能看"}' }
        else {
            $now = Get-Date
            $holds = @()
            foreach ($t in @(Read-JsonArray $TakenFile)) {
                $takenAt = $null
                try { $takenAt = [datetime]$t.time } catch { }
                $last = $null
                try { if (-not [string]::IsNullOrWhiteSpace([string]$t.lastSeen)) { $last = [datetime]$t.lastSeen } } catch { }
                $holds += @{
                    label = [string]$t.label; type = [string]$t.type; nickname = [string]$t.nickname
                    time = [string]$t.time; platforms = @($t.platforms)
                    heldMinutes = $(if ($null -ne $takenAt) { [math]::Floor(($now - $takenAt).TotalMinutes) } else { 0 })
                    idleMinutes = $(if ($null -ne $last) { [math]::Floor(($now - $last).TotalMinutes) } else { 0 })
                }
            }
            $holds = @($holds | Sort-Object -Property heldMinutes -Descending)
            Send-Response $stream 'application/json' (@{ ok = $true; holds = $holds; holdTimeoutMinutes = (Get-Settings).holdTimeoutMinutes } | ConvertTo-Json -Depth 3 -Compress)
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/backup') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = ''; name = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能备份' }
        else {
            try { $res.name = New-Backup 'manual'; $res.ok = $true } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'GET' -and $path -eq '/api/backup-list') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能看"}' }
        else { Send-Response $stream 'application/json' (@{ ok = $true; backups = @(Get-BackupList) } | ConvertTo-Json -Depth 3 -Compress) }
    } elseif ($method -eq 'POST' -and $path -eq '/api/backup-download') {
        $r = Get-RequestRole $headers
        if ($null -eq $r -or $r.role -ne 'boss') { Send-Response $stream 'application/json' '{"ok":false,"error":"只有老板能下载"}' }
        else {
            # 只允许 backups/ 里以“小梦云备份-”开头、.zip 结尾的文件名，防目录穿越
            $name = [string]$req.name
            if ($name -notmatch '^小梦云备份-[0-9]{8}-[0-9]{6}\.zip$') { Send-Response $stream 'application/json' '{"ok":false,"error":"文件名不对"}' }
            else {
                $fp = Join-Path $BackupDir $name
                if (-not (Test-Path $fp)) { Send-Response $stream 'application/json' '{"ok":false,"error":"备份文件不存在"}' }
                else {
                    $bytes = [System.IO.File]::ReadAllBytes($fp)
                    Send-BinaryResponse $stream 'application/zip' $bytes 0 $name
                }
            }
        }
    } elseif ($method -eq 'POST' -and $path -eq '/api/backup-delete') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = '' }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能删除' }
        else {
            try {
                $name = [string]$req.name
                if ($name -notmatch '^小梦云备份-[0-9]{8}-[0-9]{6}\.zip$') { $res.error = '文件名不对' }
                else {
                    $fp = Join-Path $BackupDir $name
                    if (Test-Path $fp) { Remove-Item $fp -Force }
                    $res.ok = $true
                }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Compress)
    } elseif ($method -eq 'POST' -and $path -eq '/api/restore') {
        $r = Get-RequestRole $headers
        $res = @{ ok = $false; error = ''; restored = @() }
        if ($null -eq $r -or $r.role -ne 'boss') { $res.error = '只有老板能恢复'; if ($null -eq $r) { $res.needAuth = $true } }
        elseif ($null -eq $bodyBytes -or $bodyBytes.Length -lt 4 -or $bodyBytes[0] -ne 0x50 -or $bodyBytes[1] -ne 0x4B) { $res.error = '不是 zip 备份文件' }
        else {
            try {
                $tmp = Join-Path $PSScriptRoot 'restore-upload.zip'
                [System.IO.File]::WriteAllBytes($tmp, $bodyBytes)
                try {
                    $rr = Restore-Backup $tmp
                    $res.ok = $true; $res.restored = @($rr.restored)
                } finally { if (Test-Path $tmp) { Remove-Item $tmp -Force -ErrorAction SilentlyContinue } }
            } catch { $res.error = $_.Exception.Message }
        }
        Send-Response $stream 'application/json' ($res | ConvertTo-Json -Depth 3 -Compress)
    } else {
        Send-Response $stream 'text/plain' 'Not Found'
    }
}

# ================= 启动 =================
$script:StopServer = $false
$script:StartTime = Get-Date
$script:LastHoldCheck = [datetime]::MinValue
$script:LastAutoBackup = [datetime]::MinValue
$LanIp = Get-LanIp
$HtmlShellServed = $HtmlShell.Replace('__LAN_IP__', $LanIp).Replace('__LAN_PORT__', "$Port")

# 启动时清理一次仓库（只清废弃/过期的，能用的不动）
try {
    $cleaned = Invoke-Cleanup
    if ($cleaned.Count -gt 0) { Write-Host "  启动清理：清掉 $($cleaned.Count) 个废弃账号。" }
} catch { }
$script:LastCleanup = Get-Date

# 启动时放回超时没还的号（上次关机前被人拿着没还的）
try {
    $rel = Invoke-HoldTimeout
    if ($rel.Count -gt 0) { Write-Host "  启动放回：$($rel.Count) 个超时没还的账号已自动放回仓库。" }
} catch { }
$script:LastHoldCheck = Get-Date

# 启动时检查一次更新源（配了 manifestUrl 才查；没配就跳过，不卡启动）
try {
    $mu = Get-ManifestUrl
    if (-not [string]::IsNullOrWhiteSpace($mu)) {
        $script:UpdateCheck = Invoke-ManifestCheck
        if ($script:UpdateCheck.updateAvailable) { Write-Host "  发现新版 v$($script:UpdateCheck.version)，BOSS 端可以一键更新。" -ForegroundColor Yellow }
    }
} catch { }

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $Port)
try { $listener.Start() } catch {
    Write-Host '启动失败：端口被占用，请关掉其他程序再试。' -ForegroundColor Red
    Write-Host $_.Exception.Message
    Read-Host '按回车退出'
    exit 1
}

# 尽力给 Windows 防火墙放行这个端口（需要管理员权限；没权限就跳过，首次运行弹窗点“允许访问”也行）
# profile=any：不管电脑的网络是专用还是公用都放行（只放 private 的话，网络被归成公用时手机就连不上 18080；
# 本机 127.0.0.1 不受影响，所以电脑上能打开、手机打不开。2026-11-11 用户实测 v1.0.3 的问题）
try {
    if (Get-Command netsh -ErrorAction SilentlyContinue) {
        $ruleName = "小梦云-$Port"
        $out = netsh advfirewall firewall show rule name="$ruleName" 2>$null
        if ($out -notmatch '小梦云') {
            netsh advfirewall firewall add rule name="$ruleName" dir=in action=allow protocol=TCP localport=$Port profile=any 2>$null | Out-Null
            Write-Host "  已尝试给 Windows 防火墙放行端口 $Port（如果没弹管理员确认，首次运行时弹窗请点“允许访问”）。"
        } elseif ($out -notmatch '任何' -and $out -notmatch 'Any') {
            # 老版本建的规则只放行了专用网络，删掉重建为 profile=any，否则升级后手机还是连不上
            netsh advfirewall firewall delete rule name="$ruleName" 2>$null | Out-Null
            netsh advfirewall firewall add rule name="$ruleName" dir=in action=allow protocol=TCP localport=$Port profile=any 2>$null | Out-Null
            Write-Host "  已把防火墙规则改成放行所有网络（之前只放行了专用网络）。"
        }
    }
} catch { }

# 启动时清掉上次残留的更新临时目录（上次更新中断留下的）
try {
    if (Test-Path $UpdateTempDir) { Remove-Item $UpdateTempDir -Recurse -Force -ErrorAction SilentlyContinue }
} catch { }

# 启动隧道之前，先清掉上次关黑窗口留下的 cloudflared 孤儿进程（不然它一直占着安装文件夹）
Stop-OurCloudflared

# 启动隧道（公开链接）
if (Test-Path $CfExe) {
    try {
        $script:CfProcess = Start-Process -FilePath $CfExe -ArgumentList @('tunnel','--url',"http://127.0.0.1:$Port",'--logfile',$CfLogFile,'--no-autoupdate') -PassThru -WindowStyle Hidden
        Write-Host '  隧道启动中（cloudflared），公开链接生成后会显示在 BOSS 端页面上。'
    } catch { Write-Host '  隧道启动失败，仅本机/局域网可用。' -ForegroundColor Yellow }
} else {
    Write-Host '  未找到 cloudflared.exe，公开链接不可用，仅本机/局域网可用。' -ForegroundColor Yellow
}

Write-Host ''
Write-Host '  小梦云已启动' -ForegroundColor Green
Write-Host "  本机访问：http://127.0.0.1:$Port/"
if ($LanIp) { Write-Host "  局域网访问：http://${LanIp}:$Port/ （同一 Wi-Fi 的电脑可以直接打开）" }
Write-Host '  公开链接：生成中，见 BOSS 端页面上的分享链接（每次重启都会变）。'
Write-Host '  注意：如果局域网的电脑打不开，可能是 Windows 防火墙拦住了，首次运行时弹窗请点“允许访问”。'
Write-Host '  用完关掉这个黑窗口就是关闭服务。'
Write-Host ''
try { Start-Process "http://127.0.0.1:$Port/" } catch { Write-Host '请手动打开浏览器访问上面的地址。' }

try {
    while (-not $script:StopServer) {
        if ($listener.Pending()) {
            $client = $null
            try {
                $client = $listener.AcceptTcpClient()
                $stream = $client.GetStream()
                $stream.ReadTimeout = 30000
                # ---- 读请求头（原始字节，避免 StreamReader 预读吃掉正文） ----
                $headerBytes = New-Object System.Collections.Generic.List[byte]
                $one = New-Object byte[] 1
                $headerDone = $false
                $headerLimit = 65536
                while (-not $headerDone -and $headerBytes.Count -lt $headerLimit) {
                    $n = $stream.Read($one, 0, 1)
                    if ($n -le 0) { break }
                    $headerBytes.Add($one[0])
                    $c = $headerBytes.Count
                    if ($c -ge 4 -and $headerBytes[$c-4] -eq 13 -and $headerBytes[$c-3] -eq 10 -and $headerBytes[$c-2] -eq 13 -and $headerBytes[$c-1] -eq 10) { $headerDone = $true }
                }
                if ($headerBytes.Count -gt 0 -and $headerDone) {
                    $headerText = [System.Text.Encoding]::ASCII.GetString($headerBytes.ToArray())
                    $lines = $headerText -split "`r`n"
                    $first = $lines[0] -split ' '
                    $method = $first[0]
                    $rawPath = if ($first.Count -ge 2) { $first[1] } else { '/' }
                    $path = ($rawPath -split '\?')[0]
                    $headers = @{}
                    foreach ($ln in $lines) {
                        $ci = $ln.IndexOf(':')
                        if ($ci -gt 0) { $headers[$ln.Substring(0, $ci).Trim().ToLower()] = $ln.Substring($ci + 1).Trim() }
                    }
                    $contentLength = 0
                    if ($headers.ContainsKey('content-length')) { [int]::TryParse($headers['content-length'], [ref]$contentLength) | Out-Null }
                    $isUpload = ($method -eq 'POST' -and ($path -eq '/api/update-upload' -or $path -eq '/api/restore'))
                    $maxBody = if ($isUpload) { 200MB } else { 5MB }
                    $bodyBytes = $null
                    $body = ''
                    if ($contentLength -gt 0 -and $contentLength -le $maxBody) {
                        $buf = New-Object byte[] $contentLength
                        $read = 0
                        while ($read -lt $contentLength) {
                            $n = $stream.Read($buf, $read, $contentLength - $read)
                            if ($n -le 0) { break }
                            $read += $n
                        }
                        if ($read -eq $contentLength) {
                            $bodyBytes = $buf
                            if (-not $isUpload) { $body = [System.Text.Encoding]::UTF8.GetString($buf) }
                        }
                    }
                    Invoke-Request $method $path $headers $body $bodyBytes $stream
                }
            } catch {
                try { Write-Host "请求处理出错：$($_.Exception.Message)" -ForegroundColor Yellow } catch { }
            } finally {
                if ($null -ne $client) { $client.Close() }
            }
        }
        if (-not $script:PublicUrl) { [void](Get-TunnelUrl) }
        # 每 5 分钟检查一次超时没还的号，自动放回
        if (((Get-Date) - $script:LastHoldCheck).TotalMinutes -ge 5) {
            $script:LastHoldCheck = Get-Date
            try { [void](Invoke-HoldTimeout) } catch { }
        }
        # 每天自动清理一次仓库 + 自动备份一次
        if (((Get-Date) - $script:LastCleanup).TotalHours -ge 24) {
            $script:LastCleanup = Get-Date
            try { [void](Invoke-Cleanup) } catch { }
            try { [void](New-Backup 'auto') } catch { }
        }
        Start-Sleep -Milliseconds 50
    }
} finally {
    try { $listener.Stop() } catch { }
    if ($null -ne $script:CfProcess) { try { Stop-Process -Id $script:CfProcess.Id -Force -ErrorAction SilentlyContinue } catch { } }
}
