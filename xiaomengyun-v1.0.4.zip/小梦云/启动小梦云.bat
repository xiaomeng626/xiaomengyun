﻿@echo off
chcp 65001 >nul
title 小梦云
cd /d "%~dp0"

REM 桌面快捷方式（第一次运行时创建一次，带小梦云图标）
if not exist "%USERPROFILE%\Desktop\小梦云.lnk" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\小梦云.lnk'); $s.TargetPath='%~dp0启动小梦云.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0icon.ico'; $s.Description='小梦云'; $s.Save()" >nul 2>&1
)

REM 开机自启（第一次运行时创建一次）：电脑开机后自动跑起小梦云，主机一关工人就用不了，所以要一直开着。
REM 不想自启就删掉下面这个快捷方式：开始菜单 -> 运行 -> shell:startup，删掉里面的“小梦云”。
if not exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\小梦云.lnk" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\小梦云.lnk'); $s.TargetPath='%~dp0启动小梦云.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0icon.ico'; $s.Description='小梦云（开机自启）'; $s.Save()" >nul 2>&1
)

REM 检查启动文件在不在
if not exist "%~dp0小梦云.ps1" (
  echo 找不到 小梦云.ps1，请把压缩包里的文件全部解压到一个文件夹再运行。
  pause
  exit /b 1
)

REM 检查 cloudflared 在不在（没有它就没有公开链接，只能局域网用）
if not exist "%~dp0cloudflared.exe" (
  echo 注意：没找到 cloudflared.exe，公开链接不可用，只能本机/局域网用。
  echo 请确认压缩包里的 cloudflared.exe 和这几个文件在同一个文件夹。
  echo.
)

REM 启动服务器（优先 pwsh，没有就用系统自带的 powershell）
where pwsh >nul 2>&1
if %errorlevel%==0 (
  pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0小梦云.ps1"
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0小梦云.ps1"
)

REM 更新重启时不 pause，直接关窗口；平时停住让用户看到报错
if exist "%~dp0update-pending.json" (
  del "%~dp0update-pending.json" >nul 2>&1
  exit /b 0
)
pause
